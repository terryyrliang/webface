package com.ericsson.sep.eac.asyncclient.netty.request;

import io.netty.handler.codec.http.HttpVersion;
import io.netty.util.CharsetUtil;
import org.junit.Test;

public class HttpVersionTest {
    @Test
    public void testHttpVersion(){
        HttpVersion h2 = HttpVersion.valueOf("http/2.0");
        System.out.println(h2.text());

    }
}

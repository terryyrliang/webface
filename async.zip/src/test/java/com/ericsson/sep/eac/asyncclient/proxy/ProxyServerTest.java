/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.proxy;

import com.ericsson.sep.eac.asyncclient.uri.Uri;
import org.junit.Test;

import static org.junit.Assert.*;

public class ProxyServerTest {
    @Test
    public void testProxyServer(){
        String proxyUrl = "http://10.165.23.45:25000";
        Uri uri = Uri.create(proxyUrl);
        System.out.println(uri.getUserInfo());
        ProxyServer.Builder builder = new ProxyServer.Builder(proxyUrl);
        ProxyServer server = builder.build();
        assertTrue(server.getProxyAuth() == null);
        proxyUrl = "http://user:password@10.165.23.45:25000";
        uri = Uri.create(proxyUrl);
        System.out.println(uri.getUserInfo());
        builder = new ProxyServer.Builder(proxyUrl);
        server = builder.build();
        assertTrue(server.getProxyAuth().getUsername().equals("user"));
        assertTrue(server.getProxyAuth().getPassword().equals("password"));
        System.out.println(server.getProxyAuth().isUsePreemptiveAuth());
    }

}

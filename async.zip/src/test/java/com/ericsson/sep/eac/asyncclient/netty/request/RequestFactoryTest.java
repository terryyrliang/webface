/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.request;

import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.RequestBuilder;
import com.ericsson.sep.eac.asyncclient.config.DefaultAsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import org.junit.Test;

import static org.junit.Assert.*;

public class RequestFactoryTest {

    @Test
    public void newNettyRequest() {
        String requestUrl = "http://localhost:27170/hub/testa?querya=x";
        RequestBuilder requestBuilder = new RequestBuilder();
        Uri targetUri = Uri.create(requestUrl);
        requestBuilder.setUri(targetUri);
        ProxyServer proxyServer = new ProxyServer.Builder("http://user:password@10.165.23.45:25000").build();
        requestBuilder.setProxyServer(proxyServer);
        Request request = requestBuilder.build();

        RequestFactory factory = new RequestFactory(new DefaultAsyncClientConfig.Builder().build());
        NettyRequest nettyRequest = factory.newNettyRequest(request, false, proxyServer, false, null, proxyServer.getProxyAuth());
        System.out.println(nettyRequest);
    }
}

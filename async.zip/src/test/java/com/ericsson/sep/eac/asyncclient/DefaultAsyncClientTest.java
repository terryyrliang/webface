/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.config.DefaultAsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.DefaultSslConfig;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class DefaultAsyncClientTest {
    static int count = 0;
    Set<String> set = new HashSet<>();

    @Test
    public void testAccessH2Backend() throws Exception {
        final Random generator = new Random();
        DefaultAsyncClientConfig.Builder configBuilder = new DefaultAsyncClientConfig.Builder();
        configBuilder.setHttp2PriorKnowledge(true);
        configBuilder.setHttp2(true);
        configBuilder.setMaxConnectionsPerHost(1);
//        configBuilder.setMaxConnections(100);
//        configBuilder.setWindowUpdateRatio(0.5f);
//        configBuilder.setInitialFlowControlWindowUpdate(65536);
        configBuilder.setKeepAlive(true);
        final DefaultSslConfig.Builder sslBuilder = new DefaultSslConfig.Builder();
        sslBuilder.setTlsAllowInsecureConnection(true);
//        sslBuilder.setTrustCertFile("C:\\Jane\\work\\cert\\client-cert.pem");
//        sslBuilder.setUseOpenssl(true);
//        sslBuilder.setTLS13Support(true);
//        configBuilder.setSslConfig(sslBuilder.build());


        final DefaultAsyncClient client = new DefaultAsyncClient(configBuilder.build());
//         http/1.1 with ssl
//                String url = "https://localhost:12306/cert/test";
//                Uri targetUri = Uri.create(url);
        // plain h2
        final String url = "http://localhost:8080/myapp/terry";
        long start = System.currentTimeMillis();
        // tls h2
//        String url = "https://localhost:8443";
        // http1->http2c with upgrade protocol
//        Uri targetUri = Uri.create(url, true);
        // http1->h2c prior-knowledge
        int threadNum = 10;
        int batchNum = 4000;
        List<FutureTask<List<ResponseFuture<Response>>>> futureTasks = new LinkedList<>();
        Callable<List<ResponseFuture<Response>>> callable = new Callable<List<ResponseFuture<Response>>>() {
            @Override
            public List<ResponseFuture<Response>> call() throws Exception {
                List<ResponseFuture<Response>> list = new LinkedList<>();
                for (int i = 0; i < batchNum; i++) {
                    String randomUrl = url + generator.nextInt(10000000) + 1;
                    Uri targetUri = Uri.create(randomUrl, true, true);
                    RequestBuilder requestBuilder = new RequestBuilder("POST");
                    requestBuilder.setUri(targetUri);
                    requestBuilder.setBody(new ByteArrayInputStream("{\"name\" : \"hello worldkkkkk\"}".getBytes()));
                    requestBuilder.setProtocol("HTTP/2.0");
                    requestBuilder.setSslConfig(sslBuilder.build());
                    ResponseFuture<Response> future = (ResponseFuture<Response>) client.executeRequest(requestBuilder.build());
                    list.add(future);
                }
                return list;
            }
        };
        ExecutorService executorService = Executors.newFixedThreadPool(threadNum);
        for (int i = 0; i < threadNum; i++) {
            FutureTask<List<ResponseFuture<Response>>> futureTask = new FutureTask<List<ResponseFuture<Response>>>(callable);
            futureTasks.add(futureTask);
            executorService.submit(futureTask);
        }

        for (FutureTask<List<ResponseFuture<Response>>> futureTask : futureTasks) {
            for (ResponseFuture<Response> responseFuture : futureTask.get()) {
                try {
                    String tmpReqUrl = responseFuture.getTargetRequest().getUrl();
                    String strReq = tmpReqUrl.substring(tmpReqUrl.lastIndexOf("/"));
                    Response response = responseFuture.get(50, TimeUnit.SECONDS);
                    String strResp = response.getResponseBody();
                    strResp = strResp.substring(strResp.lastIndexOf("/"));
                    strResp = strResp.substring(0, strResp.indexOf(","));
                    if (!strResp.contains(strReq)) {
//                        throw new RuntimeException(String.format("Request : %s, response : %s", strReq, strResp));
                    }
//                    System.out.println(response);
                    count++;
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println(String.format("fail to get response for request %s", responseFuture.getTargetRequest().getUrl()));
                }
            }
        }
        long end = System.currentTimeMillis();
        System.out.println("==========Send count is " + ChannelManager.sendCounter.get());
        System.out.println("Init count is " + ChannelManager.initCounter.get());
        System.out.println("null response future count is " + ChannelManager.nullCounter.get());
        System.out.println("Total number is " + count);
        System.out.println("Response number is " + ChannelManager.responseCounter.get());
        System.out.println("Duration takes - " + (end - start) + " ms");

    }

}

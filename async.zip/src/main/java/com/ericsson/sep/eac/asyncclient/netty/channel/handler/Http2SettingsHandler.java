package com.ericsson.sep.eac.asyncclient.netty.channel.handler;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http2.*;
import org.slf4j.Logger;

@ChannelHandler.Sharable
public class Http2SettingsHandler
        extends SimpleChannelInboundHandler<Http2Settings> {
    private static final Logger LOGGER = LogHelper.getLogger(Http2SettingsHandler.class);
    private Http2Settings settings;
    private Object lock = new Object();
    private Integer initialFlowControlWindowUpdate_LATCH = null;

    public Http2SettingsHandler(Integer initialFlowControlWindowUpdate) {
        this.initialFlowControlWindowUpdate_LATCH = initialFlowControlWindowUpdate;
    }

    public void awaitSettings(long timeout)
            throws Exception {
        LOGGER.debug("Start waiting for HTTP/2 settings");
        synchronized (this.lock) {
            this.lock.wait(timeout * 1000L);
        }
        if (this.settings == null) {
            throw new IllegalStateException(" Timeout waiting for HTTP/2 settings");
        }
    }

    protected void channelRead0(ChannelHandlerContext ctx, Http2Settings msg)
            throws Exception {
        synchronized (this.lock) {
            if (this.initialFlowControlWindowUpdate_LATCH != null) {
                Http2ConnectionHandler handler = (Http2ConnectionHandler) ctx.pipeline().get(Http2ConnectionHandler.class);
                Http2Connection connection = handler.connection();
                try {
                    int new_value = 65535 + this.initialFlowControlWindowUpdate_LATCH.intValue();
                    if (new_value > 65535) {
                        ((Http2LocalFlowController) connection.local().flowController()).incrementWindowSize(connection.stream(0), this.initialFlowControlWindowUpdate_LATCH.intValue());
                        LOGGER.debug("initial flow control window update, new value is = {}", Integer.valueOf(new_value));
                    } else if ((new_value == 65535) ||
                            (new_value <= 0) || (new_value >= 65535)) {
                    }
                    this.initialFlowControlWindowUpdate_LATCH = null;
                } catch (Http2Exception e) {
                    LOGGER.debug("exception = {}", e.toString());
                }
            }
            ctx.pipeline().remove(this);
            this.settings = msg;
            this.lock.notifyAll();
        }
        LOGGER.debug("received HTTP/2 settings = {}", msg.toString());
    }
}

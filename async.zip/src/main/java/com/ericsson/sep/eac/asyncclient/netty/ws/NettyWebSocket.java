/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.ws;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.util.ByteBufUtils;
import com.ericsson.sep.eac.asyncclient.ws.WebSocket;
import com.ericsson.sep.eac.asyncclient.ws.WebSocketListener;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.DefaultByteBufHolder;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.websocketx.*;
import io.netty.util.CharsetUtil;
import org.slf4j.Logger;

import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Future;

public class NettyWebSocket implements WebSocket {
    private static final Logger LOGGER = LogHelper.getLogger(NettyWebSocket.class);

    private final Channel channel;
    private final HttpHeaders upgradeHeaders;
    private final Collection<WebSocketListener> webSocketListeners;

    private FrameType frameType;
    private boolean ready;
    private List<WebSocketFrame> bufferedFrames;

    public NettyWebSocket(Channel channel, HttpHeaders upgradeHeaders) {
        this(channel, upgradeHeaders, new ConcurrentLinkedQueue<>());
    }

    public NettyWebSocket(Channel channel, HttpHeaders upgradeHeaders,
        Collection<WebSocketListener> webSocketListeners) {
        this.channel = channel;
        this.upgradeHeaders = upgradeHeaders;
        this.webSocketListeners = webSocketListeners;
    }

    @Override
    public HttpHeaders getUpgradeHeaders() {
        return upgradeHeaders;
    }

    @Override
    public SocketAddress getRemoteAddress() {
        return channel.remoteAddress();
    }

    @Override
    public SocketAddress getLocalAddress() {
        return channel.localAddress();
    }

    @Override
    public Future<Void> sendTextMessageToSouthBound(String payload) {
        return sendTextMessageToSouthBound(payload, true, 0);
    }

    @Override
    public Future<Void> sendTextMessageToSouthBound(String payload, boolean finalFragment,
        int rsv) {
        return channel.writeAndFlush(new TextWebSocketFrame(finalFragment, rsv, payload));
    }

    @Override
    public Future<Void> sendTextMessageToSouthBound(ByteBuf payload, boolean finalFragment,
        int rsv) {
        return channel.writeAndFlush(new TextWebSocketFrame(finalFragment, rsv, payload));
    }

    @Override
    public Future<Void> sendBinaryMessageToSouthBound(byte[] payload) {
        return sendBinaryMessageToSouthBound(payload, true, 0);
    }

    @Override
    public Future<Void> sendBinaryMessageToSouthBound(byte[] payload, boolean finalFragment,
        int rsv) {
        return sendBinaryMessageToSouthBound(Unpooled.wrappedBuffer(payload), finalFragment, rsv);
    }

    @Override
    public Future<Void> sendBinaryMessageToSouthBound(ByteBuf payload, boolean finalFragment,
        int rsv) {
        return channel.writeAndFlush(new BinaryWebSocketFrame(finalFragment, rsv, payload));
    }

    @Override
    public Future<Void> sendContinueFrame(String payload, boolean finalFragment, int rsv) {
        return channel.writeAndFlush(new ContinuationWebSocketFrame(finalFragment, rsv, payload));
    }

    @Override
    public Future<Void> sendContinueFrame(byte[] payload, boolean finalFragment, int rsv) {
        return sendContinueFrame(Unpooled.wrappedBuffer(payload), finalFragment, rsv);
    }

    @Override
    public Future<Void> sendContinueFrame(ByteBuf payload, boolean finalFragment, int rsv) {
        return channel.writeAndFlush(new ContinuationWebSocketFrame(finalFragment, rsv, payload));
    }

    @Override
    public Future<Void> sendPingFrame() {
        return channel.writeAndFlush(new PingWebSocketFrame());
    }

    @Override
    public Future<Void> sendPingFrame(byte[] payload) {
        return sendPingFrame(Unpooled.wrappedBuffer(payload));
    }

    @Override
    public Future<Void> sendPingFrame(ByteBuf payload) {
        return channel.writeAndFlush(new PingWebSocketFrame(payload));
    }

    @Override
    public Future<Void> sendPongFrame() {
        return channel.writeAndFlush(new PongWebSocketFrame());
    }

    @Override
    public Future<Void> sendPongFrame(byte[] payload) {
        return sendPongFrame(Unpooled.wrappedBuffer(payload));
    }

    @Override
    public Future<Void> sendPongFrame(ByteBuf payload) {
        return channel.writeAndFlush(new PongWebSocketFrame(payload));
    }

    @Override
    public Future<Void> sendCloseFrame() {
        return channel.writeAndFlush(new CloseWebSocketFrame());
    }

    @Override
    public Future<Void> sendCloseFrame(int statusCode, String reason) {
        return channel.writeAndFlush(new CloseWebSocketFrame(statusCode, reason));
    }

    @Override
    public boolean isOpen() {
        return channel.isOpen();
    }

    @Override
    public WebSocket addWebSocketListener(WebSocketListener listener) {
        webSocketListeners.add(listener);
        return this;
    }

    @Override
    public WebSocket removeWebSocketListener(WebSocketListener listener) {
        webSocketListeners.remove(listener);
        return this;
    }

    public boolean isReady() {
        return ready;
    }

    public void bufferFrame(WebSocketFrame frame) {
        if (bufferedFrames == null) {
            bufferedFrames = new ArrayList<>(1);
        }
        frame.retain();
        bufferedFrames.add(frame);
    }

    public void releaseBufferedFrames() {
        if (bufferedFrames != null) {
            bufferedFrames.forEach(DefaultByteBufHolder::release);
            bufferedFrames = null;
        }
    }

    public void processBufferedFrames() {
        ready = true;
        if (bufferedFrames != null) {
            try {
                bufferedFrames.forEach(this::handleFrame);
            } finally {
                releaseBufferedFrames();
            }
            bufferedFrames = null;
        }
    }

    public void handleFrame(WebSocketFrame frame) {
        if (frame instanceof TextWebSocketFrame) {
            onTextFrame(frame);
        } else if (frame instanceof BinaryWebSocketFrame) {
            onBinaryFrame(frame);
        } else if (frame instanceof CloseWebSocketFrame) {
            ChannelUtils.setDiscard(channel);
            CloseWebSocketFrame closeFrame = (CloseWebSocketFrame) frame;
            onClose(closeFrame.statusCode(), closeFrame.reasonText());
            ChannelUtils.closeChannelSilently(channel);
        } else if (frame instanceof PingWebSocketFrame) {
            onPingFrame((PingWebSocketFrame) frame);
        } else if (frame instanceof PongWebSocketFrame) {
            onPongFrame((PongWebSocketFrame) frame);
        } else if (frame instanceof ContinuationWebSocketFrame) {
            onContinueFrame((ContinuationWebSocketFrame) frame);
        }
    }

    private void onTextFrame(WebSocketFrame frame) {
        if (frameType == null && !frame.isFinalFragment()) {
            frameType = FrameType.TEXT;
        }
        handleTextFrame(frame);
    }

    private void onBinaryFrame(WebSocketFrame frame) {
        if (frameType == null && !frame.isFinalFragment()) {
            frameType = FrameType.BINARY;
        }
        handleBinaryFrame(frame);
    }

    public void onClose(int statusCode, String reason) {
        try {
            webSocketListeners.forEach(listener -> {
                try {
                    listener.onClose(this, statusCode, reason);
                } catch (Throwable throwable) {
                    listener.onError(throwable);
                }
            });
            webSocketListeners.clear();
        } finally {
            releaseBufferedFrames();
        }
    }

    public void onError(Throwable cause) {
        try {
            webSocketListeners.forEach(listener -> {
                try {
                    listener.onError(cause);
                } catch (Throwable throwable) {
                    LOGGER.error("webSocketListener onError exception", throwable);
                }
            });
        } finally {
            releaseBufferedFrames();
        }
    }

    private void onPingFrame(PingWebSocketFrame frame) {
        webSocketListeners
            .forEach(listener -> listener.onPingFrame(ByteBufUtils.byteBuf2Bytes(frame.content())));
    }

    private void onPongFrame(PongWebSocketFrame frame) {
        webSocketListeners
            .forEach(listener -> listener.onPongFrame(ByteBufUtils.byteBuf2Bytes(frame.content())));
    }

    private void onContinueFrame(ContinuationWebSocketFrame frame) {
        if (frameType == null) {
            LOGGER.warn("Received continuation frame without original frame, ignore");
            return;
        }
        try {
            switch (frameType) {
                case TEXT:
                    onTextFrame(frame);
                    break;
                case BINARY:
                    onBinaryFrame(frame);
                    break;
                default:
                    throw new IllegalArgumentException("unknown web socket frame type");
            }
        } finally {
            if (frame.isFinalFragment()) {
                frameType = null;
            }
        }
    }

    private void handleTextFrame(WebSocketFrame frame) {
        String text = frame.content().toString(CharsetUtil.UTF_8);
        // todo: a faster way to get text??
        webSocketListeners
            .forEach(listener -> listener.onTextFrame(text, frame.isFinalFragment(), frame.rsv()));
    }

    private void handleBinaryFrame(WebSocketFrame frame) {
        webSocketListeners.forEach(listener -> listener
            .onBinaryFrame(ByteBufUtils.byteBuf2Bytes(frame.content()), frame.isFinalFragment(),
                frame.rsv()));
    }

    private enum FrameType {
        TEXT, BINARY
    }
}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient;

import io.netty.buffer.ByteBuf;

import java.nio.ByteBuffer;

public abstract class HttpResponsePartContent {
    private final boolean last;

    public HttpResponsePartContent(boolean last) {
        this.last = last;
    }

    public abstract int length();

    public abstract byte[] getPartContentBytes();

    public abstract ByteBuf getPartContentByteBuf();

    public abstract ByteBuffer getPartContentByteBuffer();

    public boolean isLast(){
        return this.last;
    }
}

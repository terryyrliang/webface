/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.request;

import com.ericsson.sep.eac.asyncclient.Auth;
import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.request.body.NettyBody;
import com.ericsson.sep.eac.asyncclient.netty.request.body.NettyByteBufferBody;
import com.ericsson.sep.eac.asyncclient.netty.request.body.NettyInputStreamBody;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import com.ericsson.sep.eac.asyncclient.util.AuthUtils;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http2.HttpConversionUtil;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

import static com.ericsson.sep.eac.asyncclient.util.AuthUtils.computeProxyAuthorizationHeader;
import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;
import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.urlEncodeFormParams;
import static com.ericsson.sep.eac.asyncclient.util.HttpUtils.*;
import static com.ericsson.sep.eac.asyncclient.util.WebSocketUtil.getWebSocketKey;
import static io.netty.handler.codec.http.HttpHeaderNames.*;
import static io.netty.handler.codec.rtsp.RtspHeaderNames.CONTENT_LENGTH;

public class RequestFactory {
    private static final Logger LOGGER = LogHelper.getLogger(RequestFactory.class);
    private final AsyncClientConfig config;

    public RequestFactory(AsyncClientConfig config) {
        this.config = config;
    }

    public void setAuthorizationHeader(HttpHeaders headers, String authorizationHeader) {
        if (authorizationHeader != null)
            // override authorization
            headers.set(HttpHeaderNames.AUTHORIZATION, authorizationHeader);
    }

    public void setProxyAuthorizationHeader(HttpHeaders headers, String proxyAuthorizationHeader) {
        if (isNonEmpty(proxyAuthorizationHeader))
            headers.set(HttpHeaderNames.PROXY_AUTHORIZATION, proxyAuthorizationHeader);
    }

    public NettyRequest newNettyRequest(Request request, boolean isConnectMethod,
        ProxyServer proxyServer, boolean isUnauthorized, Auth auth, Auth proxyAuth) {

        Uri uri = request.getUri();
        LOGGER.debug("request uri:{}", uri);
        HttpMethod method =
            isConnectMethod ? HttpMethod.CONNECT : HttpMethod.valueOf(request.getMethod());
        boolean connect = method == HttpMethod.CONNECT;

        HttpVersion httpVersion = HttpVersion.HTTP_1_1;
        String requestUri = getRequestUri(uri, proxyServer, connect);

        NettyBody body = connect ? null : body(request);

        NettyRequest nettyRequest;
        if (body == null) {
            HttpRequest httpRequest = new DefaultFullHttpRequest(httpVersion, method, requestUri);
            nettyRequest = new NettyRequest(httpRequest, null);

        } else {
            HttpRequest httpRequest = new DefaultFullHttpRequest(httpVersion, method, requestUri,
                getRequestBody(request));
            nettyRequest = new NettyRequest(httpRequest, body);
        }

        HttpHeaders headers = nettyRequest.getHttpRequest().headers();

        if (connect) {
            // set proxy-auth if CONNECT method
            headers.set(HttpHeaderNames.PROXY_AUTHORIZATION,
                request.getHeaders().getAll(HttpHeaderNames.PROXY_AUTHORIZATION));

        } else {
            // assign headers as configured on request
            headers.set(request.getHeaders());
            if (uri.isHttp2()) {
                HttpScheme scheme = uri.isSecured() ? HttpScheme.HTTPS : HttpScheme.HTTP;
                headers.add(HttpConversionUtil.ExtensionHeaderNames.SCHEME.text(), scheme.name());
            }
        }

        if (body != null) {
            if (body.getContentLength() < 0) {
                headers.set(TRANSFER_ENCODING, HttpHeaderValues.CHUNKED);
            } else {
                headers.set(CONTENT_LENGTH, body.getContentLength());
            }
        } else if (method == HttpMethod.POST || method == HttpMethod.PUT
            || method == HttpMethod.PATCH) {
            headers.set(CONTENT_LENGTH, 0);
        }

        if (body != null && body.getContentType() != null) {
            headers.set(CONTENT_TYPE, body.getContentType());
        }

        // connection header and friends
        if (!connect && uri.isWebSocket()) {
            headers.set(UPGRADE, HttpHeaderValues.WEBSOCKET)
                .set(CONNECTION, HttpHeaderValues.UPGRADE).set(SEC_WEBSOCKET_KEY, getWebSocketKey())
                .set(SEC_WEBSOCKET_VERSION, "13");

            if (!headers.contains(ORIGIN)) {
                headers.set(ORIGIN, originHeader(uri));
            }

        } else if (!headers.contains(CONNECTION)) {
            CharSequence connectionHeaderValue =
                connectionHeader(config.isKeepAlive(), httpVersion);
            if (connectionHeaderValue != null) {
                headers.set(CONNECTION, connectionHeaderValue);
            }
        }

        if (!headers.contains(HOST)) {
            String virtualHost = request.getTargetHost();
            headers.set(HOST, virtualHost != null ? virtualHost : hostHeader(uri));
        }

        // todo: check authorization has already implemented in api-proxy-war
        if (auth != null && auth.getScheme() == Auth.AuthScheme.DIGEST && isUnauthorized) {
            LOGGER.debug("set digest authentication header");
            setAuthorizationHeader(headers, AuthUtils.computeDigestAuthentication(auth));
        }
        // only set proxy auth on request over plain HTTP, or when performing CONNECT
        if (!uri.isSecured() || connect) {
            setProxyAuthorizationHeader(headers, computeProxyAuthorizationHeader(proxyAuth));
        }

        // Add default accept headers
        if (!headers.contains(ACCEPT)) {
            headers.set(ACCEPT, ACCEPT_ALL_HEADER_VALUE);
        }

        return nettyRequest;
    }

    /**
     * get real requestUri if proxyServer is enabled
     * if use CONNECT with proxy Server, the requestUri should be host:port
     * else the requestUri is the full url
     *
     * @param uri
     * @param proxyServer
     * @param isConnectMethod
     * @return
     */
    private String getRequestUri(Uri uri, ProxyServer proxyServer, boolean isConnectMethod) {
        if (isConnectMethod) {
            // if use CONNECT with proxyServer, the requestUri should be host and port
            return uri.getHostAndPort();
        } else if (proxyServer != null && !uri.isSecured() && proxyServer.getProxyType().isHttp()) {
            // proxy over http, and the target is not secured, the requestUrl should be full url
            return uri.toUrl();
        } else {
            // if not the CONNECT method, should be relativeUrl without host:port
            return uri.toRelativeUrl();
        }
    }

    private ByteBuf getRequestBody(Request request) {
        ByteBuf content = null;
        InputStream streamData = request.getStreamData();
        if (streamData != null) {
            content = PooledByteBufAllocator.DEFAULT.buffer();
            try {
                content.writeBytes(streamData, streamData.available());
            } catch (IOException e) {
                LOGGER.error("read request content error", e);
                content = Unpooled.EMPTY_BUFFER;
            }
        } else if (request.getFormParams() != null) {
            ByteBuffer formContent =
                urlEncodeFormParams(request.getFormParams(), request.getCharset());
            content = Unpooled.wrappedBuffer(formContent);
        }
        return content;

    }

    private NettyBody body(Request request) {
        NettyBody body = null;
        InputStream streamData = request.getStreamData();
        if (streamData != null) {
            try {
                body = new NettyInputStreamBody(streamData, streamData.available());
            } catch (IOException e) {
                LOGGER.warn("read streamData from request exception", e);
                body = new NettyInputStreamBody(streamData);
            }
        } else if (isNonEmpty(request.getFormParams())) {
            CharSequence contentTypeOverride = request.getHeaders().contains(CONTENT_TYPE) ?
                null :
                HttpHeaderValues.APPLICATION_X_WWW_FORM_URLENCODED;
            body = new NettyByteBufferBody(
                urlEncodeFormParams(request.getFormParams(), request.getCharset()),
                contentTypeOverride);
        }
        return body;
    }

    private CharSequence connectionHeader(boolean keepAlive, HttpVersion httpVersion) {
        if (httpVersion.isKeepAliveDefault()) {
            return keepAlive ? null : HttpHeaderValues.CLOSE;
        } else {
            return keepAlive ? HttpHeaderValues.KEEP_ALIVE : null;
        }
    }
}

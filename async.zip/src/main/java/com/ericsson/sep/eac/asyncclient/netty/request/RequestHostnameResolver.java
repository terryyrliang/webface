/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.request;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import io.netty.resolver.NameResolver;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.ImmediateEventExecutor;
import io.netty.util.concurrent.Promise;
import org.slf4j.Logger;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

public enum  RequestHostnameResolver {
    INSTANCE;

    private static final Logger LOGGER = LogHelper.getLogger(RequestHostnameResolver.class);

    public Future<List<InetSocketAddress>> resolve(NameResolver<InetAddress> nameResolver, InetSocketAddress unresolvedAddress, AsyncHandler<?> asyncHandler) {

        final String hostname = unresolvedAddress.getHostName();
        final int port = unresolvedAddress.getPort();
        final Promise<List<InetSocketAddress>> promise = ImmediateEventExecutor.INSTANCE.newPromise();

        try {
            asyncHandler.onHostnameResolutionAttempt(hostname);
        } catch (Exception e) {
            LOGGER.error("onHostnameResolutionAttempt crashed", e);
            promise.tryFailure(e);
            return promise;
        }

        final Future<List<InetAddress>> whenResolved = nameResolver.resolveAll(hostname);

        whenResolved.addListener(new SimpleFutureListener<List<InetAddress>>() {

            @Override
            protected void onSuccess(List<InetAddress> value) {
                ArrayList<InetSocketAddress> socketAddresses = new ArrayList<>(value.size());
                for (InetAddress a : value) {
                    socketAddresses.add(new InetSocketAddress(a, port));
                }
                try {
                    asyncHandler.onHostnameResolutionSuccess(hostname, socketAddresses);
                } catch (Exception e) {
                    LOGGER.error("onHostnameResolutionSuccess crashed", e);
                    promise.tryFailure(e);
                    return;
                }
                promise.trySuccess(socketAddresses);
            }

            @Override
            protected void onFailure(Throwable t) {
                try {
                    asyncHandler.onHostnameResolutionFailure(hostname, t);
                } catch (Exception e) {
                    LOGGER.error("onHostnameResolutionFailure crashed", e);
                    promise.tryFailure(e);
                    return;
                }
                promise.tryFailure(t);
            }
        });

        return promise;
    }
}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler;

import com.ericsson.sep.eac.asyncclient.HttpResponsePartContent;
import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.handler.codec.DecoderResultProvider;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http2.HttpConversionUtil;
import io.netty.util.AsciiString;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@ChannelHandler.Sharable
public class Http2Handler extends AsyncClientBaseHandler {
    private static final int STREAM_ID_INC_STEP = 2;
    private final static AsciiString streamIdHeaderName =
            HttpConversionUtil.ExtensionHeaderNames.STREAM_ID.text();

    public Http2Handler(AsyncClientConfig config, RequestSender requestSender,
                        ChannelManager channelManager) {
        super(config, requestSender, channelManager);
    }

    @Override
    public void handleRead(Channel channel, ResponseFuture<?> future, Object receivedMsg) {
        if ("yes".equalsIgnoreCase(channel.attr(AsyncConstants.UPGRADE_ISSUED_ATTR).get()) && (channel.attr(AsyncConstants.UPGRADE_REJECTED_ATTR).get() == null &&
                channel.attr(AsyncConstants.UPGRADE_SUCCESSFUL_ATTR).get() == null)) {
            return;
        }

        if (receivedMsg instanceof DefaultFullHttpResponse) {
            LOGGER.debug("Handle Read channel for direct h2c.");
        } else if (receivedMsg instanceof DefaultHttpResponse) {
            // HTTP 1.1 response
            LOGGER.debug("Receive DefaultHttpResponse");
            future.setDefaultHttpResponse((DefaultHttpResponse)receivedMsg);
            LOGGER.debug("Save the response info");
            return;
        } else {
            // Upgrade H2C response content
            // io.netty.handler.codec.http.DefaultHttpContent
            LOGGER.debug("Handle Read channel for upgrade h2c.");
        }
        LOGGER.debug("Http2Handler received Message: {}", receivedMsg.getClass().getSimpleName());
        if (future.isDone()) {
            LOGGER.debug("Future is already done.");
            channelManager.closeChannel(channel);
            return;
        }
        try {
            if (receivedMsg instanceof DecoderResultProvider) {
                DecoderResultProvider decoderResultProvider = (DecoderResultProvider) receivedMsg;
                Throwable throwable = decoderResultProvider.decoderResult().cause();
                if (throwable != null) {
                    handleReadFailure(channel, future, throwable);
                    return;
                }
            }

            if (receivedMsg instanceof DefaultFullHttpResponse) {
                handleHttp2Response(channel, future, (DefaultFullHttpResponse) receivedMsg);
            } else if (receivedMsg instanceof DefaultHttpContent) {
                // Handle H2C upgrade fail response
                handleHttp11Response(channel, future, (DefaultHttpContent) receivedMsg);
            }
        } catch (Exception e) {
            handleReadFailure(channel, future, e);
        }
    }

    private void handleHttp2Response(Channel channel, ResponseFuture<?> future, DefaultFullHttpResponse fullHttpResponse) {
        String streamId = fullHttpResponse.headers().get(streamIdHeaderName);
        LOGGER.debug("StreamId in response: {} ", streamId);
        if (streamId != null) {
            channel.pipeline().firstContext().executor().newPromise()
                    .trySuccess(fullHttpResponse);
            final HttpResponse httpResponse =
                    new DefaultHttpResponse(fullHttpResponse.protocolVersion(),
                            fullHttpResponse.status());
            httpResponse.headers().set(fullHttpResponse.headers());
            handleHttpResponse(httpResponse, channel, future);
            handleHttpContent(fullHttpResponse.content(), channel, future, Integer.valueOf(streamId));
            ChannelManager.responseCounter.incrementAndGet();
        } else {
            handleReadFailure(channel, future,
                    new IOException("Missing STREAM_ID header in http2 response."));
        }
    }

    private void handleHttp11Response(Channel channel, ResponseFuture<?> future, DefaultHttpContent defaultHttpContent) {
        DefaultHttpResponse defaultHttpResponse = future.getDefaultHttpResponse();
        LOGGER.debug("Receive HTTP 1.1 DefaultHttpContent");
        channel.pipeline().firstContext().executor().newPromise()
                .trySuccess(defaultHttpResponse);
        final HttpResponse httpResponse =
                new DefaultHttpResponse(defaultHttpResponse.protocolVersion(),
                        defaultHttpResponse.status());
        httpResponse.headers().set(defaultHttpResponse.headers());
        handleHttpResponse(httpResponse, channel, future);
        ByteBuf bb = defaultHttpContent.content();
        String actualString = bb.toString(0, bb.readableBytes(), StandardCharsets.UTF_8);
        handleHttpContent(Unpooled.wrappedBuffer(actualString.getBytes()), channel, future, -1);
    }

    @Override
    public void handleChannelInactive(ResponseFuture<?> future) {

    }

    @Override
    public void handleException(ResponseFuture<?> future, Throwable cause) {

    }

    private void handleHttpResponse(HttpResponse response, Channel channel,
                                    ResponseFuture<?> future) {
        AsyncHandler<?> asyncHandler = future.getAsyncHandler();
        LOGGER.debug("Handle httpResponse: {}", response);
        HttpRequest httpRequest = future.getNettyRequest().getHttpRequest();
        LOGGER.debug("Request: {} \n\nResponse: {}", httpRequest, response);
        future.setKeepAlive(config.isKeepAlive());
        handleHttpVersion(asyncHandler, response.protocolVersion());
        if (!interceptors.isExitAfterIntercept(channel, future, response)) {
            boolean abort = abortAfterHandlingStatusAndHeaders(asyncHandler, response.status(),
                    response.headers());
            LOGGER.debug("Check http Response abort: {}", abort);
            if (abort) {
                finishUpdate(future, channel, true);
            }
        }
    }

    private void handleHttpContent(ByteBuf content, Channel channel, ResponseFuture<?> future, int streamId) {
        AsyncHandler<?> asyncHandler = future.getAsyncHandler();
        LOGGER.debug("Handle httpContent");
        HttpResponsePartContent partContent =
                config.getResponseBodyPartFactory().newResponsePartContent(content, true);
        boolean abort = asyncHandler.onPartContentReceived(partContent) == AsyncHandler.State.ABORT;
        LOGGER.debug("Handle http content with abort: {}", abort);

        if (abort) {
            LOGGER.debug("Finish update with close: {}", true);
            finishUpdate(future, channel, true);
        } else {
            if (streamId > 0) {
                finishUpdate(future, channel, ChannelUtils.isStreamIdExceeded(streamId));
            } else {
                finishUpdate(future, channel, false);
            }
        }
    }

}

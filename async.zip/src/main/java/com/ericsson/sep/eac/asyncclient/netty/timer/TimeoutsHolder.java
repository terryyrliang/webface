/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */
package com.ericsson.sep.eac.asyncclient.netty.timer;

import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.util.Timeout;
import io.netty.util.Timer;
import io.netty.util.TimerTask;

import java.net.InetSocketAddress;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.currentMillisTime;

public class TimeoutsHolder {

    private final AtomicBoolean cancelled = new AtomicBoolean();
    private final Timeout requestTimeout;
    private final long requestTimeoutMilliSec;

    private final Timer nettyTimer;
    private final RequestSender requestSender;

    private final int readTimeoutValue;
    private volatile Timeout readTimeout;

    private final int upgradeTimeoutValue = 5000;
    private volatile Timeout upgradeTimeout;

    private volatile ResponseFuture<?> responseFuture;
    private volatile InetSocketAddress remoteAddress;

    public TimeoutsHolder(Timer nettyTimer, ResponseFuture<?> responseFuture,
        RequestSender requestSender, AsyncClientConfig config,
        InetSocketAddress originalRemoteAddress) {
        this.nettyTimer = nettyTimer;
        this.responseFuture = responseFuture;
        this.requestSender = requestSender;
        this.remoteAddress = originalRemoteAddress;

        final Request targetRequest = responseFuture.getTargetRequest();

        final int readTimeoutInMs = targetRequest.getReadTimeoutMilliSec();
        this.readTimeoutValue =
            readTimeoutInMs == 0 ? config.getReadTimeoutMilliSec() : readTimeoutInMs;

        int requestTimeoutInMs = targetRequest.getRequestTimeoutMilliSec();
        if (requestTimeoutInMs == 0) {
            requestTimeoutInMs = config.getRequestTimeoutMilliSec();
        }

        if (requestTimeoutInMs != -1) {
            requestTimeoutMilliSec = currentMillisTime() + requestTimeoutInMs;
            requestTimeout = newTimeout(
                new RequestTimeoutTimerTask(requestSender, this, responseFuture,
                    requestTimeoutInMs), requestTimeoutInMs);
        } else {
            requestTimeoutMilliSec = -1L;
            requestTimeout = null;
        }
    }

    public void setResolvedRemoteAddress(InetSocketAddress address) {
        remoteAddress = address;
    }

    InetSocketAddress remoteAddress() {
        return remoteAddress;
    }

    public void startReadTimeoutTask() {
        if (readTimeoutValue != -1) {
            startReadTimeoutTask(null);
        }
    }

    public void startUpgradeTimeoutTask() {
        if (upgradeTimeoutValue != -1) {
            startUpgradeTimeout(null);
        }
    }

    void startReadTimeoutTask(ReadTimeoutTimerTask task) {
        if (requestTimeout == null || (!requestTimeout.isExpired() && readTimeoutValue < (
            requestTimeoutMilliSec - currentMillisTime()))) {
            // only schedule a new readTimeout if the requestTimeout doesn't happen first
            if (task == null) {
                // first call triggered from outside (else is read timeout is re-scheduling itself)
                task =
                    new ReadTimeoutTimerTask(requestSender, this, responseFuture, readTimeoutValue);
            }
            this.readTimeout = newTimeout(task, readTimeoutValue);

        } else if (task != null) {
            // read timeout couldn't re-scheduling itself, clean up
            task.clean();
        }
    }

    void startUpgradeTimeout(Http2UpgradeTimeoutTimerTask task) {
        if (requestTimeout == null || (!requestTimeout.isExpired() && upgradeTimeoutValue < (
            requestTimeoutMilliSec - currentMillisTime()))) {
            if (task == null) {
                task = new Http2UpgradeTimeoutTimerTask(requestSender, this, responseFuture,
                    upgradeTimeoutValue);
            }
            this.upgradeTimeout = newTimeout(task, upgradeTimeoutValue);

        } else if (task != null) {
            task.clean();
        }
    }

    public void cancel() {
        if (cancelled.compareAndSet(false, true)) {
            if (requestTimeout != null) {
                requestTimeout.cancel();
                RequestTimeoutTimerTask.class.cast(requestTimeout.task()).clean();
            }
            if (readTimeout != null) {
                readTimeout.cancel();
                ReadTimeoutTimerTask.class.cast(readTimeout.task()).clean();
            }
        }
    }

    private Timeout newTimeout(TimerTask task, long delay) {
        return requestSender.isClosed() ?
            null :
            nettyTimer.newTimeout(task, delay, TimeUnit.MILLISECONDS);
    }
}

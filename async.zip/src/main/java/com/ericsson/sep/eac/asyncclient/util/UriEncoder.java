/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.util;

import com.ericsson.sep.eac.asyncclient.RequestParam;
import com.ericsson.sep.eac.asyncclient.common.StringBuilderPool;
import com.ericsson.sep.eac.asyncclient.uri.Uri;

import java.util.List;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;

public enum  UriEncoder {
    RAW {
        @Override
        protected String withQueryWithParams(String query, List<RequestParam> params) {
            StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
            sb.append(query);
            appendRawQueryParams(sb, params);
            sb.setLength(sb.length() - 1);
            return sb.toString();
        }

        @Override
        protected String withQueryWithoutParams(String query) {
            return query;
        }

        @Override
        protected String withoutQueryWithParams(List<RequestParam> params) {
            StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
            appendRawQueryParams(sb, params);
            sb.setLength(sb.length() - 1);
            return sb.toString();
        }

        public String encodePath(String path){
            return path;
        }

        protected void appendRawQueryParams(StringBuilder sb, List<RequestParam> params){
            params.forEach(param -> appendRawQueryParam(sb, param.getName(), param.getValue()));
        }

        private void appendRawQueryParam(StringBuilder sb, String key, String value){
            sb.append(key);
            if (isNonEmpty(value)){
                sb.append('=').append(value);
            }
            sb.append('&');
        }
    },
    ENDODE{
        @Override
        protected String withQueryWithParams(String query, List<RequestParam> params) {
            StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
            Utf8UrlEncoder.encodeAndAppendQuery(sb, query);
            sb.append('&');
            encodeAndAppendQueryParams(sb, params);
            sb.setLength(sb.length() - 1);
            return sb.toString();
        }

        @Override
        protected String withQueryWithoutParams(String query) {
            StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
            Utf8UrlEncoder.encodeAndAppendQuery(sb, query);
            return sb.toString();
        }

        @Override
        protected String withoutQueryWithParams(List<RequestParam> params) {
            StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
            encodeAndAppendQueryParams(sb, params);
            sb.setLength(sb.length() - 1);
            return sb.toString();
        }

        @Override
        protected String encodePath(String path) {
            return Utf8UrlEncoder.encodePath(path);
        }

        private void encodeAndAppendQueryParams(StringBuilder sb, final List<RequestParam> params){
            params.forEach(param -> encodeAndAppendQueryParam(sb, param.getName(), param.getValue()));
        }

        private void encodeAndAppendQueryParam(StringBuilder sb, final CharSequence name, final CharSequence value){
            Utf8UrlEncoder.encodeAndAppendFormElement(sb, name);
            if (value != null){
                sb.append('=');
                Utf8UrlEncoder.encodeAndAppendFormElement(sb, value);
            }
            sb.append('&');
        }
    };

    public static UriEncoder uriEncoder(boolean isDisableEncoding){
        return isDisableEncoding ? RAW : ENDODE;
    }

    public Uri encode(Uri uri, List<RequestParam> params){
        String newPath = encodePath(uri.getPath());
        String newQuery = encodeQuery(uri.getQuery(), params);
        return new Uri(uri.getScheme(), uri.getUserInfo(),
            uri.getHost(), uri.getPort(),
            newPath, newQuery, uri.getFragment(), uri.isHttp2(), uri.isHttp2PriorKnowledge());
    }

    protected abstract String withQueryWithParams(String query, List<RequestParam> params);

    protected abstract String withQueryWithoutParams(String query);

    protected abstract String withoutQueryWithParams(List<RequestParam> params);

    protected abstract String encodePath(String path);

    private String withQuery(String query, List<RequestParam> params){
        return isNonEmpty(params)? withQueryWithParams(query, params) : withQueryWithoutParams(query);
    }

    private String withoutQuery(List<RequestParam> params){
        return isNonEmpty(params) ? withoutQueryWithParams(params) : null;
    }

    private String encodeQuery(final String query, final List<RequestParam> params){
        return  (isNonEmpty(query)) ? withQuery(query, params) : withoutQuery(params);
    }


}

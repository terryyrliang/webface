/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.channel;

import io.netty.channel.Channel;

import java.util.Collections;
import java.util.Map;
import java.util.function.Predicate;

/**
 * @author emeezhg
 * @date 1/9/2019
 */
public enum NoopChannelPool implements ChannelPool {
    INSTANCE;

    @Override
    public boolean offer(Object partitionKey, Channel channel) {
        return false;
    }

    @Override
    public Channel poll(Object partitionKey) {
        return null;
    }

    @Override
    public boolean removeAll(Channel channel) {
        return false;
    }

    @Override
    public boolean isOpen() {
        return true;
    }

    @Override
    public void destroy() {

    }

    @Override
    public void flushPartitions(Predicate<Object> predicate) {

    }

    @Override
    public Map<String, Long> getIdleChannelCountPerHost() {
        return Collections.emptyMap();
    }
}

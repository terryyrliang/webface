/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;

import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.channel.*;
import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.AsyncClientBaseHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerUtils;
import com.ericsson.sep.eac.asyncclient.netty.channel.initializer.*;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.ssl.DefaultSslEngineFactory;
import com.ericsson.sep.eac.asyncclient.netty.ssl.SslEngineFactory;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.DefaultSslConfig;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.handler.codec.http.websocketx.WebSocket13FrameDecoder;
import io.netty.handler.codec.http.websocketx.WebSocket13FrameEncoder;
import io.netty.handler.codec.http.websocketx.WebSocketFrameAggregator;
import io.netty.handler.codec.http2.*;
import io.netty.handler.ssl.SslHandler;
import io.netty.util.Timer;
import io.netty.util.concurrent.*;
import org.slf4j.Logger;

import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.*;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public class ChannelManager {
    private static final Logger LOGGER = LogHelper.getLogger(ChannelManager.class);
    private final int KB = 1024;
    public static AtomicInteger nullCounter = new AtomicInteger(0);
    public static AtomicInteger responseCounter = new AtomicInteger(0);
    public static AtomicInteger sendCounter = new AtomicInteger(0);
    public static AtomicInteger initCounter = new AtomicInteger(0);

    private final AsyncClientConfig config;
    private final SslEngineFactory sslEngineFactory;


    private final EventLoopGroup eventLoopGroup;
    private final Bootstrap httpBootstrap;
    private final Bootstrap http2Bootstrap;
    private final Bootstrap http2cBootstrap;
    private final Bootstrap http2cDirectBootstrap;
    private final Bootstrap wsBootstrap;

    private final ChannelPool channelPool;
    private final ChannelGroup openChannels;

    private final SslConfig defaultSslConfig = new DefaultSslConfig.Builder().build();

    private AsyncClientBaseHandler wsHandler;

    private Http2cDirectClientInitializer http2cDirectClientInitializer;

    public ChannelManager(final AsyncClientConfig config, Timer timer) {
        this.config = config;
        this.sslEngineFactory = new DefaultSslEngineFactory();
        this.sslEngineFactory.init(config.getSslConfig());

        ChannelPool channelPool;
        if (config.isKeepAlive()) {
            if (config.isHttp2()) {
                LOGGER.info("Use Http2ChannelPool");
                channelPool = new Http2ChannelPool(this, config, timer);
//                channelPool = new DefaultChannelPool(config, timer);
            } else {
                channelPool = new DefaultChannelPool(config, timer);
            }
        } else {
            channelPool = NoopChannelPool.INSTANCE;
        }
        this.channelPool = channelPool;

        openChannels =
            new DefaultChannelGroup("ApiProxy-asyncClient", GlobalEventExecutor.INSTANCE);

        ChannelFactory<? extends Channel> channelFactory = NioSocketChannelFactory.INSTANCE;
        ThreadFactory threadFactory = new DefaultThreadFactory("tf-asyncClient");
        eventLoopGroup = new NioEventLoopGroup(config.getIoThreadsCount(), threadFactory);

        httpBootstrap = newBootstrap(channelFactory, eventLoopGroup, config);
        http2Bootstrap = newBootstrap(channelFactory, eventLoopGroup, config);
        http2cBootstrap = newBootstrap(channelFactory, eventLoopGroup, config);
        http2cDirectBootstrap = newBootstrap(channelFactory, eventLoopGroup, config);
        wsBootstrap = newBootstrap(channelFactory, eventLoopGroup, config);
    }

    public void configHttp2BootStrapBaseHandlers(RequestSender requestSender) {
        this.http2cDirectClientInitializer =
                new Http2cDirectClientInitializer(config, requestSender, this);
        http2cDirectBootstrap.handler(this.http2cDirectClientInitializer);
        LOGGER.debug("config h2cDirectBootstrap");
    }

    public void configBootStrapBaseHandlers(RequestSender requestSender) {
        HttpClientInitializer httpClientInitializer =
            new HttpClientInitializer(config, requestSender, this);
        httpBootstrap.handler(httpClientInitializer);
        LOGGER.debug("config httpBootstrap");

        WsClientInitializer wsClientInitializer =
            new WsClientInitializer(config, requestSender, this);
        wsBootstrap.handler(wsClientInitializer);
        wsHandler = wsClientInitializer.getWsHandler();
        LOGGER.debug("config wsBootstrap");

        Http2ClientInitializer http2ClientInitializer =
            new Http2ClientInitializer(config, requestSender, this);
        http2Bootstrap.handler(http2ClientInitializer);
        LOGGER.debug("config http2Bootstrap");

        Http2cClientInitializer h2cClientInitializer =
                    new Http2cClientInitializer(config, requestSender, this);
        http2cBootstrap.handler(h2cClientInitializer);
        LOGGER.debug("config h2cBootstrap");

        this.http2cDirectClientInitializer =
                new Http2cDirectClientInitializer(config, requestSender, this);
        http2cDirectBootstrap.handler(this.http2cDirectClientInitializer);
        LOGGER.debug("config h2cDirectBootstrap");
    }

    public void closeChannel(Channel channel) {
        LOGGER.debug("closing channel:{}", channel);
        ChannelUtils.setDiscard(channel);
        removeAll(channel);
        ChannelUtils.closeChannelSilently(channel);
    }

    public void shutdownGracefully() {
        eventLoopGroup.shutdownGracefully(config.getQuietPeriodMilliSec(),
            config.getShutdownTimeoutMilliSec(), TimeUnit.MILLISECONDS);
    }

    public void registerOpenChannel(Channel channel) {
        openChannels.add(channel);
    }

    public Future<Bootstrap> reConfigBootstrap(Request request) {
        LOGGER.debug("reConfig bootStrap");
        Uri uri = request.getUri();
        ProxyServer proxy = request.getProxyServer();

        final Promise<Bootstrap> promise = ImmediateEventExecutor.INSTANCE.newPromise();
        int connectionTimeout = getConnectionTimeoutMilliSec(request);

        if (uri.isWebSocket() && proxy == null) {
            wsBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeout);
            return promise.setSuccess(wsBootstrap);
        } else if (uri.isHttp2()) {
            return getBootstrapForH2(uri, promise, connectionTimeout);
        } else {
            httpBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeout);
            promise.setSuccess(httpBootstrap);
        }
        return promise;
    }

    private Future<Bootstrap> getBootstrapForH2(Uri uri, Promise<Bootstrap> promise,
        int connectionTimeout) {
        if (uri.isSecured()) {
            LOGGER.debug("re-config bootStrap for http2 with secure");
            http2Bootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeout);
            return promise.setSuccess(http2Bootstrap);
        } else {
            LOGGER.debug("re-config bootStrap for http2c");
            http2cBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeout);
            return promise.setSuccess(http2cBootstrap);
        }
    }

    public Bootstrap getBootstrapForH2(boolean isSecure, int connectionTimeout) {
        if (isSecure) {
            LOGGER.debug("re-config bootStrap for http2 with secure");
            http2Bootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeout);
            return http2Bootstrap;
        } else {
            LOGGER.debug("re-config bootStrap for http2c");
            http2cBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeout);
            return http2cBootstrap;
        }
    }

    public Bootstrap getHttp2cDirectBootstrap(int connectionTimeout) {
        LOGGER.debug("re-config direct bootStrap for http2c");
        http2cBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, connectionTimeout);
        return http2cDirectBootstrap;
    }

    public void removeAll(Channel channel) {
        channelPool.removeAll(channel);
    }

    public boolean isOpen() {
        return channelPool.isOpen();
    }


    public Channel fetch(Uri uri, String targetHost, ProxyServer proxyServer,
        ChannelPoolPartitioning channelPoolPartitioning) {
        Object partitionKey = channelPoolPartitioning.getPartitionKey(uri, targetHost, proxyServer);
        return channelPool.poll(partitionKey);
    }

    public void offerChannelToPool(Channel channel, AsyncHandler<?> asyncHandler, boolean keepAlive,
        Object partitionKey) {
        if (channel.isActive() && keepAlive) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("add key:{} for channel:{}", partitionKey, channel);
            }
            ChannelUtils.setDiscard(channel);

            try {
                asyncHandler.onConnectionOffer(channel);
            } catch (Exception e) {
                LOGGER.error("offer connection exception", e);
            }

            if (!channelPool.offer(partitionKey, channel)) {
                closeChannel(channel);
            }
        } else {
            closeChannel(channel);
        }
    }

    public Future<Channel> updatePipelineForProxyTunneling(ChannelPipeline pipeline, Uri requestUri,
        SslConfig sslConfigInRequest) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("update pipeline for http tunneling with uri:{}", requestUri);
        }
        Future<Channel> handshakePromise = null;

        if (pipeline.get(HTTP_CLIENT_CODEC) != null) {
            LOGGER.debug("remove {} handler", HTTP_CLIENT_CODEC);
            pipeline.remove(HTTP_CLIENT_CODEC);
        }

        boolean isHttp2 = requestUri.isHttp2();

        if (requestUri.isSecured()) {
            if (!isSslHandlerConfigured(pipeline)) {
                SslHandler sslHandler = createSslHandler(isHttp2, sslConfigInRequest);
                handshakePromise = sslHandler.handshakeFuture();
                pipeline.addFirst(SSL_HANDLER, sslHandler);
            }
            LOGGER.debug("add {} handler back", HTTP_CLIENT_CODEC);
            pipeline
                .addAfter(SSL_HANDLER, HTTP_CLIENT_CODEC, HandlerUtils.newHttpClientCodec(config));
        } else {
            //todo: for plain http2
            if (isHttp2) {
                LOGGER.warn("do nothing, since http2 proxy server is not support currently");
            } else {
                LOGGER.debug("add {} handler back for nonSecured request", HTTP_CLIENT_CODEC);
                pipeline.addBefore(ASY_HTTP_HANDLER, HTTP_CLIENT_CODEC,
                    HandlerUtils.newHttpClientCodec(config));
            }
        }

        if (requestUri.isWebSocket()) {
            pipeline.addAfter(ASY_HTTP_HANDLER, ASY_WS_HANDLER, wsHandler);
            pipeline.remove(ASY_HTTP_HANDLER);
        }
        return handshakePromise;
    }

    public boolean handlerExist(ChannelPipeline pipeline, String handlerName) {
        return pipeline.get(handlerName) != null;
    }

    public void removeHandlerByName(ChannelPipeline pipeline, String handlerName) {
        if (handlerExist(pipeline, handlerName)) {
            pipeline.remove(handlerName);
        }
    }

    public void updatePipelineForH2cPriorKnowledge(ChannelPipeline pipeline){
        removeHandlerByName(pipeline, HTTP_CLIENT_CODEC);
        removeHandlerByName(pipeline, H2_UPGRADE);
        LOGGER.debug("init channel for h2c");
        ChannelHandler lastHandler = new ChannelInboundHandlerAdapter() {
            @Override
            public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
                if (evt instanceof Http2ConnectionPrefaceAndSettingsFrameWrittenEvent) {
                    LOGGER.debug("trigger here");
                    ctx.pipeline().remove(this);
                }
            }
        };
        pipeline.addBefore(ASY_H2_HANDLER, HTTP2_CONN_HANDLER, newHttp2ConnectionHandler());
        pipeline.addBefore(ASY_H2_HANDLER, null, lastHandler);
    }

    private Http2ConnectionHandler newHttp2ConnectionHandler() {
        final DefaultHttp2Connection connection = new DefaultHttp2Connection(false);
        final InboundHttp2ToHttpAdapter adapter = new InboundHttp2ToHttpAdapterBuilder(connection)
            .maxContentLength(config.getResponseMaxContentLengthKB() * KB)
            .build();
        final DelegatingDecompressorFrameListener frameListener =
            new DelegatingDecompressorFrameListener(connection, adapter);
        return new Http2ConnectionHandlerBuilder()
            .frameListener(frameListener)
            .connection(connection)
            .build();
    }

    public SslHandler createSslHandler(boolean isHttp2, SslConfig sslConfigInRequest) {
        SSLEngine sslEngine;
        SslConfig sslConfigInClient = config.getSslConfig();
        SslConfig sslConfig = sslConfigInRequest == null ? sslConfigInClient : sslConfigInRequest;
        if (sslConfigInClient != null && sslConfigInRequest != null) {
            sslConfigInRequest.copyFrom(sslConfigInClient);
        }

        if (sslConfig == null) {
            sslConfig = defaultSslConfig;
        }

        try {
            if (isHttp2) {
                sslEngine = sslEngineFactory.newH2SslEngine(sslConfig);
            } else {
                sslEngine = sslEngineFactory.newSslEngine(sslConfig);
            }
        } catch (SSLException e) {
            throw new RuntimeException("Could not initialize sslEngineFactory", e);
        }
        SslHandler sslHandler = new SslHandler(sslEngine);
        int handshakeTimeout = sslConfig.getHandshakeTimeoutMilliSec();
        if (handshakeTimeout > 0) {
            sslHandler.setHandshakeTimeoutMillis(handshakeTimeout);
        }
        return sslHandler;
    }

    public SslHandler addSslHandler(ChannelPipeline pipeline, boolean isHttp2,
        SslConfig sslConfigInRequest) {
        SslHandler sslHandler = createSslHandler(isHttp2, sslConfigInRequest);
        LOGGER.debug("add sslHandler:{} with uri isHttp2:{}", sslHandler, isHttp2);
        pipeline.addFirst(SSL_HANDLER, sslHandler);

        return sslHandler;
    }

    public boolean ifUpgradeSuccess(Channel channel) {
        return "yes".equals(channel.attr(AsyncConstants.UPGRADE_SUCCESSFUL_ATTR).get());
    }

    public void upgradePipelineForWebSocket(ChannelPipeline pipeline) {
        pipeline.addAfter(HTTP_CLIENT_CODEC, WS_ENCODER_HANDLER, new WebSocket13FrameEncoder(true));
        pipeline.addAfter(WS_ENCODER_HANDLER, WS_DECODER_HANDLER,
            new WebSocket13FrameDecoder(false, true, config.getWebSocketMaxFrameSizeKB() * KB));
        pipeline.addAfter(WS_DECODER_HANDLER, WS_FRAME_AGGREGATOR,
            new WebSocketFrameAggregator(config.getResponseMaxContentLengthKB() * KB));
        pipeline.remove(HTTP_CLIENT_CODEC);
    }

    private Bootstrap newBootstrap(ChannelFactory<? extends Channel> channelFactory,
        EventLoopGroup eventLoopGroup, AsyncClientConfig config) {

        return new Bootstrap().channelFactory(channelFactory).group(eventLoopGroup)
            .option(ChannelOption.SO_KEEPALIVE, config.isSoReuseAddress())
            .option(ChannelOption.TCP_NODELAY, config.isTcpNoDelay())
            .option(ChannelOption.SO_REUSEADDR, config.isSoReuseAddress())
            .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, config.getConnectionTimeoutMilliSec());
    }

    private int getConnectionTimeoutMilliSec(Request request) {
        int connectionTimeoutInRequest = request.getConnectionTimeoutMilliSec();
        int connectionTimeOutInConfig = config.getConnectionTimeoutMilliSec();
        if (connectionTimeoutInRequest > 0
            && connectionTimeOutInConfig != connectionTimeoutInRequest) {
            return connectionTimeoutInRequest;
        }
        return connectionTimeOutInConfig;
    }

    private static boolean isSslHandlerConfigured(ChannelPipeline pipeline) {
        return pipeline.get(SSL_HANDLER) != null;
    }

    public Http2cDirectClientInitializer getHttp2cDirectClientInitializer() {
        return http2cDirectClientInitializer;
    }

    public ChannelPool getChannelPool() {
        return channelPool;
    }
}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler.interceptor;

import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.RequestBuilder;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.channel.Channel;
import io.netty.util.concurrent.Future;
import org.slf4j.Logger;



/**
 * @author emeezhg
 * @date 12/21/2018
 */
public class Connect200Interceptor {
    private static final Logger LOGGER = LogHelper.getLogger(Connect200Interceptor.class);

    private final ChannelManager channelManager;
    private final RequestSender requestSender;

    public Connect200Interceptor(ChannelManager channelManager, RequestSender requestSender) {
        this.channelManager = channelManager;
        this.requestSender = requestSender;
    }

    public boolean isExitAfterHandlingConnect(final Channel channel,
        final ResponseFuture<?> future) {
        ProxyServer proxyServer = future.getProxyServer();
        Request request = future.getCurrentRequest();
        if (future.isKeepAlive()) {
            future.attachChannel(channel, true);
        }
        future.setReuseChannel(true);
        future.setConnectAllowed(false);

        Uri requestUri = request.getUri();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Connecting to proxy {} for {}", proxyServer, requestUri);
        }

        Future<Channel> handshakePromise =
            channelManager.updatePipelineForProxyTunneling(channel.pipeline(), requestUri, future.getSslConfigInRequest());

        Request newRequest = new RequestBuilder(future.getTargetRequest()).build();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("CONNECT 200 construct a new request:{} ", newRequest);
        }
        requestSender.getChannelAndExecNextRequest(channel, future, newRequest, handshakePromise);
        return true;
    }

}

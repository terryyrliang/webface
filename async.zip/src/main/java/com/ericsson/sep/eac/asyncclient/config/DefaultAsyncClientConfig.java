/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.config;


import com.ericsson.sep.eac.asyncclient.HttpResponsePartContentFactory;
import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public class DefaultAsyncClientConfig implements AsyncClientConfig{
    // shutdown
    private final int quietPeriodMilliSec;
    private final int shutdownTimeoutMilliSec;

    // http
    private final boolean isValidateResponseHeaders;
    private final int responseMaxContentLengthKB;

    // websocket
    private final int webSocketMaxFrameSizeKB;

    // keep alive
    private final int maxConnections;
    private final int maxConnectionsPerHost;
    private final boolean isKeepAlive;
    private final int obtainFreeChannelTimeoutMilliSec;

    private final int pooledConnectionTtlMilliSec;
    private final int pooledConnectionIdleTimeoutMilliSec;
    private final int pooledConnectionClearPeriodMilliSec;


    // timeout
    private final int connectionTimeoutMilliSec;
    private final int readTimeoutMilliSec;
    private final int requestTimeoutMilliSec;

    // ssl
    private final SslConfig sslConfig;

    // tunning
    private final boolean isTcpNoDelay;
    private final boolean isSoReuseAddress;

    // internal
    private final int ioThreadsCount;
    private final int maxInitialLineLength;
    private final int maxHeaderSize;
    private final int maxChunkSize;
    private final int initialBufferSize;

    private boolean isHttp2;
    private boolean isHttp2PriorKnowledge;

    // direct h2c
    private float windowUpdateRatio = AsyncConstants.DEFAULT_WINDOW_UPDATE_RATIO;
    private int initialFlowControlWindowUpdate = AsyncConstants.DEFAULT_INIT_FLOW_CONTROL_WINDOW_UPDATE;
    private int http2ChannelPerHost = AsyncConstants.DEFAULT_HTTP2_CHANNEL_PER_HOST;

    private final HttpResponsePartContentFactory responsePartContentFactory;

    public DefaultAsyncClientConfig(
            // shutdown
            int quietPeriodMilliSec,
            int shutdownTimeoutMilliSec,
            // http
            boolean isValidateResponseHeaders,
            int responseMaxContentLengthKB,
            // ws
            int webSocketMaxFrameSizeKB,
            // keep alive
            int maxConnections,
            int maxConnectionsPerHost,
            boolean isKeepAlive,
            int obtainFreeChannelTimeoutMilliSec,
            // timeout
            int connectionTimeoutMilliSec,
            int readTimeoutMilliSec,
            int requestTimeoutMilliSec,
            int pooledConnectionTtlMilliSec,
            int pooledConnectionIdleTimeoutMilliSec,
            int pooledConnectionClearPeriodMilliSec,
            // tls
            SslConfig sslConfig,
            // tuning
            boolean isTcpNoDelay,
            boolean isSoReuseAddress,
            // internal
            int ioThreadsCount,
            int maxInitialLineLength,
            int maxHeaderSize,
             int maxChunkSize,
            int initialBufferSize,
            boolean isHttp2,
            boolean isHttp2PriorKnowledge,
            // direct h2c
            float windowUpdateRatio,
            int initialFlowControlWindowUpdate,
            int http2ChannelPerHost,
            HttpResponsePartContentFactory responsePartContentFactory) {
        // shutdown
        this.quietPeriodMilliSec = quietPeriodMilliSec;
        this.shutdownTimeoutMilliSec = shutdownTimeoutMilliSec;
        // http
        this.isValidateResponseHeaders = isValidateResponseHeaders;
        this.responseMaxContentLengthKB = responseMaxContentLengthKB;
        // ws
        this.webSocketMaxFrameSizeKB = webSocketMaxFrameSizeKB;
        // keep-alive
        this.maxConnections = maxConnections;
        this.maxConnectionsPerHost = maxConnectionsPerHost;
        this.isKeepAlive = isKeepAlive;
        this.obtainFreeChannelTimeoutMilliSec = obtainFreeChannelTimeoutMilliSec;

        this.pooledConnectionTtlMilliSec = pooledConnectionTtlMilliSec;
        this.pooledConnectionIdleTimeoutMilliSec = pooledConnectionIdleTimeoutMilliSec;
        this.pooledConnectionClearPeriodMilliSec = pooledConnectionClearPeriodMilliSec;
        // timeout
        this.connectionTimeoutMilliSec = connectionTimeoutMilliSec;
        this.readTimeoutMilliSec = readTimeoutMilliSec;
        this.requestTimeoutMilliSec = requestTimeoutMilliSec;
        // tls
        this.sslConfig = sslConfig;
//        this.isUseOpenSsl = isUseOpenSsl;
//        this.isAllowInsecureConnection = isAllowInsecureConnection;
//        this.privateKeyFile = privateKeyFile;
//        this.certificateFile = certificateFile;
//        this.keyPassword = keyPassword;
//        this.trustCertCollectionPemFile = trustCertCollectionPemFile;
//        this.handshakeTimeoutMilliSec = handshakeTimeoutMilliSec;
//        this.tlsSessionCacheSize = tlsSessionCacheSize;
//        this.tlsSessionTimeoutMilliSec = tlsSessionTimeoutMilliSec;
        // tuning
        this.isTcpNoDelay = isTcpNoDelay;
        this.isSoReuseAddress = isSoReuseAddress;
        // internal
        this.ioThreadsCount = ioThreadsCount;
        this.maxInitialLineLength = maxInitialLineLength;
        this.maxHeaderSize = maxHeaderSize;
        this.maxChunkSize = maxChunkSize;
        this.initialBufferSize = initialBufferSize;
        this.isHttp2 = isHttp2;
        this.isHttp2PriorKnowledge = isHttp2PriorKnowledge;
        this.windowUpdateRatio = windowUpdateRatio;
        this.initialFlowControlWindowUpdate = initialFlowControlWindowUpdate;
        this.http2ChannelPerHost = http2ChannelPerHost;

        this.responsePartContentFactory = responsePartContentFactory;
    }

    @Override
    public int getIoThreadsCount() {
        return ioThreadsCount;
    }

    @Override
    public int getMaxConnections() {
        return maxConnections;
    }

    @Override
    public int getMaxConnectionPerHost() {
        return maxConnectionsPerHost;
    }

    @Override
    public int getConnectionTimeoutMilliSec() {
        return connectionTimeoutMilliSec;
    }

    @Override
    public int getReadTimeoutMilliSec() {
        return readTimeoutMilliSec;
    }

    @Override
    public int getRequestTimeoutMilliSec() {
        return requestTimeoutMilliSec;
    }

    @Override
    public boolean isKeepAlive() {
        return isKeepAlive;
    }

    @Override
    public int getObtainFreeChannelTimeoutMilliSec() {
        return obtainFreeChannelTimeoutMilliSec;
    }

    @Override
    public boolean isTcpNoDelay() {
        return isTcpNoDelay;
    }

    @Override
    public boolean isSoReuseAddress() {
        return isSoReuseAddress;
    }

    @Override
    public int getMaxInitLineLength() {
        return maxInitialLineLength;
    }

    @Override
    public int getMaxHeaderSize() {
        return maxHeaderSize;
    }

    @Override
    public int getMaxChunkSize() {
        return maxChunkSize;
    }

    @Override
    public boolean isValidateResponseHeaders() {
        return isValidateResponseHeaders;
    }

    @Override
    public int getWebSocketMaxFrameSizeKB() {
        return webSocketMaxFrameSizeKB;
    }

    @Override
    public int getInitBufferSize() {
        return initialBufferSize;
    }

    @Override
    public int getResponseMaxContentLengthKB() {
        return responseMaxContentLengthKB;
    }

    @Override
    public SslConfig getSslConfig() {
        return sslConfig;
    }

    @Override
    public int getPooledConnectionTtlMilliSec() {
        return pooledConnectionTtlMilliSec;
    }

    @Override
    public int getPooledConnectionIdleTimeoutMilliSec() {
        return pooledConnectionIdleTimeoutMilliSec;
    }

    @Override
    public int getPooledConnectionClearPeriodMilliSec() {
        return pooledConnectionClearPeriodMilliSec;
    }

    @Override
    public int getQuietPeriodMilliSec() {
        return quietPeriodMilliSec;
    }

    @Override
    public int getShutdownTimeoutMilliSec() {
        return shutdownTimeoutMilliSec;
    }

    @Override
    public boolean isHttp2() {
        return isHttp2;
    }

    public void setHttp2(boolean http2) {
        isHttp2 = http2;
    }

    public boolean isHttp2PriorKnowledge() {
        return isHttp2PriorKnowledge;
    }

    public void setHttp2PriorKnowledge(boolean http2PriorKnowledge) {
        isHttp2PriorKnowledge = http2PriorKnowledge;
    }

    @Override
    public Float getWindowUpdateRatio() {
        return this.windowUpdateRatio;
    }

    @Override
    public Integer getInitialFlowControlWindowUpdate() {
        return this.initialFlowControlWindowUpdate;
    }

    @Override
    public int getHttp2ChannelPerHost() {
        return http2ChannelPerHost;
    }

    @Override
    public HttpResponsePartContentFactory getResponseBodyPartFactory() {
        return responsePartContentFactory;
    }

    public static class Builder {
        // shutdown
        private int quietPeriodMilliSec = 30000;
        private int shutdownTimeoutMilliSec = 30000;
        // http
        private boolean isValidateResponseHeaders = false;
        private int responseMaxContentLengthKB = 8;

        // ws
        private int webSocketMaxFrameSizeKB = 8;

        // keep alive
        private int maxConnections = 5000;
        private int maxConnectionsPerHost = 50;
        private boolean isKeepAlive = true;
        int obtainFreeChannelTimeoutMilliSec = 10000;
        private int pooledConnectionTtlMilliSec = 30000;
        private int pooledConnectionIdleTimeoutMilliSec = 30000;
        private int pooledConnectionClearPeriodMilliSec = 30000;

        // timeout
        private int connectionTimeoutMilliSec = 30000;
        private int readTimeoutMilliSec = 30000;
        private int requestTimeoutMilliSec = 30000;

        // ssl
        private SslConfig sslConfig = null;

        // tunning
        private boolean isTcpNoDelay = true;
        private boolean isSoReuseAddress = true;

        // internal
        private int ioThreadsCount = 5;
        private int maxInitialLineLength = 4096;
        private int maxHeaderSize = 8192;
        private int maxChunkSize = 8192;
        private int initialBufferSize = 8192;

        private boolean isHttp2;
        private boolean isHttp2PriorKnowledge;

        // direct h2c
        private float windowUpdateRatio = AsyncConstants.DEFAULT_WINDOW_UPDATE_RATIO;
        private int initialFlowControlWindowUpdate = AsyncConstants.DEFAULT_INIT_FLOW_CONTROL_WINDOW_UPDATE;
        private int http2ChannelPerHost = AsyncConstants.DEFAULT_HTTP2_CHANNEL_PER_HOST;

        private HttpResponsePartContentFactory responsePartContentFactory = HttpResponsePartContentFactory.EAGER;

        public Builder(){
        }

        public Builder(AsyncClientConfig config){
            // shutdown
            quietPeriodMilliSec = config.getQuietPeriodMilliSec();
            shutdownTimeoutMilliSec = config.getShutdownTimeoutMilliSec();
            // http
            isValidateResponseHeaders = config.isValidateResponseHeaders();
            responseMaxContentLengthKB = config.getResponseMaxContentLengthKB();
            // ws
            webSocketMaxFrameSizeKB = config.getWebSocketMaxFrameSizeKB();

            //keep alive
            maxConnections = config.getMaxConnections();
            maxConnectionsPerHost = config.getMaxConnectionPerHost();
            isKeepAlive = config.isKeepAlive();
            obtainFreeChannelTimeoutMilliSec = config.getObtainFreeChannelTimeoutMilliSec();

            pooledConnectionTtlMilliSec = config.getPooledConnectionTtlMilliSec();
            pooledConnectionIdleTimeoutMilliSec = config.getPooledConnectionIdleTimeoutMilliSec();
            pooledConnectionClearPeriodMilliSec = config.getPooledConnectionClearPeriodMilliSec();

            // timeout
            connectionTimeoutMilliSec = config.getConnectionTimeoutMilliSec();
            readTimeoutMilliSec = config.getReadTimeoutMilliSec();
            requestTimeoutMilliSec = config.getRequestTimeoutMilliSec();

            // ssl
            sslConfig = config.getSslConfig();

            // tuning
            isTcpNoDelay = config.isTcpNoDelay();
            isSoReuseAddress = config.isSoReuseAddress();

            // internal
            ioThreadsCount = config.getIoThreadsCount();
            maxInitialLineLength = config.getMaxInitLineLength();
            maxHeaderSize = config.getMaxHeaderSize();
            maxChunkSize = config.getMaxChunkSize();
            initialBufferSize = config.getInitBufferSize();

            isHttp2 = config.isHttp2();
            isHttp2PriorKnowledge = config.isHttp2PriorKnowledge();

            windowUpdateRatio = config.getWindowUpdateRatio();
            initialFlowControlWindowUpdate = config.getInitialFlowControlWindowUpdate();
            http2ChannelPerHost = config.getHttp2ChannelPerHost();

            responsePartContentFactory = config.getResponseBodyPartFactory();
        }

        public Builder setQuietPeriodMilliSec(int quietPeriodMilliSec) {
            this.quietPeriodMilliSec = quietPeriodMilliSec;
            return this;
        }

        public Builder setShutdownTimeoutMilliSec(int shutdownTimeoutMilliSec) {
            this.shutdownTimeoutMilliSec = shutdownTimeoutMilliSec;
            return this;
        }

        public Builder setValidateResponseHeaders(boolean validateResponseHeaders) {
            this.isValidateResponseHeaders = validateResponseHeaders;
            return this;
        }

        public Builder setResponseMaxContentLengthKB(int responseMaxContentLengthKB) {
            this.responseMaxContentLengthKB = responseMaxContentLengthKB;
            return this;
        }

        public Builder setWebSocketMaxFrameSizeKB(int webSocketMaxFrameSizeKB) {
            this.webSocketMaxFrameSizeKB = webSocketMaxFrameSizeKB;
            return this;
        }

        public Builder setMaxConnections(int maxConnections) {
            this.maxConnections = maxConnections;
            return this;
        }

        public Builder setMaxConnectionsPerHost(int maxConnectionsPerHost) {
            this.maxConnectionsPerHost = maxConnectionsPerHost;
            return this;
        }

        public Builder setKeepAlive(boolean keepAlive) {
            isKeepAlive = keepAlive;
            return this;
        }

        public Builder setObtainFreeChannelTimeoutMilliSec(int obtainFreeChannelTimeoutMilliSec) {
            this.obtainFreeChannelTimeoutMilliSec = obtainFreeChannelTimeoutMilliSec;
            return this;
        }

        public Builder setConnectionTimeoutMilliSec(int connectionTimeoutMilliSec) {
            this.connectionTimeoutMilliSec = connectionTimeoutMilliSec;
            return this;
        }

        public Builder setReadTimeoutMilliSec(int readTimeoutMilliSec) {
            this.readTimeoutMilliSec = readTimeoutMilliSec;
            return this;
        }

        public Builder setRequestTimeoutMilliSec(int requestTimeoutMilliSec) {
            this.requestTimeoutMilliSec = requestTimeoutMilliSec;
            return this;
        }

        public void setSslConfig(SslConfig sslConfig) {
            this.sslConfig = sslConfig;
        }

        public Builder setTcpNoDelay(boolean tcpNoDelay) {
            isTcpNoDelay = tcpNoDelay;
            return this;
        }

        public Builder setSoReuseAddress(boolean soReuseAddress) {
            isSoReuseAddress = soReuseAddress;
            return this;
        }

        public Builder setIoThreadsCount(int ioThreadsCount) {
            this.ioThreadsCount = ioThreadsCount;
            return this;
        }

        public Builder setMaxInitialLineLength(int maxInitialLineLength) {
            this.maxInitialLineLength = maxInitialLineLength;
            return this;
        }

        public Builder setMaxHeaderSize(int maxHeaderSize) {
            this.maxHeaderSize = maxHeaderSize;
            return this;
        }

        public Builder setMaxChunkSize(int maxChunkSize) {
            this.maxChunkSize = maxChunkSize;
            return this;
        }

        public Builder setInitialBufferSize(int initialBufferSize) {
            this.initialBufferSize = initialBufferSize;
            return this;
        }

        public Builder setPooledConnectionTtlMilliSec(int pooledConnectionTtlMilliSec) {
            this.pooledConnectionTtlMilliSec = pooledConnectionTtlMilliSec;
            return this;
        }

        public Builder setPooledConnectionIdleTimeoutMilliSec(int pooledConnectionIdleTimeoutMilliSec) {
            this.pooledConnectionIdleTimeoutMilliSec = pooledConnectionIdleTimeoutMilliSec;
            return this;
        }

        public Builder setPooledConnectionClearPeriodMilliSec(int pooledConnectionClearPeriodMilliSec) {
            this.pooledConnectionClearPeriodMilliSec = pooledConnectionClearPeriodMilliSec;
            return this;
        }

        public Builder setResponsePartContentFactory(
            HttpResponsePartContentFactory responsePartContentFactory) {
            this.responsePartContentFactory = responsePartContentFactory;
            return this;
        }

        public Builder setHttp2(boolean http2) {
            this.isHttp2 = http2;
            return this;
        }

        public Builder setHttp2PriorKnowledge(boolean http2PriorKnowledge) {
            isHttp2PriorKnowledge = http2PriorKnowledge;
            return this;
        }

        public Builder setWindowUpdateRatio(float windowUpdateRatio) {
            this.windowUpdateRatio = windowUpdateRatio;
            return this;
        }

        public Builder setInitialFlowControlWindowUpdate(int initialFlowControlWindowUpdate) {
            this.initialFlowControlWindowUpdate = initialFlowControlWindowUpdate;
            return this;
        }

        public Builder setHttp2ChannelPerHost(int http2ChannelPerHost) {
            this.http2ChannelPerHost = http2ChannelPerHost;
            return this;
        }

        public DefaultAsyncClientConfig build(){
            return new DefaultAsyncClientConfig(
                // shutdown
                quietPeriodMilliSec,
                shutdownTimeoutMilliSec,
                // http
                isValidateResponseHeaders,
                responseMaxContentLengthKB,

                // ws
                webSocketMaxFrameSizeKB,

                //keep alive
                maxConnections,
                maxConnectionsPerHost,
                isKeepAlive,
                obtainFreeChannelTimeoutMilliSec,

                pooledConnectionTtlMilliSec,
                pooledConnectionIdleTimeoutMilliSec,
                pooledConnectionClearPeriodMilliSec,

                // timeout
                connectionTimeoutMilliSec,
                readTimeoutMilliSec,
                requestTimeoutMilliSec,

                // ssl
                sslConfig,

                // tuning
                isTcpNoDelay,
                isSoReuseAddress,

                // internal
                ioThreadsCount,
                maxInitialLineLength,
                maxHeaderSize,
                maxChunkSize,
                initialBufferSize,
                    isHttp2,
                isHttp2PriorKnowledge,
                windowUpdateRatio,
                initialFlowControlWindowUpdate,
                http2ChannelPerHost,
                responsePartContentFactory
                    );
        }
    }
}

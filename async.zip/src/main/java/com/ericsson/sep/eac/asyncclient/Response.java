/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */
package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http.cookie.Cookie;

import java.io.InputStream;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents the asynchronous HTTP response callback
 */
public interface Response {
    /**
     * @return the httpVersion returned from backend end
     */
    String getHttpVersion();

    /**
     * Returns the status code for the request.
     *
     * @return The status code
     */
    int getStatusCode();

    /**
     * customize statusCode of the response
     *
     * @param statusCode
     */
    void setStatusCode(int statusCode);

    /**
     * @return the reason phase
     * example: newStatus(404, "Not Found")
     */
    String getReasonPhase();

    /**
     * customized reason phase of the response
     *
     * @param reasonPhase
     */
    void setReasonPhase(String reasonPhase);

    /**
     * set response entity
     *
     * @param stream
     */
    void setEntity(InputStream stream);

    /**
     * Return the entire response body as a byte[].
     *
     * @return the entire response body as a byte[].
     */
    byte[] getResponseBodyAsBytes();

    /**
     * @return the entire response body as ByteBuffer
     */
    ByteBuffer getResponseBodyAsByteBuffer();

    /**
     * Return the entire response body as a ByteBuf.
     *
     * @return the entire response body as a ByteBuf.
     */
    ByteBuf getResponseBodyAsByteBuf();

    /**
     * Returns an input stream for the response body. Note that you should not try to get this more than once, and that you should not close the stream.
     *
     * @return The input stream
     */
    InputStream getResponseBodyAsStream();

    /**
     * Return the entire response body as a String.
     *
     * @param charset the charset to use when decoding the stream
     * @return the entire response body as a String.
     */
    String getResponseBody(Charset charset);

    /**
     * Return the entire response body as a String.
     *
     * @return the entire response body as a String.
     */
    String getResponseBody();

    /**
     * Return the request {@link Uri}. Note that if the request got redirected, the value of the {@link Uri} will be the last valid redirect url.
     *
     * @return the request {@link Uri}.
     */
    Uri getUri();

    /**
     * Return the content-type header value.
     *
     * @return the content-type header value.
     */
    String getContentType();

    /**
     * @param name the header name
     * @return the first response header value
     */
    String getHeader(CharSequence name);

    /**
     * Return a {@link List} of the response header value.
     *
     * @param name the header name
     * @return the response header value
     */
    List<String> getHeaders(CharSequence name);

    HttpHeaders getHeaders();

    /**
     * Return true if the response redirects to another object.
     *
     * @return True if the response redirects to another object.
     */
    boolean isRedirected();

    /**
     * Subclasses SHOULD implement toString() in a way that identifies the response for logging.
     *
     * @return the textual representation
     */
    String toString();

    /**
     * @return the list of {@link Cookie}.
     */
    List<Cookie> getCookies();

    boolean hasResponseStatus();

    boolean hasResponseHeaders();

    boolean hasResponseBody();

    /**
     * Get the remote address that the client initiated the request to.
     *
     * @return The remote address that the client initiated the request to. May be {@code null} if asynchronous provider is unable to provide the remote address
     */
    SocketAddress getRemoteAddress();

    /**
     * Get the local address that the client initiated the request from.
     *
     * @return The local address that the client initiated the request from. May be {@code null} if asynchronous provider is unable to provide the local address
     */
    SocketAddress getLocalAddress();

    class ResponseBuilder {
        private final List<HttpResponsePartContent> contentParts = new ArrayList<HttpResponsePartContent>(1);
        private HttpVersion httpVersion;
        private HttpResponseStatus status;
        private HttpHeaders headers;

        public void accumulate(HttpVersion httpVersion) {
            this.httpVersion = httpVersion;
        }

        public void accumulate(HttpResponseStatus status) {
            this.status = status;
        }

        public void accumulate(HttpHeaders headers) {
            this.headers = this.headers == null ? headers : this.headers.add(headers);
        }

        /**
         * @param partContent a body part (possibly empty, but will be filtered out)
         */
        public void accumulate(HttpResponsePartContent partContent) {
            if (partContent.length() > 0)
                contentParts.add(partContent);
        }

        /**
         * Build a {@link Response} instance
         *
         * @return a {@link Response} instance
         */
        public Response build() {
            if (httpVersion == null) {
                httpVersion = HttpVersion.HTTP_1_1;
            }
            return status == null ?
                null :
                new NettyResponse(httpVersion, status, headers, contentParts);
        }

        /**
         * Reset the internal state of this builder.
         */
        public void reset() {
            contentParts.clear();
            status = null;
            headers = null;
        }
    }
}

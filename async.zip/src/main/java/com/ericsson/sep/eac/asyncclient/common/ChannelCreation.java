package com.ericsson.sep.eac.asyncclient.common;

public class ChannelCreation {
    public final long creationTime;
    public final Object partitionKey;

    public ChannelCreation(long creationTime, Object partitionKey) {
        this.creationTime = creationTime;
        this.partitionKey = partitionKey;
    }
}

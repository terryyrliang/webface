/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.ws;

import com.ericsson.sep.eac.asyncclient.HttpResponsePartContent;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.ws.NettyWebSocket;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;

import java.util.ArrayList;
import java.util.List;

public class WebSocketUpgradeHandler implements AsyncHandler<NettyWebSocket> {
    private final List<WebSocketListener> webSocketListeners;
    private NettyWebSocket webSocket;

    public WebSocketUpgradeHandler(List<WebSocketListener> webSocketListeners) {
        this.webSocketListeners = webSocketListeners;
    }

    @Override
    public State onHttpVersionReceived(HttpVersion httpVersion) {
        return State.CONTINUE;
    }

    @Override
    public State onStatusReceived(HttpResponseStatus status) {
        return status.code() == HttpResponseStatus.SWITCHING_PROTOCOLS.code() ?
            State.CONTINUE :
            State.ABORT;
    }

    @Override
    public State onHeadersReceived(HttpHeaders headers) {
        return State.CONTINUE;
    }

    @Override
    public State onPartContentReceived(HttpResponsePartContent partContent) {
        return State.CONTINUE;
    }

    @Override
    public void onThrowable(Throwable t) {
        webSocketListeners.forEach(listener -> {
            if (webSocket != null) {
                webSocket.addWebSocketListener(listener);
            }
            listener.onError(t);
        });
    }

    @Override
    public NettyWebSocket onCompleted() {
        return webSocket;
    }

    public final void setWebSocket(NettyWebSocket webSocket) {
        this.webSocket = webSocket;

    }

    public void onOpen() {
        webSocketListeners.forEach(listener -> {
            webSocket.addWebSocketListener(listener);
            listener.onOpen(webSocket);
        });
        webSocket.processBufferedFrames();
    }

    public final static class Builder {
        private List<WebSocketListener> listeners = new ArrayList<>(1);

        public Builder addListener(WebSocketListener listener) {
            listeners.add(listener);
            return this;
        }

        public Builder removeListener(WebSocketListener listener) {
            listeners.remove(listener);
            return this;
        }

        public WebSocketUpgradeHandler build() {
            return new WebSocketUpgradeHandler(listeners);
        }
    }

}

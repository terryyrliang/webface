/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.channel.ChannelPoolPartitioning;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.resolver.NameResolver;

import java.io.InputStream;
import java.net.InetAddress;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;

/**
 * @author emeezhg
 * @date 1/10/2019
 */
public interface Request{

    /**
     * @return http request protocol
     */
    String getProtocol();

    /**
     * @return the request HTTP Method
     */
    String getMethod();

    /**
     * @return the HTTP headers
     */
    HttpHeaders getHeaders();

    /**
     * @return the request's body inputStream
     */
    InputStream getStreamData();

    /**
     * @return the request's form parameters
     */
    List<RequestParam> getFormParams();

    /**
     * @return query params from url
     */
    List<RequestParam> getQueryParams();

    /**
     * @return the uri
     */
    Uri getUri();

    /**
     * @return the string of the uri
     */
    String getUrl();

    /**
     * @return the InetAddress to be used to bypass the uri's home resolution
     */
    InetAddress getAddress();

    /**
     * @return the local address to bind from
     */
    InetAddress getLocalAddress();

    /**
     * @return the target host to connect
     */
    String getTargetHost();


    /**
     * @return the proxy server to be used
     */
    ProxyServer getProxyServer();

    /**
     * @return the realm to be used for this request
     */
    Auth getAuth();

    /**
     * @return connectionTimeout in MilliSec, may be override the value in AsyncClientConfig
     */
    int getConnectionTimeoutMilliSec();

    /**
     * @return request timeout in milliSec, may be override the value in AsyncClientConfig
     */
    int getRequestTimeoutMilliSec();

    /**
     * @return read time out in MilliSec, may be override the value in AsyncClientConfig
     */
    int getReadTimeoutMilliSec();

    /**
     * @return the charset value when decode the request's body
     */
    Charset getCharset();

    /**
     * @return the strategy to compute ChannelPool'skeys
     */
    ChannelPoolPartitioning getChannelPoolPartitioning();

    NameResolver<InetAddress> getNameResolver();

    /**
     * @return sslConfig for the request
     */
    SslConfig getSslConfig();

    /**
     *
     * @return attributes that used in current request
     */
    Map<String, String> getAttributes();
}

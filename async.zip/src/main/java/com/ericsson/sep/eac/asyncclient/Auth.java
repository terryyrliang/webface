/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.common.StringBuilderPool;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import com.ericsson.sep.eac.asyncclient.util.AuthUtils;
import com.ericsson.sep.eac.asyncclient.util.CommonUtils;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import static com.ericsson.sep.eac.asyncclient.util.AssertUtils.assertNotNull;
import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;
import static java.nio.charset.StandardCharsets.ISO_8859_1;
import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * @author emeezhg
 * @date 12/19/2018
 * This class is required when authentication is need.
 * The class support BASIC, DIGEST
 */
public class Auth {

    private static final String DEFAULT_NC = "00000001";
    // MD5("")
    private static final String EMPTY_ENTITY_MD5 = "d41d8cd98f00b204e9800998ecf8427e";

    private final String username;
    private final String password;
    private final AuthScheme scheme;
    private final String realmName;
    private final String nonce;
    private final String algorithm;
    private final String response;
    private final String opaque;
    private final String qop;
    private final String nc;
    private final String cnonce;
    private final Uri uri;
    private final boolean usePreemptiveAuth;
    private final Charset charset;
    private final boolean useAbsoluteURI;
    private final boolean omitQuery;
    private final Map<String, String> customLoginConfig;
    private final String servicePrincipalName;
    private final boolean useCanonicalHostname;
    private final String loginContextName;

    private Auth(AuthScheme scheme,
        String username,
        String password,
        String realmName,
        String nonce,
        String algorithm,
        String response,
        String opaque,
        String qop,
        String nc,
        String cnonce,
        Uri uri,
        boolean usePreemptiveAuth,
        Charset charset,
        boolean useAbsoluteURI,
        boolean omitQuery,
        String servicePrincipalName,
        boolean useCanonicalHostname,
        Map<String, String> customLoginConfig,
        String loginContextName) {

        this.scheme = assertNotNull(scheme, "scheme");
        this.username = username;
        this.password = password;
        this.realmName = realmName;
        this.nonce = nonce;
        this.algorithm = algorithm;
        this.response = response;
        this.opaque = opaque;
        this.qop = qop;
        this.nc = nc;
        this.cnonce = cnonce;
        this.uri = uri;
        this.usePreemptiveAuth = usePreemptiveAuth;
        this.charset = charset;
        this.useAbsoluteURI = useAbsoluteURI;
        this.omitQuery = omitQuery;
        this.servicePrincipalName = servicePrincipalName;
        this.useCanonicalHostname = useCanonicalHostname;
        this.customLoginConfig = customLoginConfig;
        this.loginContextName = loginContextName;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public AuthScheme getScheme() {
        return scheme;
    }

    public String getRealmName() {
        return realmName;
    }

    public String getNonce() {
        return nonce;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public String getResponse() {
        return response;
    }

    public String getOpaque() {
        return opaque;
    }

    public String getQop() {
        return qop;
    }

    public String getNc() {
        return nc;
    }

    public String getCnonce() {
        return cnonce;
    }

    public Uri getUri() {
        return uri;
    }

    public Charset getCharset() {
        return charset;
    }

    /**
     * Return true is preemptive authentication is enabled
     *
     * @return true is preemptive authentication is enabled
     */
    public boolean isUsePreemptiveAuth() {
        return usePreemptiveAuth;
    }


    public boolean isUseAbsoluteURI() {
        return useAbsoluteURI;
    }

    public boolean isOmitQuery() {
        return omitQuery;
    }

    public Map<String, String> getCustomLoginConfig() {
        return customLoginConfig;
    }

    public String getServicePrincipalName() {
        return servicePrincipalName;
    }

    public boolean isUseCanonicalHostname() {
        return useCanonicalHostname;
    }

    public String getLoginContextName() {
        return loginContextName;
    }


    @Override
    public String toString() {
        return "Auth{" +
            "username='" + username + '\'' +
            ", password='" + password + '\'' +
            ", scheme=" + scheme +
            ", realmName='" + realmName + '\'' +
            ", nonce='" + nonce + '\'' +
            ", algorithm='" + algorithm + '\'' +
            ", response='" + response + '\'' +
            ", opaque='" + opaque + '\'' +
            ", qop='" + qop + '\'' +
            ", nc='" + nc + '\'' +
            ", cnonce='" + cnonce + '\'' +
            ", uri=" + uri +
            ", usePreemptiveAuth=" + usePreemptiveAuth +
            ", charset=" + charset +
            ", useAbsoluteURI=" + useAbsoluteURI +
            ", omitQuery=" + omitQuery +
            ", customLoginConfig=" + customLoginConfig +
            ", servicePrincipalName='" + servicePrincipalName + '\'' +
            ", useCanonicalHostname=" + useCanonicalHostname +
            ", loginContextName='" + loginContextName + '\'' +
            '}';
    }

    public enum AuthScheme {
        BASIC, DIGEST
    }

    /**
     * A builder for {@link Auth}
     */
    public static class Builder {

        private final String username;
        private final String password;
        private AuthScheme scheme;
        private String realmName;
        private String nonce;
        private String algorithm;
        private String response;
        private String opaque;
        private String qop;
        private String nc = DEFAULT_NC;
        private String cnonce;
        private Uri uri;
        private String methodName = "GET";
        private boolean usePreemptive;
        private Charset charset = UTF_8;
        private boolean useAbsoluteURI = false;
        private boolean omitQuery;
        /**
         * Kerberos/Spnego properties
         */
        private Map<String, String> customLoginConfig;
        private String servicePrincipalName;
        private boolean useCanonicalHostname;
        private String loginContextName;

        public Builder() {
            this.username = null;
            this.password = null;
        }

        public Builder(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public Builder setScheme(AuthScheme scheme) {
            this.scheme = scheme;
            return this;
        }

        public Builder setRealmName(String realmName) {
            this.realmName = realmName;
            return this;
        }

        public Builder setNonce(String nonce) {
            this.nonce = nonce;
            return this;
        }

        public Builder setAlgorithm(String algorithm) {
            this.algorithm = algorithm;
            return this;
        }

        public Builder setResponse(String response) {
            this.response = response;
            return this;
        }

        public Builder setOpaque(String opaque) {
            this.opaque = opaque;
            return this;
        }

        public Builder setQop(String qop) {
            if (isNonEmpty(qop)) {
                this.qop = qop;
            }
            return this;
        }

        public Builder setNc(String nc) {
            this.nc = nc;
            return this;
        }

        public Builder setUri(Uri uri) {
            this.uri = uri;
            return this;
        }

        public Builder setMethodName(String methodName) {
            this.methodName = methodName;
            return this;
        }

        public Builder setUsePreemptiveAuth(boolean usePreemptiveAuth) {
            this.usePreemptive = usePreemptiveAuth;
            return this;
        }

        public Builder setUseAbsoluteURI(boolean useAbsoluteURI) {
            this.useAbsoluteURI = useAbsoluteURI;
            return this;
        }

        public Builder setOmitQuery(boolean omitQuery) {
            this.omitQuery = omitQuery;
            return this;
        }

        public Builder setCharset(Charset charset) {
            this.charset = charset;
            return this;
        }

        public Builder setCustomLoginConfig(Map<String, String> customLoginConfig) {
            this.customLoginConfig = customLoginConfig;
            return this;
        }

        public Builder setServicePrincipalName(String servicePrincipalName) {
            this.servicePrincipalName = servicePrincipalName;
            return this;
        }

        public Builder setUseCanonicalHostname(boolean useCanonicalHostname) {
            this.useCanonicalHostname = useCanonicalHostname;
            return this;
        }

        public Builder setLoginContextName(String loginContextName) {
            this.loginContextName = loginContextName;
            return this;
        }

        private String parseRawQop(String rawQop) {
            String[] rawServerSupportedQops = rawQop.split(",");
            String[] serverSupportedQops = new String[rawServerSupportedQops.length];
            for (int i = 0; i < rawServerSupportedQops.length; i++) {
                serverSupportedQops[i] = rawServerSupportedQops[i].trim();
            }

            // prefer auth over auth-int
            for (String rawServerSupportedQop : serverSupportedQops) {
                if (rawServerSupportedQop.equals("auth")) {
                    return rawServerSupportedQop;
                }
            }

            for (String rawServerSupportedQop : serverSupportedQops) {
                if (rawServerSupportedQop.equals("auth-int")) {
                    return rawServerSupportedQop;
                }
            }

            return null;
        }

        public Builder parseWWWAuthenticateHeader(String headerLine) {
            setRealmName(match(headerLine, "realm"))
                .setNonce(match(headerLine, "nonce"))
                .setOpaque(match(headerLine, "opaque"))
                .setScheme(isNonEmpty(nonce) ? AuthScheme.DIGEST : AuthScheme.BASIC);
            String algorithm = match(headerLine, "algorithm");
            if (isNonEmpty(algorithm)) {
                setAlgorithm(algorithm);
            }

            String rawQop = match(headerLine, "qop");
            if (rawQop != null) {
                setQop(parseRawQop(rawQop));
            }

            return this;
        }

        public Builder parseProxyAuthenticateHeader(String headerLine) {
            setRealmName(match(headerLine, "realm"))
                .setNonce(match(headerLine, "nonce"))
                .setOpaque(match(headerLine, "opaque"))
                .setScheme(isNonEmpty(nonce) ? AuthScheme.DIGEST : AuthScheme.BASIC);
            String algorithm = match(headerLine, "algorithm");
            if (isNonEmpty(algorithm)) {
                setAlgorithm(algorithm);
            }
            setQop(match(headerLine, "qop"));

            return this;
        }

        private void newCnonce(MessageDigest md) {
            byte[] b = new byte[8];
            ThreadLocalRandom.current().nextBytes(b);
            b = md.digest(b);
            cnonce = CommonUtils.toHexString(b);
        }

        private String match(String headerLine, String token) {
            if (headerLine == null) {
                return null;
            }

            int match = headerLine.indexOf(token);
            if (match <= 0) {
                return null;
            }

            // = to skip
            match += token.length() + 1;
            int trailingComa = headerLine.indexOf(",", match);
            String value = headerLine.substring(match, trailingComa > 0 ? trailingComa : headerLine.length());
            value = value.length() > 0 && value.charAt(value.length() - 1) == '"'
                ? value.substring(0, value.length() - 1)
                : value;
            return value.charAt(0) == '"' ? value.substring(1) : value;
        }

        private byte[] md5FromRecycledStringBuilder(StringBuilder sb, MessageDigest md) {
            md.update(CommonUtils.charSequence2ByteBuffer(sb, ISO_8859_1));
            sb.setLength(0);
            return md.digest();
        }

        private byte[] ha1(StringBuilder sb, MessageDigest md) {
            // if algorithm is "MD5" or is unspecified => A1 = username ":" realm-value ":"
            // passwd
            // if algorithm is "MD5-sess" => A1 = MD5( username-value ":" realm-value ":"
            // passwd ) ":" nonce-value ":" cnonce-value

            sb.append(username).append(':').append(realmName).append(':').append(password);
            byte[] core = md5FromRecycledStringBuilder(sb, md);

            if (algorithm == null || algorithm.equals("MD5")) {
                // A1 = username ":" realm-value ":" passwd
                return core;
            } else if ("MD5-sess".equals(algorithm)) {
                // A1 = MD5(username ":" realm-value ":" passwd ) ":" nonce ":" cnonce
                CommonUtils.appendBase16(sb, core);
                sb.append(':').append(nonce).append(':').append(cnonce);
                return md5FromRecycledStringBuilder(sb, md);
            }

            throw new UnsupportedOperationException("Digest algorithm not supported: " + algorithm);
        }

        private byte[] ha2(StringBuilder sb, String digestUri, MessageDigest md) {

            // if qop is "auth" or is unspecified => A2 = Method ":" digest-uri-value
            // if qop is "auth-int" => A2 = Method ":" digest-uri-value ":" H(entity-body)
            sb.append(methodName).append(':').append(digestUri);
            if ("auth-int".equals(qop)) {
                // when qop == "auth-int", A2 = Method ":" digest-uri-value ":" H(entity-body)
                // but we don't have the request body here
                // we would need a new API
                sb.append(':').append(EMPTY_ENTITY_MD5);

            } else if (qop != null && !qop.equals("auth")) {
                throw new UnsupportedOperationException("Digest qop not supported: " + qop);
            }

            return md5FromRecycledStringBuilder(sb, md);
        }

        private void appendMiddlePart(StringBuilder sb) {
            // request-digest = MD5(H(A1) ":" nonce ":" nc ":" cnonce ":" qop ":" H(A2))
            sb.append(':').append(nonce).append(':');
            if ("auth".equals(qop) || "auth-int".equals(qop)) {
                sb.append(nc).append(':').append(cnonce).append(':').append(qop).append(':');
            }
        }

        private void newResponse(MessageDigest md) {
            // when using preemptive auth, the request uri is missing
            if (uri != null) {
                // BEWARE: compute first as it uses the cached StringBuilder
                String digestUri = AuthUtils.computeRealmURI(uri, useAbsoluteURI, omitQuery);

                StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();

                // WARNING: DON'T MOVE, BUFFER IS RECYCLED!!!!
                byte[] ha1 = ha1(sb, md);
                byte[] ha2 = ha2(sb, digestUri, md);

                CommonUtils.appendBase16(sb, ha1);
                appendMiddlePart(sb);
                CommonUtils.appendBase16(sb, ha2);

                byte[] responseDigest = md5FromRecycledStringBuilder(sb, md);
                response = CommonUtils.toHexString(responseDigest);
            }
        }

        /**
         * Build a {@link Auth}
         *
         * @return a {@link Auth}
         */
        public Auth build() {

            // Avoid generating
            if (isNonEmpty(nonce)) {
                MessageDigest md = CommonUtils.pooledMd5MessageDigest();
                newCnonce(md);
                newResponse(md);
            }

            return new Auth(scheme, username,
                password,
                realmName,
                nonce,
                algorithm,
                response,
                opaque,
                qop,
                nc,
                cnonce,
                uri,
                usePreemptive,
                charset,
                useAbsoluteURI,
                omitQuery,
                servicePrincipalName,
                useCanonicalHostname,
                customLoginConfig,
                loginContextName);
        }
    }
}

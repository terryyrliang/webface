package com.ericsson.sep.eac.asyncclient.common;

import com.ericsson.sep.eac.asyncclient.channel.Http2ChannelPool;
import io.netty.channel.Channel;

import static com.ericsson.sep.eac.asyncclient.util.AssertUtils.assertNotNull;

public class Http2Channel {
    public int streamId = AsyncConstants.DEFAULT_BEGIN_STREAM_ID;
    final Channel channel;
    final long startTime;
    @SuppressWarnings("unused")
    private volatile int owned = 0;

    public Http2Channel(Channel channel, long startTime) {
        this.channel = assertNotNull(channel, "channel");
        this.startTime = startTime;
    }

    public Channel getChannel() {
        return channel;
    }

    public int incAndGetStreamId() {
        streamId += 2;
        return streamId;
    }

    @Override
    // only depends on channel
    public boolean equals(Object o) {
        return this == o || (o instanceof Http2Channel && channel
                .equals(((Http2Channel) o).channel));
    }

    @Override
    public int hashCode() {
        return channel.hashCode();
    }
}

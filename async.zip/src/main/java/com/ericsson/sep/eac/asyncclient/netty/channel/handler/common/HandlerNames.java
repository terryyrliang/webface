/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler.common;

public final class HandlerNames {

    private HandlerNames() {
    }

    public static final String LOGGER_HANDLER = "logHandler";

    public static final String SSL_HANDLER = "ssl";

    public static final String HTTP_CLIENT_CODEC = "httpCodec";
    public static final String CONTENT_DECOMPRESSOR = "contentDecompressor";
    public static final String HTTP_AGGREGATOR = "httpAggregator";
    public static final String CHUNKED_WRITER = "chunkWriter";
    public static final String ASY_HTTP_HANDLER = "asyHttp";
    public static final String EVENT_LOG = "eventLog";


    public static final String SOCKS_HANDLER = "socks";
    public static final String INFLATER_HANDLER = "inflater";
    public static final String WS_DECODER_HANDLER = "wsDecoder";
    public static final String WS_FRAME_AGGREGATOR = "ws-aggregator";
    public static final String WS_COMPRESSOR_HANDLER = "ws-compressor";
    public static final String WS_ENCODER_HANDLER = "wsEncoder";

    public static final String WS_CLIENT_COMPRESSION = "wsClientCompression";
    public static final String ASY_WS_HANDLER = "asyWs";

    // http2 handlers for Tls sequence: ssl(add after connect), apn, h2Settings, asyHttp2
    public static final String APN_HANDLER = "apnHandler";
    public static final String HTTP_TO_HTTP2_HANDLER = "httpToHttp2Handler";
    public static final String HTTP2_CONN_HANDLER = "http2ConnHandler";
    public static final String HTTP2_SETTINGS = "h2Settings";
    public static final String ASY_H2_HANDLER = "asyHttp2";

    // http2 plain handlers sequence: httpCodec, HttpClientUpgradeHandler, h2Settings, asyHttp2
    public static final String H2_UPGRADE = "h2Upgrade";

    // purge http2 connectionHandler
    public static final String H2_CONNECT_HANDLER = "h2Connection";
}

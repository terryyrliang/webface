/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.common;

/**
 * @author emeezhg
 * @date 12/19/2018
 */
public class StringBuilderPool {
    public static final StringBuilderPool DEFAULT = new StringBuilderPool();

    private final ThreadLocal<StringBuilder> pool = ThreadLocal.withInitial(() -> new StringBuilder(512));

    /**
     * BEWARE: MUSN'T APPEND TO ITSELF!
     *
     * @return a pooled StringBuilder
     */
    public StringBuilder stringBuilder() {
        StringBuilder sb = pool.get();
        sb.setLength(0);
        return sb;
    }
}

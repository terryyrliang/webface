/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;


import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.currentMillisTime;

public class CombinedConnectionSemaphore extends PerHostConnectionSemaphore {

    private final MaxConnectionSemaphore maxConnectionSemaphore;

    public CombinedConnectionSemaphore(int maxConnections, int maxConnectionsPerHost,
        int obtainTimeoutMilliSec) {
        super(maxConnectionsPerHost, obtainTimeoutMilliSec);
        this.maxConnectionSemaphore =
            new MaxConnectionSemaphore(maxConnections, obtainTimeoutMilliSec);
    }

    @Override
    public void acquireChannelLock(Object partitionKey) throws IOException {
        long remainingTime = obtainTimeoutMilliSec > 0 ?
            obtainGlobalUsedTime(partitionKey) :
            obtainGlobal(partitionKey);

        try {
            if (remainingTime < 0 || !getFreeConnectionsForPerHost(partitionKey)
                .tryAcquire(remainingTime, TimeUnit.MILLISECONDS)) {
                releaseGlobal(partitionKey);
                throw tooManyConnectionsPerHost;
            }
        } catch (InterruptedException e) {
            releaseGlobal(partitionKey);
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
        }
    }

    @Override
    public void releaseChannelLock(Object partitionKey) {
        maxConnectionSemaphore.releaseChannelLock(partitionKey);
        super.releaseChannelLock(partitionKey);
    }

    protected void releaseGlobal(Object partitionKey) {
        this.maxConnectionSemaphore.releaseChannelLock(partitionKey);
    }

    private long obtainGlobalUsedTime(Object partitionKey) throws IOException {
        long currentTime = currentMillisTime();
        obtainGlobal(partitionKey);
        long lockTime = currentMillisTime() - currentTime;
        return obtainTimeoutMilliSec - lockTime;
    }

    private long obtainGlobal(Object partitionKey) throws IOException {
        this.maxConnectionSemaphore.acquireChannelLock(partitionKey);
        return 0;
    }
}

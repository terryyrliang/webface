/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.request.body;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.request.WriteProcessListener;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.util.CommonUtils;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.Channel;
import io.netty.channel.ChannelProgressiveFuture;
import io.netty.handler.codec.http.LastHttpContent;
import io.netty.util.CharsetUtil;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;

public class NettyInputStreamBody implements NettyBody {
    private static final Logger LOGGER = LogHelper.getLogger(NettyInputStreamBody.class);

    private final InputStream inputStream;
    private final long contentLength;

    public NettyInputStreamBody(InputStream inputStream) {
        this(inputStream, -1);
    }

    public NettyInputStreamBody(InputStream inputStream, long contentLength) {
        this.inputStream = inputStream;
        this.contentLength = contentLength;
    }

    @Override
    public long getContentLength() {
        return contentLength;
    }

    @Override
    public void write(Channel channel, ResponseFuture<?> responseFuture) throws IOException {
        LOGGER.debug("Write request body.");
        if (!ChannelUtils.isChannelActive(channel)) {
            LOGGER.warn("Channel is not active.");
            return;
        }
        final InputStream is = inputStream;
        if (responseFuture.isContentStreamConsumed()) {
            if (is.markSupported()) {
                is.reset();
            } else {
                LOGGER.warn("Stream has already consumed and can not be reset.");
                return;
            }
        } else {
            responseFuture.setContentStreamConsumed(true);
        }
        ByteBuf content = PooledByteBufAllocator.DEFAULT.buffer();
        content.writeBytes(is, is.available());
        LOGGER.debug("Request body is: {}", content.toString(CharsetUtil.UTF_8));
        channel.write(content, channel.newProgressivePromise()
            .addListener(new WriteProcessListener(responseFuture, false, contentLength) {
                @Override
                public void operationComplete(ChannelProgressiveFuture future) {
                    LOGGER.debug("Get request body write future: {}", future);
                    CommonUtils.closeSilently(inputStream);
                    super.operationComplete(future);
                }

                @Override
                public void operationProgressed(ChannelProgressiveFuture progressiveFuture,
                    long progress, long total) throws Exception {
                    LOGGER.debug("Process write request with total: {}", total);
                    super.operationProgressed(progressiveFuture, progress, total);
                }
            }));
        LOGGER.debug("Write and flush last empty content.");
        channel.writeAndFlush(LastHttpContent.EMPTY_LAST_CONTENT, channel.newPromise());
    }
}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler.common;

import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import io.netty.handler.codec.http.HttpClientCodec;
import io.netty.handler.codec.http.HttpObjectAggregator;

/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class HandlerUtils {

    private HandlerUtils() {
    }

    private static final int KB = 1024;

    public static HttpClientCodec newHttpClientCodec(AsyncClientConfig config) {
        return new HttpClientCodec(config.getMaxInitLineLength(), config.getMaxHeaderSize(),
            config.getMaxChunkSize(), false, config.isValidateResponseHeaders(),
            config.getInitBufferSize());
    }

    public static HttpObjectAggregator newHttpObjectAggregator(AsyncClientConfig config) {
        return new HttpObjectAggregator(config.getResponseMaxContentLengthKB() * KB);
    }
}

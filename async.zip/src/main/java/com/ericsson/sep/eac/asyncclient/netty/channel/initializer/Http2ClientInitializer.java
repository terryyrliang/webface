/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.initializer;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2Handler;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http2.*;
import org.slf4j.Logger;

import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.ASY_H2_HANDLER;
import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.HTTP_TO_HTTP2_HANDLER;



/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class Http2ClientInitializer extends ChannelInitializer<SocketChannel> {
    private static final Logger LOGGER = LogHelper.getLogger(Http2ClientInitializer.class);
    private static final int KB = 1024;

    private final AsyncClientConfig config;
    private final RequestSender requestSender;
    private final ChannelManager channelManager;
    // bellow two connection handler is for http->http2 connection
    private HttpToHttp2ConnectionHandler httpToHttp2TLSConnectionHandler;

    public Http2ClientInitializer(AsyncClientConfig config, RequestSender sender,
        ChannelManager channelManager) {
        this.config = config;
        this.requestSender = sender;
        this.channelManager = channelManager;
    }

    @Override
    protected void initChannel(SocketChannel socketChannel) {
        LOGGER.debug("Init channel for h2 with TLS.");
        ChannelPipeline pipeline = socketChannel.pipeline();
        pipeline.addLast(ASY_H2_HANDLER, new Http2Handler(config, requestSender, channelManager));
        httpToHttp2TLSConnectionHandler = newHttpToHttp2ConnectionHandler();
        pipeline.addBefore(ASY_H2_HANDLER, HTTP_TO_HTTP2_HANDLER, httpToHttp2TLSConnectionHandler);
    }

    private HttpToHttp2ConnectionHandler newHttpToHttp2ConnectionHandler() {
        final DefaultHttp2Connection connection = new DefaultHttp2Connection(false);
        final InboundHttp2ToHttpAdapter adapter = new InboundHttp2ToHttpAdapterBuilder(connection)
            .maxContentLength(config.getResponseMaxContentLengthKB() * KB).build();
        final DelegatingDecompressorFrameListener frameListener =
            new DelegatingDecompressorFrameListener(connection, adapter);
        return new HttpToHttp2ConnectionHandlerBuilder().frameListener(frameListener)
            .connection(connection).build();
    }
}

/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;

import com.ericsson.sep.eac.asyncclient.channel.Http2ChannelPool;
import com.ericsson.sep.eac.asyncclient.common.ChannelCreation;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.ChannelEvent;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.channel.Channel;
import io.netty.util.Attribute;
import io.netty.util.AttributeKey;
import org.slf4j.Logger;

import static com.ericsson.sep.eac.asyncclient.common.AsyncConstants.CHANNEL_CREATION_ATTRIBUTE_KEY;

/**
 * @author emeezhg
 * @date 1/9/2019
 */
public class ChannelUtils {
    private static final Logger LOGGER = LogHelper.getLogger(ChannelUtils.class);
    private static final AttributeKey<Object> DEFAULT_ATTRIBUTE = AttributeKey.valueOf("default");
    private static final AttributeKey<Active> ACTIVE_ATTRIBUTE = AttributeKey.valueOf("active");

    public static boolean isChannelActive(Channel channel){
        return channel != null && channel.isActive();
    }

    public static void close(Channel channel){
        setDiscard(channel);
        closeChannelSilently(channel);
    }

    public static Object getAttribute(Channel channel) {
        Attribute<Object> attr = channel.attr(DEFAULT_ATTRIBUTE);
        return attr != null ? attr.get() : null;
    }

    public static void setAttribute(Channel channel, AttributeKey attributeKey, Object value) {
        Attribute<Object> attr = channel.attr(attributeKey);
        if (attr != null) {
            attr.set(value);
        }
    }

    public static Object getAttribute(Channel channel, AttributeKey attributeKey) {
        Attribute<Object> attr = channel.attr(attributeKey);
        return attr != null ? attr.get() : null;
    }

    public static Object getPartitionKey(Channel channel) {
        Attribute<ChannelCreation> channelCreationAttribute =
                channel.attr(CHANNEL_CREATION_ATTRIBUTE_KEY);
        return channelCreationAttribute.get() == null ? null : channelCreationAttribute.get().partitionKey;
    }

    public static String getRequestId(Channel channel, Integer streamId) {
        return String.format("%s:%d", channel.id().asShortText(), streamId);
    }

    public static boolean isStreamIdExceeded(int streamId) {
        return streamId > Integer.MAX_VALUE - 2;
//        return streamId > 3000;
    }

    public static void setAttribute(Channel channel, Object o) {
        channel.attr(DEFAULT_ATTRIBUTE).set(o);
    }

    public static void setDiscard(Channel channel) {
        setAttribute(channel, ChannelEvent.DISCARD);
    }

    public static void closeChannelSilently(Channel channel){
        try {
            if (isChannelActive(channel)) {
                channel.close();
            }
        }catch (Throwable t){
            LOGGER.debug("Channel close exception occur", t);
        }
    }

    public static void setActiveToken(Channel channel){
        channel.attr(ACTIVE_ATTRIBUTE).set(Active.INSTANCE);
    }

    public static boolean isActiveTokenSet(Channel channel){
        return channel != null && channel.attr(ACTIVE_ATTRIBUTE).getAndSet(null) != null;
    }

    private enum Active {INSTANCE}
}

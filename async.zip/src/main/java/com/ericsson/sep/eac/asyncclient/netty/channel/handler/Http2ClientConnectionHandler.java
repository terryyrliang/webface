package com.ericsson.sep.eac.asyncclient.netty.channel.handler;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http2.*;
import org.slf4j.Logger;

public class Http2ClientConnectionHandler extends HttpToHttp2ConnectionHandler {
    private static final Logger LOGGER = LogHelper.getLogger(Http2ClientConnectionHandler.class);
    private Boolean errorOccurred = Boolean.valueOf(false);
    private Object errorOccurredLock = new Object();

    protected Http2ClientConnectionHandler(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings) {
        super(decoder, encoder, initialSettings, false);
    }

    public void channelActive(ChannelHandlerContext ctx)
            throws Exception {
        super.channelActive(ctx);
        super.flush(ctx);
    }

    protected void onConnectionError(ChannelHandlerContext ctx, boolean outbound, Throwable cause, Http2Exception http2Ex) {
        cause.printStackTrace();
        if (!hasErrorOccurred().booleanValue()) {
            String causeText = cause.getMessage() == null ? cause.getClass().getName() : cause == null ? "" : cause.getMessage();
            String httpExceptionMessage = http2Ex == null ? "" : http2Ex.getMessage();
            LOGGER.warn("onConnectionError: outbound={}, Cause={}, Exception={}", Boolean.valueOf(outbound), causeText, httpExceptionMessage);

            LOGGER.debug("onConnectionError: outbound={}, Cause={}, Exception={}", Boolean.valueOf(outbound), causeText, httpExceptionMessage, cause);
        }
        setErrorOccurred(Boolean.valueOf(true));
        super.onConnectionError(ctx, outbound, cause, http2Ex);
    }

    protected void onStreamError(ChannelHandlerContext ctx, boolean outbound, Throwable cause, Http2Exception.StreamException http2Ex) {
        cause.printStackTrace();
        if (!hasErrorOccurred().booleanValue()) {
            String causeText = cause.getMessage() == null ? cause.getClass().getName() : cause == null ? "" : cause.getMessage();
            String httpExceptionMessage = http2Ex == null ? "" : http2Ex.getMessage();
            LOGGER.warn("onStreamError: outbound={}, Cause={}, Exception={}", Boolean.valueOf(outbound), causeText, httpExceptionMessage);

            LOGGER.warn("{}, shutdown hint: {}, error:{}", Integer.valueOf(connection().numActiveStreams()), http2Ex
                    .shutdownHint().name(), http2Ex.error().name());
            LOGGER.debug("onStreamError: outbound={}, Cause={}, Exception={}", Boolean.valueOf(outbound), causeText, httpExceptionMessage, cause);
        }
        if ((http2Ex != null) && (http2Ex.error() == Http2Error.REFUSED_STREAM)) {
            setErrorOccurred(Boolean.valueOf(true));
            super.onConnectionError(ctx, outbound, cause, new Http2Exception(http2Ex.error(), Http2Exception.ShutdownHint.GRACEFUL_SHUTDOWN));
        } else {
            super.onStreamError(ctx, outbound, cause, http2Ex);
        }
    }

    public void onError(ChannelHandlerContext ctx, boolean outbound, Throwable cause) {
        cause.printStackTrace();
        Http2Exception embedded = Http2CodecUtil.getEmbeddedHttp2Exception(cause);
        if (Http2Exception.isStreamError(embedded)) {
            onStreamError(ctx, outbound, cause, (Http2Exception.StreamException) embedded);
        } else if ((embedded instanceof Http2Exception.CompositeStreamException)) {
            Http2Exception.CompositeStreamException compositException = (Http2Exception.CompositeStreamException) embedded;
            for (Http2Exception.StreamException streamException : compositException) {
                onStreamError(ctx, outbound, cause, streamException);
            }
        } else {
            onConnectionError(ctx, outbound, cause, embedded);
        }
    }

    public Boolean hasErrorOccurred() {
        return false;
    }

    private void setErrorOccurred(Boolean connectionErrorOccurred) {
        synchronized (this.errorOccurredLock) {
            this.errorOccurred = connectionErrorOccurred;
        }
    }
}

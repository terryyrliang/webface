/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.util;

import java.util.Base64;
import java.util.concurrent.ThreadLocalRandom;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.pooledSha1MessageDigest;
import static java.nio.charset.StandardCharsets.US_ASCII;

public class WebSocketUtil {

    private WebSocketUtil() {
    }

    private static final String MAGIC_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    public static String getWebSocketKey() {
        byte[] nonce = new byte[16];
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < nonce.length; i++) {
            nonce[i] = (byte) random.nextInt(256);
        }
        return Base64.getEncoder().encodeToString(nonce);
    }

    public static String getAcceptKey(String key) {
        return Base64.getEncoder().encodeToString(
            pooledSha1MessageDigest().digest((key + MAGIC_GUID).getBytes(US_ASCII)));
    }
}

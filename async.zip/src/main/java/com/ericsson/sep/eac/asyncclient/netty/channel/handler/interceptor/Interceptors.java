/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler.interceptor;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponse;
import io.netty.handler.codec.http.HttpResponseStatus;
import org.slf4j.Logger;


public class Interceptors {
    private static final Logger LOGGER = LogHelper.getLogger(Interceptors.class);

    private final RequestSender requestSender;
    private final ChannelManager channelManager;

    private final Unauthorized401Interceptor unauthorized401Interceptor;
    private final Connect200Interceptor connect200Interceptor;
    private final Continue100Interceptor continue100Interceptor;

    public Interceptors(RequestSender requestSender, ChannelManager channelManager) {
        this.requestSender = requestSender;
        this.channelManager = channelManager;
        this.continue100Interceptor = new Continue100Interceptor(requestSender);
        this.unauthorized401Interceptor =
            new Unauthorized401Interceptor(channelManager, requestSender);
        this.connect200Interceptor = new Connect200Interceptor(channelManager, requestSender);
    }


    public boolean isExitAfterIntercept(Channel channel, ResponseFuture<?> future,
        HttpResponse response) {
        LOGGER.debug("if exit after interceptors with channel isOpen:{}, isActive:{}",
            channel.isOpen(), channel.isActive());
        int statusCode = response.status().code();
        HttpRequest request = future.getNettyRequest().getHttpRequest();

        if (statusCode == HttpResponseStatus.UNAUTHORIZED.code()) {
            LOGGER.debug("check 401 response");
            return unauthorized401Interceptor.isExitAfterHandling401(channel, future, response);
        } else if (request.method() == HttpMethod.CONNECT && statusCode == HttpResponseStatus.OK
            .code()) {
            LOGGER.debug("check 200 response");
            return connect200Interceptor.isExitAfterHandlingConnect(channel, future);
        } else if (statusCode == HttpResponseStatus.CONTINUE.code()) {
            LOGGER.debug("check 100 response");
            return continue100Interceptor.isExitAfterHandling100(channel, future);
        }
        LOGGER.debug("not exit after interceptors");
        return false;
    }
}

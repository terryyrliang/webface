/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.channel.ChannelPoolPartitioning;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.handler.codec.http.*;
import io.netty.resolver.NameResolver;

import java.io.InputStream;
import java.net.InetAddress;
import java.nio.charset.Charset;
import java.util.*;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;

/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class DefaultRequest implements Request {
    private final Uri uri;
    private final String protocol;
    private final String method;
    private final HttpHeaders headers;
    private final List<RequestParam> formParams;
    private final InputStream streamData;
    private final InetAddress address;
    private final InetAddress localAddress;
    private final String targetHost;
    private final Auth auth;
    private final ProxyServer proxyServer;
    private final int connectionTimeoutMilliSec;
    private final int requestTimeoutMilliSec;
    private final int readTimeoutMilliSec;
    private final Charset charset;
    private final ChannelPoolPartitioning channelPoolPartitioning;
    private final NameResolver<InetAddress> nameResolver;
    private final SslConfig sslConfig;
    // lazy load
    private List<RequestParam> queryParams;
    private Map<String, String> attributes;

    public DefaultRequest(Uri uri, String protocol, String method, HttpHeaders headers,
        List<RequestParam> formParams, InputStream streamData, InetAddress address,
        InetAddress localAddress, String targetHost, Auth auth, ProxyServer proxyServer,
        int connectionTimeoutMilliSec, int requestTimeoutMilliSec, int readTimeoutMilliSec,
        Charset charset, ChannelPoolPartitioning channelPoolPartitioning,
        NameResolver<InetAddress> nameResolver, SslConfig sslConfig, Map<String, String> attributes) {
        this.uri = uri;
        this.protocol = protocol;
        this.method = method;
        this.headers = headers;
        this.formParams = formParams;
        this.streamData = streamData;
        this.address = address;
        this.localAddress = localAddress;
        this.targetHost = targetHost;
        this.auth = auth;
        this.proxyServer = proxyServer;
        this.connectionTimeoutMilliSec = connectionTimeoutMilliSec;
        this.requestTimeoutMilliSec = requestTimeoutMilliSec;
        this.readTimeoutMilliSec = readTimeoutMilliSec;
        this.charset = charset;
        this.channelPoolPartitioning = channelPoolPartitioning;
        this.nameResolver = nameResolver;
        this.sslConfig = sslConfig;
        this.attributes = new HashMap<>(attributes);
    }

    @Override
    public Uri getUri() {
        return uri;
    }

    /**
     * @return [scheme]://[userInfo]@[host]:[port]/[path]?[query]
     */
    @Override
    public String getUrl() {
        return uri.toUrl();
    }

    @Override
    public String getMethod() {
        return method;
    }

    @Override
    public String getProtocol() {
        return protocol;
    }

    @Override
    public HttpHeaders getHeaders() {
        return headers;
    }

    @Override
    public InputStream getStreamData() {
        return streamData;
    }

    @Override
    public List<RequestParam> getFormParams() {
        return formParams;
    }

    @Override
    public InetAddress getAddress() {
        return address;
    }

    @Override
    public InetAddress getLocalAddress() {
        return localAddress;
    }

    @Override
    public String getTargetHost() {
        return targetHost;
    }

    @Override
    public Auth getAuth() {
        return auth;
    }

    @Override
    public int getConnectionTimeoutMilliSec() {
        return connectionTimeoutMilliSec;
    }

    @Override
    public int getRequestTimeoutMilliSec() {
        return requestTimeoutMilliSec;
    }

    @Override
    public int getReadTimeoutMilliSec() {
        return readTimeoutMilliSec;
    }

    @Override
    public Charset getCharset() {
        return charset;
    }

    @Override
    public ChannelPoolPartitioning getChannelPoolPartitioning() {
        return channelPoolPartitioning;
    }

    @Override
    public ProxyServer getProxyServer() {
        return proxyServer;
    }

    @Override
    public NameResolver<InetAddress> getNameResolver() {
        return nameResolver;
    }

    @Override
    public SslConfig getSslConfig() {
        return sslConfig;
    }

    @Override
    public List<RequestParam> getQueryParams() {
        if (queryParams == null || queryParams.isEmpty()) {
            if (isNonEmpty(uri.getQuery())) {
                queryParams = new ArrayList<>(1);
                for (String parm : uri.getQuery().split("&")) {
                    int index = parm.indexOf("=");
                    if (index < 0) {
                        queryParams.add(new RequestParam(parm, null));
                    } else {
                        queryParams.add(
                            new RequestParam(parm.substring(0, index), parm.substring(index + 1)));
                    }
                }
            }
        } else {
            queryParams = Collections.emptyList();
        }
        return queryParams;
    }

    @Override
    public Map<String, String> getAttributes() {
        return attributes;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(getUrl());
        sb.append("\n");
        sb.append(protocol);
        sb.append(" ");
        sb.append(method);
        sb.append("\nheaders:");
        if (!headers.isEmpty()) {
            headers.forEach(header -> {
                sb.append("\n");
                sb.append(header.getKey());
                sb.append(":");
                sb.append(header.getValue());
            });
        }
        if (isNonEmpty(formParams)) {
            sb.append("\tformParams:");
            formParams.forEach(param ->{
                sb.append("\n");
                sb.append(param.getName());
                sb.append(":");
                sb.append(param.getValue());
            });
        }
        return sb.toString();
    }
}

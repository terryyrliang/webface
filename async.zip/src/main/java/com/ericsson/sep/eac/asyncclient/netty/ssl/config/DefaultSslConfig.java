/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.ssl.config;

import com.ericsson.sep.eac.asyncclient.util.CommonUtils;

import java.util.concurrent.TimeUnit;

public class DefaultSslConfig implements SslConfig {
    // ssl
    private boolean isUseOpenssl;
    private boolean isTLS13Support;
    private boolean isTlsAllowInsecureConnection;
    private String privateKeyFile;
    private String certificateFile;
    private String passwordFile;
    private String trustCertFile;

    private final int handshakeTimeoutMilliSec;
    private final int tlsSessionCacheSize;
    private final int tlsSessionTimeoutMilliSec;

    private final int cacheVolume;
    private final int cacheTimeout;
    private final TimeUnit cacheTimeoutUnit;

    public DefaultSslConfig(boolean isUseOpenssl, boolean isTLS13Support,
        boolean isTlsAllowInsecureConnection, String privateKeyFile, String certificateFile,
        String trustCertFile, String passwordFile, int handshakeTimeoutMilliSec,
        int tlsSessionCacheSize, int tlsSessionTimeoutMilliSec, int cacheVolume, int cacheTimeout,
        TimeUnit cacheTimeoutUnit) {
        this.isUseOpenssl = isUseOpenssl;
        this.isTLS13Support = isTLS13Support;
        this.isTlsAllowInsecureConnection = isTlsAllowInsecureConnection;
        this.privateKeyFile = privateKeyFile;
        this.certificateFile = certificateFile;
        this.trustCertFile = trustCertFile;
        this.passwordFile = passwordFile;
        this.handshakeTimeoutMilliSec = handshakeTimeoutMilliSec;
        this.tlsSessionCacheSize = tlsSessionCacheSize;
        this.tlsSessionTimeoutMilliSec = tlsSessionTimeoutMilliSec;
        this.cacheVolume = cacheVolume;
        this.cacheTimeout = cacheTimeout;
        this.cacheTimeoutUnit = cacheTimeoutUnit;
    }

    @Override
    public boolean isUseOpenSsl() {
        return isUseOpenssl;
    }

    @Override
    public boolean isTLS13Support() {
        return isTLS13Support;
    }

    @Override
    public boolean isAllowInsecureConnection() {
        return isTlsAllowInsecureConnection;
    }

    @Override
    public String getPrivateKeyFile() {
        return privateKeyFile;
    }

    @Override
    public String getCertificateFile() {
        return certificateFile;
    }

    @Override
    public String getTrustCertFile() {
        return trustCertFile;
    }

    @Override
    public String getKeyPasswordFile() {
        return passwordFile;
    }

    @Override
    public int getHandshakeTimeoutMilliSec() {
        return handshakeTimeoutMilliSec;
    }

    @Override
    public int getTlsSessionCacheSize() {
        return tlsSessionCacheSize;
    }

    @Override
    public int getTlsSessionTimeoutMilliSec() {
        return tlsSessionTimeoutMilliSec;
    }

    @Override
    public int getCacheVolume() {
        return cacheVolume;
    }

    @Override
    public int getCacheTimeout() {
        return cacheTimeout;
    }

    @Override
    public TimeUnit getCacheTimeoutUnit() {
        return cacheTimeoutUnit;
    }

    @Override
    public void copyFrom(SslConfig parentSslConfig) {
        if (CommonUtils.nullOrEmptyString(privateKeyFile)) {
            this.privateKeyFile = parentSslConfig.getPrivateKeyFile();
        }
        if (CommonUtils.nullOrEmptyString(certificateFile)) {
            this.certificateFile = parentSslConfig.getCertificateFile();
        }
        if (CommonUtils.nullOrEmptyString(trustCertFile)) {
            this.trustCertFile = parentSslConfig.getTrustCertFile();
        }
        if (CommonUtils.nullOrEmptyString(passwordFile)) {
            this.passwordFile = parentSslConfig.getKeyPasswordFile();
        }
    }

    public static class Builder {
        private boolean isUseOpenssl = false;
        private boolean isTLS13Support = false;
        private boolean isTlsAllowInsecureConnection = false;
        private String privateKeyFile = "";
        private String certificateFile = "";
        private String passwordFile = "";
        private String trustCertFile = "";

        private int handshakeTimeoutMilliSec = 30000;
        private int tlsSessionCacheSize = 100;
        private int tlsSessionTimeoutMilliSec = 60000;

        private int cacheVolume = 100;
        private int cacheTimeout = 5;
        private TimeUnit cacheTimeoutUnit = TimeUnit.MINUTES;

        public Builder() {
        }

        public Builder(SslConfig config) {
            this.isUseOpenssl = config.isUseOpenSsl();
            this.isTLS13Support = config.isTLS13Support();
            this.isTlsAllowInsecureConnection = config.isAllowInsecureConnection();
            this.privateKeyFile = config.getPrivateKeyFile();
            this.certificateFile = config.getCertificateFile();
            this.trustCertFile = config.getTrustCertFile();
            this.passwordFile = config.getKeyPasswordFile();
            this.handshakeTimeoutMilliSec = config.getHandshakeTimeoutMilliSec();
            this.tlsSessionCacheSize = config.getTlsSessionCacheSize();
            this.tlsSessionTimeoutMilliSec = config.getTlsSessionTimeoutMilliSec();
            this.cacheVolume = config.getCacheVolume();
            this.cacheTimeout = config.getCacheTimeout();
            this.cacheTimeoutUnit = config.getCacheTimeoutUnit();
        }

        public Builder setUseOpenssl(boolean useOpenssl) {
            isUseOpenssl = useOpenssl;
            return this;
        }

        public Builder setTLS13Support(boolean TLS13Support) {
            isTLS13Support = TLS13Support;
            return this;
        }

        public Builder setTlsAllowInsecureConnection(boolean tlsAllowInsecureConnection) {
            isTlsAllowInsecureConnection = tlsAllowInsecureConnection;
            return this;
        }

        public Builder setPrivateKeyFile(String privateKeyFile) {
            this.privateKeyFile = privateKeyFile;
            return this;
        }

        public Builder setCertificateFile(String certificateFile) {
            this.certificateFile = certificateFile;
            return this;
        }

        public Builder setTrustCertFile(String trustCertFile) {
            this.trustCertFile = trustCertFile;
            return this;
        }

        public Builder setPasswordFile(String passwordFile) {
            this.passwordFile = passwordFile;
            return this;
        }

        public Builder setHandshakeTimeoutMilliSec(int handshakeTimeoutMilliSec) {
            this.handshakeTimeoutMilliSec = handshakeTimeoutMilliSec;
            return this;
        }

        public Builder setTlsSessionCacheSize(int tlsSessionCacheSize) {
            this.tlsSessionCacheSize = tlsSessionCacheSize;
            return this;
        }

        public Builder setTlsSessionTimeoutMilliSec(int tlsSessionTimeoutMilliSec) {
            this.tlsSessionTimeoutMilliSec = tlsSessionTimeoutMilliSec;
            return this;
        }

        public Builder setCacheVolume(int cacheVolume) {
            this.cacheVolume = cacheVolume;
            return this;
        }

        public Builder setCacheTimeout(int cacheTimeout) {
            this.cacheTimeout = cacheTimeout;
            return this;
        }

        public Builder setCacheTimeoutUnit(TimeUnit cacheTimeoutUnit) {
            this.cacheTimeoutUnit = cacheTimeoutUnit;
            return this;
        }

        public DefaultSslConfig build() {
            return new DefaultSslConfig(isUseOpenssl, isTLS13Support, isTlsAllowInsecureConnection,
                privateKeyFile, certificateFile, trustCertFile, passwordFile,
                handshakeTimeoutMilliSec, tlsSessionCacheSize, tlsSessionTimeoutMilliSec,
                cacheVolume, cacheTimeout, cacheTimeoutUnit);
        }
    }
}

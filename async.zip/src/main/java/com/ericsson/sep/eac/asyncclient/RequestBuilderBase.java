/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.channel.ChannelPoolPartitioning;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import com.ericsson.sep.eac.asyncclient.util.UriEncoder;
import io.netty.handler.codec.http.DefaultHttpHeaders;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.resolver.DefaultNameResolver;
import io.netty.resolver.NameResolver;
import io.netty.util.concurrent.ImmediateEventExecutor;
import org.slf4j.Logger;

import java.io.InputStream;
import java.net.InetAddress;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.getWithDefault;
import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;
import static com.ericsson.sep.eac.asyncclient.util.HttpUtils.extractContentTypeCharset;
import static java.nio.charset.StandardCharsets.UTF_8;

public abstract class RequestBuilderBase<T extends RequestBuilderBase<T>> {
    private static final Logger LOGGER = LogHelper.getLogger(RequestBuilderBase.class);
    private static final Uri DEFAULT_REQUEST_URL = Uri.create("http://localhost");
    private static NameResolver<InetAddress> DEFAULT_RESOLVER =
        new DefaultNameResolver(ImmediateEventExecutor.INSTANCE);

    protected UriEncoder uriEncoder;
    protected List<RequestParam> queryParams;
    // request fields
    protected String protocol;
    protected Uri uri;
    protected String method;
    protected HttpHeaders headers;
    protected List<RequestParam> formParams;
    protected InputStream streamData;
    protected InetAddress address;
    protected InetAddress localAddress;
    protected String targetHost;
    protected ProxyServer proxyServer;
    protected Auth auth;
    protected int connectionTimeoutMilliSec;
    protected int requestTimeoutMilliSec;
    protected int readTimeoutMilliSec;
    protected Charset charset;
    protected ChannelPoolPartitioning channelPoolPartitioning =
        ChannelPoolPartitioning.PerHostRoundRobinChannelPoolPartitioning.INSTANCE;
    protected NameResolver<InetAddress> nameResolver = DEFAULT_RESOLVER;
    private SslConfig sslConfig;
    private Map<String, String> attributes = new HashMap<>();

    public RequestBuilderBase(String method, boolean isDisableEncoding) {
        this("HTTP/1.1", method, isDisableEncoding, true);
    }

    public RequestBuilderBase(String protocol, String method, boolean isDisableEncoding) {
        this(protocol, method, isDisableEncoding, isDisableEncoding);
    }

    protected RequestBuilderBase(String protocol, String method, boolean isDisableEncoding,
        boolean isValidateHeaders) {
        this(method, isDisableEncoding, isValidateHeaders);
        this.protocol = protocol;
    }

    protected RequestBuilderBase(String method, boolean isDisableEncoding,
        boolean isValidateHeaders) {
        this.method = method;
        this.uriEncoder = UriEncoder.uriEncoder(isDisableEncoding);
        this.headers = new DefaultHttpHeaders(isValidateHeaders);
    }

    protected RequestBuilderBase(Request prototype) {
        this(prototype, false, false);
    }

    protected RequestBuilderBase(Request prototype, boolean isDisableEncoding,
        boolean isValidateHeaders) {
        this.uriEncoder = UriEncoder.uriEncoder(isDisableEncoding);
        this.uri = prototype.getUri();
        this.method = prototype.getMethod();
        this.address = prototype.getAddress();
        this.localAddress = prototype.getLocalAddress();
        this.headers = new DefaultHttpHeaders(isValidateHeaders);
        this.headers.add(prototype.getHeaders());
        if (isNonEmpty(prototype.getFormParams())) {
            this.formParams = new ArrayList<>(prototype.getFormParams());
        }
        this.streamData = prototype.getStreamData();
        this.targetHost = prototype.getTargetHost();
        this.proxyServer = prototype.getProxyServer();
        this.auth = prototype.getAuth();

        this.connectionTimeoutMilliSec = prototype.getConnectionTimeoutMilliSec();
        this.requestTimeoutMilliSec = prototype.getRequestTimeoutMilliSec();
        this.readTimeoutMilliSec = prototype.getReadTimeoutMilliSec();
        this.charset = prototype.getCharset();
        this.channelPoolPartitioning = prototype.getChannelPoolPartitioning();
        this.nameResolver = prototype.getNameResolver();
        this.sslConfig = prototype.getSslConfig();
    }

    private T asType() {
        return (T) this;
    }

    public T setUrl(String url) {
        return setUri(Uri.create(url));
    }

    public T setUri(Uri uri) {
        this.uri = uri;
        return asType();
    }

    public T setProtocol(String protocol) {
        this.protocol = protocol;
        return asType();
    }

    public T setMethod(String method) {
        this.method = method;
        return asType();
    }

    public T setHeader(CharSequence name, Object value) {
        this.headers.set(name, value);
        return asType();
    }

    public T setHeader(CharSequence name, Iterable<?> value) {
        this.headers.set(name, value);
        return asType();
    }

    public T addHeader(CharSequence name, Object value) {
        if (value == null) {
            LOGGER.warn("Header value is null, set it to \"\"");
            value = "";
        }
        this.headers.add(name, value);
        return asType();
    }

    public T addHeader(CharSequence name, Iterable<?> values) {
        this.headers.add(name, values);
        return asType();
    }

    public T setHeaders(HttpHeaders headers) {
        if (headers == null) {
            this.headers.clear();
        } else {
            this.headers = headers;
        }
        return asType();
    }

    public T setHeaders(Map<? extends CharSequence, ? extends Iterable<?>> headers) {
        this.headers.clear();
        if (headers != null) {
            headers.forEach((name, values) -> {
                if (values != null) {
                    values.forEach(value -> {
                        if (value != null) {
                            this.headers.add(name, value);
                        } else {
                            this.headers.add(name, "");
                        }
                    });
                } else {
                    this.headers.add(name, "");
                }
            });
        }
        return asType();
    }

    private void resetBody() {
        this.formParams = null;
        this.streamData = null;
    }

    public T setBody(InputStream streamData) {
        resetBody();
        this.streamData = streamData;
        return asType();
    }

    public T addFormParam(String name, String value) {
        resetBody();
        if (this.formParams == null) {
            this.formParams = new ArrayList<>(1);
        }
        this.formParams.add(new RequestParam(name, value));
        return asType();
    }

    public T setFormParams(Map<String, List<String>> map) {
        return setFormParams(RequestParam.map2ParamList(map));
    }

    public T setFormParams(List<RequestParam> params) {
        resetBody();
        this.formParams = params;
        return asType();
    }


    public T addQueryParam(String name, String value) {
        if (queryParams == null) {
            queryParams = new ArrayList<>(1);
        }
        queryParams.add(new RequestParam(name, value));
        return asType();
    }

    public T addQueryParams(List<RequestParam> params) {
        if (queryParams == null) {
            queryParams = params;
        } else {
            queryParams.addAll(params);
        }
        return asType();
    }

    public T setQueryParams(Map<String, List<String>> map) {
        return setQueryParams(RequestParam.map2ParamList(map));
    }

    public T setQueryParams(List<RequestParam> params) {
        // reset existing query
        if (this.uri != null && isNonEmpty(this.uri.getQuery())) {
            this.uri = this.uri.withNewQuery(null);
        }
        queryParams = params;
        return asType();
    }

    public T setAddress(InetAddress address) {
        this.address = address;
        return asType();
    }

    public T setLocalAddress(InetAddress localAddress) {
        this.localAddress = localAddress;
        return asType();
    }

    public T setTargetHost(String targetHost) {
        this.targetHost = targetHost;
        return asType();
    }

    public T setProxyServer(ProxyServer proxyServer) {
        this.proxyServer = proxyServer;
        return asType();
    }

    public T setAuth(Auth auth) {
        this.auth = auth;
        return asType();
    }

    public T setConnectionTimeoutMilliSec(int connectionTimeoutMilliSec) {
        this.connectionTimeoutMilliSec = connectionTimeoutMilliSec;
        return asType();
    }

    public T setRequestTimeoutMilliSec(int requestTimeoutMilliSec) {
        this.requestTimeoutMilliSec = requestTimeoutMilliSec;
        return asType();
    }

    public T setReadTimeoutMilliSec(int readTimeoutMilliSec) {
        this.readTimeoutMilliSec = readTimeoutMilliSec;
        return asType();
    }

    public T setCharset(Charset charset) {
        this.charset = charset;
        return asType();
    }

    public T setSslConfig(SslConfig config) {
        this.sslConfig = config;
        return asType();
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    private void updateCharset() {
        String contentTypeHeader = headers.get(HttpHeaderNames.CONTENT_TYPE);
        Charset contentTypeCharset = extractContentTypeCharset(contentTypeHeader);
        charset = getWithDefault(contentTypeCharset, getWithDefault(charset, UTF_8));
        if (contentTypeHeader != null && contentTypeHeader.regionMatches(true, 0, "text/", 0, 5)
            && contentTypeCharset == null) {
            // add explicit charset to content-type header
            headers.set(HttpHeaderNames.CONTENT_TYPE,
                contentTypeHeader + "; charset=" + charset.name());
        }
    }

    private Uri encodeUri() {

        Uri tempUri = this.uri;
        if (tempUri == null) {
            LOGGER.debug("setUrl hasn't been invoked. Using {}", DEFAULT_REQUEST_URL);
            tempUri = DEFAULT_REQUEST_URL;
        } else {
            Uri.validateSupportedScheme(tempUri);
        }

        return uriEncoder.encode(tempUri, queryParams);
    }

    public Request build() {
        updateCharset();
        Uri encodedUri = encodeUri();

        return new DefaultRequest(encodedUri, this.protocol, this.method, this.headers,
            this.formParams, this.streamData, this.address, this.localAddress, this.targetHost,
            this.auth, this.proxyServer, this.connectionTimeoutMilliSec,
            this.requestTimeoutMilliSec, this.readTimeoutMilliSec, this.charset,
            this.channelPoolPartitioning, this.nameResolver, this.sslConfig, this.attributes);
    }
}

/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.ssl;

import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.common.StringBuilderPool;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.DefaultSslConfig;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;
import com.ericsson.sep.eac.asyncclient.util.CommonUtils;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import io.netty.buffer.ByteBufAllocator;
import io.netty.handler.codec.http2.Http2SecurityUtil;
import io.netty.handler.ssl.*;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.slf4j.Logger;

import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLParameters;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;
import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.nullOrEmptyString;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public class DefaultSslEngineFactory implements SslEngineFactory {
    private static final Logger LOGGER = LogHelper.getLogger(DefaultSslEngineFactory.class);

    private volatile SslContext sslContext;
    private volatile SslContext sslContextForH2;

    private volatile Cache<String, String> pwdContentCache;
    private volatile Cache<String, File> fileCache;

    @Override
    public SSLEngine newSslEngine(SslConfig config) throws SSLException {
        sslContext = createSslContextBuilder(config).build();
        SSLEngine sslEngine;
        LOGGER.debug("Build http SSL Engine.");
        sslEngine = sslContext.newEngine(ByteBufAllocator.DEFAULT);
        sslEngine.setUseClientMode(true);
        return sslEngine;
    }

    @Override
    public SSLEngine newH2SslEngine(SslConfig config) throws SSLException {
        sslContextForH2 = createH2SslContextBuilder(config).build();
        SSLEngine sslEngine;
        LOGGER.debug("Build http2 SSL Engine.");
        sslEngine = sslContextForH2.newEngine(ByteBufAllocator.DEFAULT);
        sslEngine.setUseClientMode(true);
        return sslEngine;
    }

    @Override
    public void init(SslConfig config) {
        SslConfig sslConfig = config == null ? new DefaultSslConfig.Builder().build() : config;
        pwdContentCache = CacheBuilder.newBuilder().maximumSize(sslConfig.getCacheVolume())
            .expireAfterAccess(sslConfig.getCacheTimeout(), sslConfig.getCacheTimeoutUnit())
            .build();
        fileCache = CacheBuilder.newBuilder().maximumSize(sslConfig.getCacheVolume())
            .expireAfterAccess(sslConfig.getCacheTimeout(), sslConfig.getCacheTimeoutUnit())
            .build();
    }
    //todo: check peerHost&peerPort??

    private SslContextBuilder createH2SslContextBuilder(SslConfig config) throws SSLException {
        SslProvider sslProvider = config.isUseOpenSsl() ? SslProvider.OPENSSL : SslProvider.JDK;
        if (sslProvider == SslProvider.OPENSSL) {
            // check if openSSL support ALPN
            boolean isAlpnSupported = OpenSsl.isAlpnSupported();
            if (!isAlpnSupported) {
                throw new SSLException("Current openSsl does not support ALPN.");
            }
        }
        final SslContextBuilder sslCtxBuilder =
            SslContextBuilder.forClient().sslProvider(sslProvider)
                .ciphers(Http2SecurityUtil.CIPHERS, SupportedCipherSuiteFilter.INSTANCE)
                .applicationProtocolConfig(
                    new ApplicationProtocolConfig(ApplicationProtocolConfig.Protocol.ALPN,
                        // NO_ADVERTISE is currently the only mode supported by both openssl and jdk provider
                        ApplicationProtocolConfig.SelectorFailureBehavior.NO_ADVERTISE,
                        // ACCEPT is currently the only mode supported by both openssl and jdk provider
                        ApplicationProtocolConfig.SelectedListenerFailureBehavior.ACCEPT,
                        ApplicationProtocolNames.HTTP_2, ApplicationProtocolNames.HTTP_1_1));
        setProtocols(config, sslCtxBuilder);
        setKeyAndTrustManager(config, sslCtxBuilder);

        return sslCtxBuilder;
    }

    private SslContextBuilder createSslContextBuilder(SslConfig config) {
        SslContextBuilder builder = SslContextBuilder.forClient();
        SslProvider sslProvider = config.isUseOpenSsl() ? SslProvider.OPENSSL : SslProvider.JDK;
        LOGGER.debug("Use sslProvider: {}", sslProvider.name());
        builder.sslProvider(sslProvider).sessionCacheSize(config.getTlsSessionCacheSize())
            .sessionTimeout(config.getTlsSessionTimeoutMilliSec())
            .ciphers(null, SupportedCipherSuiteFilter.INSTANCE);

        setProtocols(config, builder);
        setKeyAndTrustManager(config, builder);
        return builder;
    }

    private void setProtocols(SslConfig sslConfig, SslContextBuilder sslContextBuilder) {
        boolean isTLS3Support = sslConfig.isTLS13Support();
        if (isTLS3Support) {
            sslContextBuilder.protocols("TLSv1.3");
        }
    }

    private void setKeyAndTrustManager(SslConfig config, SslContextBuilder sslCtxBuilder) {
        String keyFilePath = config.getPrivateKeyFile();
        String certFilePath = config.getCertificateFile();
        String passwordPath = config.getKeyPasswordFile();
        String trustCertCollectionFile = config.getTrustCertFile();
        LOGGER.debug("Get keyFile: {}, certFile: {}, keyPassword: {}", keyFilePath, certFilePath,
            keyFilePath);

        if (isNonEmpty(keyFilePath) && isNonEmpty(certFilePath)) {
            if (isNonEmpty(passwordPath)) {
                String pwdContent = getPasswordContent(passwordPath);
                if (nullOrEmptyString(pwdContent)) {
                    sslCtxBuilder
                        .keyManager(getFileByPath(certFilePath), getFileByPath(keyFilePath),
                            pwdContent);
                }
            } else {
                sslCtxBuilder.keyManager(getFileByPath(certFilePath), getFileByPath(keyFilePath));
            }
        }


        if (config.isAllowInsecureConnection() || AsyncConstants.isTestMode() || CommonUtils
            .nullOrEmptyString(trustCertCollectionFile)) {
            sslCtxBuilder.trustManager(InsecureTrustManagerFactory.INSTANCE);
            LOGGER.debug("Allow TLS insecure connection.");
        } else {
            LOGGER.debug("Build trust certification collection from file: {}",
                trustCertCollectionFile);
            File trustCertFile = fileCache.getIfPresent(trustCertCollectionFile);
            if (trustCertFile == null) {
                trustCertFile = new File(trustCertCollectionFile);
            }
            sslCtxBuilder.trustManager(trustCertFile);
        }
    }

    private File getFileByPath(String filePath) {
        File file = fileCache.getIfPresent(filePath);
        if (file == null) {
            return new File(filePath);
        }
        return file;
    }

    private String getPasswordContent(String passwordFile) {
        String secret = pwdContentCache.getIfPresent(passwordFile);
        if (secret == null) {
            StringBuilder builder = StringBuilderPool.DEFAULT.stringBuilder();
            try (Stream<String> stream = Files.lines(Paths.get(passwordFile))) {
                stream.forEach(builder::append);
            } catch (IOException e) {
                return "";
            }
            secret = builder.toString().trim();
            pwdContentCache.put(passwordFile, secret);
        }
        return secret;
    }

    private void configSslEngine(SSLEngine sslEngine) {
        sslEngine.setUseClientMode(true);
        SSLParameters parameters = sslEngine.getSSLParameters();
        parameters.setEndpointIdentificationAlgorithm("HTTPS");
        sslEngine.setSSLParameters(parameters);
    }
}

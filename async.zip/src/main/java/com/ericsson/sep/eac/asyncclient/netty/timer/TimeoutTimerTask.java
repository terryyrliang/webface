/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.timer;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.util.TimerTask;
import org.slf4j.Logger;

import java.net.InetSocketAddress;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class TimeoutTimerTask implements TimerTask {
    private static final Logger LOGGER = LogHelper.getLogger(TimeoutTimerTask.class);

    protected final AtomicBoolean done = new AtomicBoolean();
    protected final RequestSender requestSender;
    final TimeoutsHolder timeoutsHolder;
    volatile ResponseFuture<?> responseFuture;

    public TimeoutTimerTask(RequestSender requestSender, TimeoutsHolder timeoutsHolder,
        ResponseFuture<?> responseFuture) {
        this.requestSender = requestSender;
        this.timeoutsHolder = timeoutsHolder;
        this.responseFuture = responseFuture;
    }

    protected void expire(String expireMsg, long processTimeInMilliSec) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("{} for {} after {}ms", responseFuture, expireMsg, processTimeInMilliSec);
        }
        requestSender
            .abort(responseFuture.channel(), responseFuture, new TimeoutException(expireMsg));
    }

    public void clean(){
        if (done.compareAndSet(false, true)){
            responseFuture = null;
        }
    }

    protected void addRemoteAddressToExpireInfo(StringBuilder sb){
        InetSocketAddress remoteAddr = timeoutsHolder.remoteAddress();
        sb.append(remoteAddr.getHostName());
        if (! remoteAddr.isUnresolved()){
            sb.append('/').append(remoteAddr.getAddress().getHostAddress());
        }
        sb.append(':').append(remoteAddr.getPort());
    }
}

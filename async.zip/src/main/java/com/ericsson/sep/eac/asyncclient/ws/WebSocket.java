/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.ws;

import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.http.HttpHeaders;

import java.net.SocketAddress;
import java.util.concurrent.Future;

public interface WebSocket {

    HttpHeaders getUpgradeHeaders();

    SocketAddress getRemoteAddress();

    SocketAddress getLocalAddress();

    Future<Void> sendTextMessageToSouthBound(String payload);

    /**
     * send a text frame with finalFragment flag or extension bit
     * if finalFragment is false, the next frame must be sent with sendContinuationFrame
     *
     * @param payload       text payload
     * @param finalFragment the flag shows whether this is the finalFragment frame
     * @param rsv           reserved bits used for protocol extensions
     * @return
     */
    Future<Void> sendTextMessageToSouthBound(String payload, boolean finalFragment, int rsv);

    Future<Void> sendTextMessageToSouthBound(ByteBuf payload, boolean finalFragment, int rsv);


    Future<Void> sendBinaryMessageToSouthBound(byte[] payload);

    /**
     * send a text frame with finalFragment flag or extension bit
     * if finalFragment is false, the next frame must be sent with sendContinuationFrame
     *
     * @param payload
     * @param finalFragment
     * @param rsv
     * @return
     */
    Future<Void> sendBinaryMessageToSouthBound(byte[] payload, boolean finalFragment, int rsv);

    Future<Void> sendBinaryMessageToSouthBound(ByteBuf payload, boolean finalFragment, int rsv);

    Future<Void> sendContinueFrame(String payload, boolean finalFragment, int rsv);

    Future<Void> sendContinueFrame(byte[] payload, boolean finalFragment, int rsv);

    Future<Void> sendContinueFrame(ByteBuf payload, boolean finalFragment, int rsv);


    Future<Void> sendPingFrame();

    Future<Void> sendPingFrame(byte[] payload);

    Future<Void> sendPingFrame(ByteBuf payload);


    Future<Void> sendPongFrame();

    Future<Void> sendPongFrame(byte[] payload);

    Future<Void> sendPongFrame(ByteBuf payload);


    Future<Void> sendCloseFrame();

    Future<Void> sendCloseFrame(int statusCode, String reason);

    boolean isOpen();

    WebSocket addWebSocketListener(WebSocketListener listener);

    WebSocket removeWebSocketListener(WebSocketListener listener);
}

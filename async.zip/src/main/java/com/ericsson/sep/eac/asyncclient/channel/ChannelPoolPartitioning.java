/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.channel;

import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyType;
import com.ericsson.sep.eac.asyncclient.uri.Uri;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public interface ChannelPoolPartitioning {
    Object getPartitionKey(Uri uri, String virtualHost, ProxyServer proxyServer);

    enum PerHostChannelPoolPartitioning implements ChannelPoolPartitioning {

        INSTANCE;

        public Object getPartitionKey(Uri uri, String virtualHost, ProxyServer proxyServer) {
            String targetHostBaseUrl = uri.getBaseUrl();
            if (proxyServer == null) {
                if (virtualHost == null) {
                    return targetHostBaseUrl;
                } else {
                    return new CompositePartitionKey(
                        targetHostBaseUrl,
                        virtualHost,
                        null,
                        0,
                        null);
                }
            } else {
                int proxyPort = uri.isSecured() && proxyServer.getProxyType() == ProxyType.HTTP ?
                    proxyServer.getSecuredPort() :
                    proxyServer.getPort();
                return new CompositePartitionKey(
                    targetHostBaseUrl,
                    virtualHost,
                    proxyServer.getHost(),
                    proxyPort,
                    proxyServer.getProxyType());
            }
        }
    }

    enum PerHostRoundRobinChannelPoolPartitioning implements ChannelPoolPartitioning {

        INSTANCE;
        private ConcurrentHashMap<String, AtomicInteger> roundRobin = new ConcurrentHashMap<>();
        private int subNum = Runtime.getRuntime().availableProcessors();

        private int getIndex(String key) {
            AtomicInteger count = roundRobin.get(key);
            if (count == null) {
                roundRobin.putIfAbsent(key, new AtomicInteger(0));
            }
            return Math.abs(roundRobin.get(key).incrementAndGet() % subNum);
        }

        public Object getPartitionKey(Uri uri, String virtualHost, ProxyServer proxyServer) {
            String targetHostBaseUrl = uri.getBaseUrl();
            if (proxyServer == null) {
                if (virtualHost == null) {
                    return targetHostBaseUrl + ":" + getIndex(targetHostBaseUrl);
                } else {
                    return new CompositePartitionKey(
                            targetHostBaseUrl,
                            virtualHost,
                            null,
                            0,
                            null);
                }
            } else {
                int proxyPort = uri.isSecured() && proxyServer.getProxyType() == ProxyType.HTTP ?
                        proxyServer.getSecuredPort() :
                        proxyServer.getPort();
                return new CompositePartitionKey(
                        targetHostBaseUrl,
                        virtualHost,
                        proxyServer.getHost(),
                        proxyPort,
                        proxyServer.getProxyType());
            }
        }

        public void setSubNum(int subNum) {
            this.subNum = subNum;
        }
    }

    class CompositePartitionKey {
        private final String targetHostBaseUrl;
        private final String targetHost;
        private final String proxyHost;
        private final int proxyPort;
        // TODO: remove this criteria
        private final ProxyType proxyType;

        CompositePartitionKey(String targetHostBaseUrl, String targetHost, String proxyHost, int proxyPort, ProxyType proxyType) {
            this.targetHostBaseUrl = targetHostBaseUrl;
            this.targetHost = targetHost;
            this.proxyHost = proxyHost;
            this.proxyPort = proxyPort;
            this.proxyType = proxyType;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            CompositePartitionKey that = (CompositePartitionKey) o;

            if (proxyPort != that.proxyPort) {
                return false;
            }
            if (! targetHostBaseUrl.equals(that.targetHostBaseUrl)){
                return false;
            }
            if (! targetHost.equals(that.targetHost)){
                return false;
            }
            if (!proxyHost.equals(that.proxyHost)){
                return false;
            }
            return proxyType == that.proxyType;
        }

        @Override
        public int hashCode() {
            int result = targetHostBaseUrl != null ? targetHostBaseUrl.hashCode() : 0;
            result = 31 * result + (targetHost != null ? targetHost.hashCode() : 0);
            result = 31 * result + (proxyHost != null ? proxyHost.hashCode() : 0);
            result = 31 * result + proxyPort;
            result = 31 * result + (proxyType != null ? proxyType.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return "CompositePartitionKey(" +
                "targetHostBaseUrl=" + targetHostBaseUrl +
                ", targetHost=" + targetHost +
                ", proxyHost=" + proxyHost +
                ", proxyPort=" + proxyPort +
                ", proxyType=" + proxyType;
        }
    }
}

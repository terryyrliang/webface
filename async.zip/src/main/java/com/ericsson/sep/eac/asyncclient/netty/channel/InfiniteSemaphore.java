/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;

import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class InfiniteSemaphore extends Semaphore {
    private static final long serialVersionUID = 8933931338459783505L;

    public static final InfiniteSemaphore INSTANCE = new InfiniteSemaphore();

    private InfiniteSemaphore() {
        super(Integer.MAX_VALUE);
    }

    @Override
    public void acquire() {
    }

    @Override
    public void acquireUninterruptibly() {
    }

    @Override
    public boolean tryAcquire() {
        return true;
    }

    @Override
    public boolean tryAcquire(long timeout, TimeUnit unit) throws InterruptedException {
        return true;
    }

    @Override
    public void release() {
    }

    @Override
    public void acquire(int permits) {
    }

    @Override
    public void acquireUninterruptibly(int permits) {
    }

    @Override
    public boolean tryAcquire(int permits) {
        return true;
    }

    @Override
    public boolean tryAcquire(int permits, long timeout, TimeUnit unit) {
        return true;
    }

    @Override
    public void release(int permits) {
    }

    @Override
    public int availablePermits() {
        return Integer.MAX_VALUE;
    }

    @Override
    public int drainPermits() {
        return Integer.MAX_VALUE;
    }

    @Override
    protected void reducePermits(int reduction) {
    }

    @Override
    protected Collection<Thread> getQueuedThreads() {
        return Collections.emptyList();
    }

    @Override
    public boolean isFair() {
        return true;
    }
}

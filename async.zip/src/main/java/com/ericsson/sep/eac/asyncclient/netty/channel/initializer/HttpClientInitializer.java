/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.initializer;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.AsyncClientBaseHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.HttpHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerUtils;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import org.slf4j.Logger;

import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.*;


/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class HttpClientInitializer extends ChannelInitializer<SocketChannel> {
    private static final Logger LOGGER = LogHelper.getLogger(HttpClientInitializer.class);

    private final AsyncClientConfig config;
    private final ChannelManager channelManager;
    private final RequestSender requestSender;

    public HttpClientInitializer(AsyncClientConfig config, RequestSender requestSender,
        ChannelManager channelManager) {
        this.config = config;
        this.requestSender = requestSender;
        this.channelManager = channelManager;
    }

    @Override
    protected void initChannel(SocketChannel ch) {
        ChannelPipeline pipeline = ch.pipeline();
        AsyncClientBaseHandler httpHandler = new HttpHandler(config, requestSender, channelManager);
        if (LOGGER.isDebugEnabled()) {
            pipeline.addFirst(new LoggingHandler(LogLevel.DEBUG));
        }
        pipeline.addLast(HTTP_CLIENT_CODEC, HandlerUtils.newHttpClientCodec(config));
//        pipeline.addLast(HTTP_AGGREGATOR, HandlerUtils.newHttpObjectAggregator(config));
//        pipeline.addLast(CONTENT_DECOMPRESSOR, new HttpContentCompressor());

        pipeline.addLast(ASY_HTTP_HANDLER, httpHandler);
        LOGGER.debug("init httpClient initializer");
    }
}

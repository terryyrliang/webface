/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */
package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.http.EmptyHttpHeaders;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http.cookie.ClientCookieDecoder;
import io.netty.handler.codec.http.cookie.Cookie;
import io.netty.util.ReferenceCountUtil;
import org.slf4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;
import static io.netty.handler.codec.http.HttpHeaderNames.*;
import static java.nio.charset.StandardCharsets.UTF_8;

public class NettyResponse implements Response {
    private static final Logger LOGGER = LogHelper.getLogger(NettyResponse.class);

    private List<HttpResponsePartContent> contentList;
    private final HttpHeaders headers;
    private HttpResponseStatus status;
    private HttpVersion httpVersion = HttpVersion.HTTP_1_1;
    private List<Cookie> cookies;

    public NettyResponse(HttpResponseStatus status, HttpHeaders headers,
        List<HttpResponsePartContent> contentList) {
        this.contentList = contentList;
        this.headers = headers;
        this.status = status;
    }

    public NettyResponse(HttpVersion httpVersion, HttpResponseStatus status, HttpHeaders headers,
        List<HttpResponsePartContent> contentList) {
        this.httpVersion = httpVersion;
        this.contentList = contentList;
        this.headers = headers;
        this.status = status;
    }

    private List<Cookie> buildCookies() {

        List<String> setCookieHeaders = headers.getAll(SET_COOKIE2);

        if (!isNonEmpty(setCookieHeaders)) {
            setCookieHeaders = headers.getAll(SET_COOKIE);
        }

        if (isNonEmpty(setCookieHeaders)) {
            List<Cookie> cookieList = new ArrayList<>(1);
            for (String value : setCookieHeaders) {
                Cookie c = ClientCookieDecoder.STRICT.decode(value);
                if (c != null) {
                    cookieList.add(c);
                }
            }
            return Collections.unmodifiableList(cookieList);
        }

        return Collections.emptyList();
    }

    @Override
    public String getHttpVersion() {
        return httpVersion.text();
    }

    @Override
    public final int getStatusCode() {
        return status.code();
    }

    @Override
    public String getReasonPhase() {
        return status.reasonPhrase();
    }

    @Override
    public void setStatusCode(int statusCode) {
        String reasonPhase = status.reasonPhrase();
        this.status = new HttpResponseStatus(statusCode, reasonPhase);
    }

    @Override
    public void setReasonPhase(String reasonPhase) {
        int statusCode = status.code();
        this.status = new HttpResponseStatus(statusCode, reasonPhase);
    }

    @Override
    public final Uri getUri() {
        //    return status.getUri();
        return null;
    }

    @Override
    public SocketAddress getRemoteAddress() {
        //    return status.getRemoteAddress();
        return null;
    }

    @Override
    public SocketAddress getLocalAddress() {
        //    return status.getLocalAddress();
        return null;
    }

    @Override
    public final String getContentType() {
        return headers != null ? getHeader(CONTENT_TYPE) : null;
    }

    @Override
    public final String getHeader(CharSequence name) {
        return headers != null ? getHeaders().get(name) : null;
    }

    @Override
    public final List<String> getHeaders(CharSequence name) {
        return headers != null ? getHeaders().getAll(name) : Collections.emptyList();
    }

    @Override
    public final HttpHeaders getHeaders() {
        return headers != null ? headers : EmptyHttpHeaders.INSTANCE;
    }

    @Override
    public final boolean isRedirected() {
        switch (status.code()) {
            case 301:
            case 302:
            case 303:
            case 307:
            case 308:
                return true;
            default:
                return false;
        }
    }

    @Override
    public List<Cookie> getCookies() {

        if (headers == null) {
            return Collections.emptyList();
        }

        if (cookies == null) {
            cookies = buildCookies();
        }
        return cookies;
    }

    @Override
    public boolean hasResponseStatus() {
        return status != null;
    }

    @Override
    public boolean hasResponseHeaders() {
        return headers != null && !headers.isEmpty();
    }

    @Override
    public boolean hasResponseBody() {
        return isNonEmpty(contentList);
    }

    @Override
    public void setEntity(InputStream stream) {
        if (contentList == null) {
            contentList = new ArrayList<>(1);
        }
        contentList.clear();
        ByteBuf content = Unpooled.directBuffer();
        try {
            content.writeBytes(stream, stream.available());
            contentList.add(new EagerHttpResponsePartContent(content, true));
        } catch (IOException e) {
            LOGGER.warn("set entity failure", e);
        } finally {
            ReferenceCountUtil.release(content);
        }
    }

    @Override
    public byte[] getResponseBodyAsBytes() {
        return getResponseBodyAsByteBuffer().array();
    }

    @Override
    public ByteBuf getResponseBodyAsByteBuf() {
        return Unpooled.wrappedBuffer(getResponseBodyAsByteBuffer());
    }

    @Override
    public ByteBuffer getResponseBodyAsByteBuffer() {

        int length = 0;
        for (HttpResponsePartContent part : contentList) {
            length += part.length();
        }

        ByteBuffer target = ByteBuffer.wrap(new byte[length]);
        for (HttpResponsePartContent part : contentList) {
            target.put(part.getPartContentBytes());
        }

        target.flip();
        return target;
    }

    @Override
    public String getResponseBody() {
        return getResponseBody(UTF_8);
    }

    @Override
    public String getResponseBody(Charset charset) {
        return new String(getResponseBodyAsBytes(), charset);
    }

    @Override
    public InputStream getResponseBodyAsStream() {
        return new ByteArrayInputStream(getResponseBodyAsBytes());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName()).append(" {").append(getHttpVersion()).append(" ")
            .append(getStatusCode()).append(" ").append(getReasonPhase()).append("\n")
            .append("\theaders=\n");

        for (Map.Entry<String, String> header : getHeaders()) {
            sb.append("\t\t").append(header.getKey()).append(": ").append(header.getValue())
                .append("\n");
        }
        return sb.append("\tbody=\n").append("\t\t").append(getResponseBody()).append("\n")
            .append("}").toString();
    }
}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.channel;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import io.netty.channel.Channel;
import io.netty.util.Timer;
import io.netty.util.TimerTask;
import io.netty.util.*;
import org.slf4j.Logger;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.ericsson.sep.eac.asyncclient.util.AssertUtils.assertNotNull;

/**
 * @author emeezhg
 * @date 1/9/2019
 */
public class DefaultChannelPool implements ChannelPool {
    private static final Logger LOGGER = LogHelper.getLogger(DefaultChannelPool.class);

    private static final AttributeKey<ChannelCreation> CHANNEL_CREATION_ATTRIBUTE_KEY =
        AttributeKey.valueOf("channelCreation");
    private final ConcurrentHashMap<Object, ConcurrentLinkedDeque<IdleChannel>> partitions =
        new ConcurrentHashMap<>();
    private final AtomicBoolean isClosed = new AtomicBoolean(false);
    private final Timer nettyTimer;
    private final int connectionTtl;
    private final boolean connectionTtlEnabled;
    private final int maxIdleTime;
    private final boolean maxIdleTimeEnabled;
    private final long cleanerPeriodMilliSec;
    private final PoolLeaseStrategy poolLeaseStrategy;

    public DefaultChannelPool(AsyncClientConfig config, Timer timer) {
        this(config.getPooledConnectionIdleTimeoutMilliSec(),
            config.getPooledConnectionTtlMilliSec(), timer,
            config.getPooledConnectionClearPeriodMilliSec());
    }

    public DefaultChannelPool(int maxIdleTime, int connectionTtl, Timer timer, int cleanerPeriod) {
        this(maxIdleTime, connectionTtl, PoolLeaseStrategy.LIFO, timer, cleanerPeriod);
    }

    public DefaultChannelPool(int maxIdleTime, int connectionTtl,
        PoolLeaseStrategy poolLeaseStrategy, Timer timer, int cleanerPeriodMilliSec) {
        this.maxIdleTime = maxIdleTime;
        this.connectionTtl = connectionTtl;
        connectionTtlEnabled = connectionTtl > 0;
        this.nettyTimer = timer;
        maxIdleTimeEnabled = maxIdleTime > 0;
        this.poolLeaseStrategy = poolLeaseStrategy;
        this.cleanerPeriodMilliSec = Math.min(cleanerPeriodMilliSec,
            Math.min(connectionTtlEnabled ? connectionTtl : Integer.MAX_VALUE,
                maxIdleTimeEnabled ? maxIdleTime : Integer.MAX_VALUE));
        if (maxIdleTimeEnabled || connectionTtlEnabled) {
            scheduleNewIdleChannelDetector(new IdleChannelWatcherTask());
        }
    }

    private void scheduleNewIdleChannelDetector(TimerTask task) {
        nettyTimer.newTimeout(task, cleanerPeriodMilliSec, TimeUnit.MILLISECONDS);
    }

    private boolean isTtlExpired(Channel channel, long startTime) {
        if (!connectionTtlEnabled) {
            return false;
        }
        ChannelCreation creation = channel.attr(CHANNEL_CREATION_ATTRIBUTE_KEY).get();
        return creation != null && startTime - creation.creationTime >= connectionTtl;
    }

    @Override
    public boolean offer(Object partitionKey, Channel channel) {
        if (isClosed.get()) {
            return false;
        }
        long currentTime = System.currentTimeMillis();
        if (isTtlExpired(channel, currentTime)) {
            return false;
        }

        boolean offered = add(partitionKey, channel, currentTime);
        if (offered && connectionTtlEnabled) {
            registerChannelCreation(partitionKey, channel, currentTime);
        }
        return offered;
    }


    private boolean add(Object partitionKey, Channel channel, long currentTime) {
        ConcurrentLinkedDeque<IdleChannel> partition = partitions.get(partitionKey);
        if (partition == null) {
            partition =
                partitions.computeIfAbsent(partitionKey, key -> new ConcurrentLinkedDeque<>());
        }
        return partition.offerFirst(new IdleChannel(channel, currentTime));
    }

    private void registerChannelCreation(Object partitionKey, Channel channel, long currentTime) {
        Attribute<ChannelCreation> channelCreationAttribute =
            channel.attr(CHANNEL_CREATION_ATTRIBUTE_KEY);
        if (channelCreationAttribute.get() == null) {
            channelCreationAttribute.set(new ChannelCreation(currentTime, partitionKey));
        }
    }

    @Override
    public Channel poll(Object partitionKey) {
        IdleChannel idleChannel = null;
        ConcurrentLinkedDeque<IdleChannel> partition = partitions.get(partitionKey);
        if (partition != null) {
            while (idleChannel == null) {
                idleChannel = poolLeaseStrategy.lease(partition);
                if (idleChannel == null) {
                    break;
                } else if (!ChannelUtils.isChannelActive(idleChannel.channel)) {
                    idleChannel = null;
                    LOGGER.debug("Channel is inactive.");
                } else if (!idleChannel.takeOwnership()) {
                    idleChannel = null;
                    LOGGER.debug(
                        "Could not take ownership of channel, probably in the process of being expired!");
                }
            }
        }
        return idleChannel != null ? idleChannel.channel : null;
    }

    @Override
    public boolean removeAll(Channel channel) {
        ChannelCreation creation =
            connectionTtlEnabled ? channel.attr(CHANNEL_CREATION_ATTRIBUTE_KEY).get() : null;
        return !isClosed.get() && creation != null && partitions.get(creation.partitionKey)
            .remove(new IdleChannel(channel, Long.MIN_VALUE));
    }

    @Override
    public boolean isOpen() {
        return !isClosed.get();
    }

    @Override
    public void destroy() {
        if (isClosed.getAndSet(true)) {
            return;
        }
        partitions.clear();
    }

    @Override
    public void flushPartitions(Predicate<Object> predicate) {
        partitions.forEach((partitionKey, value) -> {
            if (predicate.test(partitionKey)) {
                flustPartition(partitionKey, value);
            }
        });
    }

    private void flustPartition(Object partitionKey, ConcurrentLinkedDeque<IdleChannel> partition) {
        if (partition != null) {
            partitions.remove(partitionKey);
            partition.forEach(idleChannel -> ChannelUtils.close(idleChannel.channel));
        }
    }

    @Override
    public Map<String, Long> getIdleChannelCountPerHost() {
        return partitions.values().stream().flatMap(ConcurrentLinkedDeque::stream)
            .map(idle -> idle.getChannel().remoteAddress())
            .filter(a -> a.getClass() == InetSocketAddress.class).map(a -> (InetSocketAddress) a)
            .map(InetSocketAddress::getHostName)
            .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
    }

    public enum PoolLeaseStrategy {
        LIFO {
            @Override
            public <E> E lease(Deque<E> d) {
                return d.pollFirst();
            }
        }, FIFO {
            @Override
            public <E> E lease(Deque<E> d) {
                return d.pollLast();
            }
        };

        abstract <E> E lease(Deque<E> d);
    }


    private static final class ChannelCreation {
        final long creationTime;
        final Object partitionKey;

        ChannelCreation(long creationTime, Object partitionKey) {
            this.creationTime = creationTime;
            this.partitionKey = partitionKey;
        }
    }


    private static final class IdleChannel {

        private static final AtomicIntegerFieldUpdater<IdleChannel> ownedField =
            AtomicIntegerFieldUpdater.newUpdater(IdleChannel.class, "owned");

        final Channel channel;
        final long startTime;
        @SuppressWarnings("unused")
        private volatile int owned = 0;

        IdleChannel(Channel channel, long startTime) {
            this.channel = assertNotNull(channel, "channel");
            this.startTime = startTime;
        }

        public boolean takeOwnership() {
            return ownedField.getAndSet(this, 1) == 0;
        }

        public Channel getChannel() {
            return channel;
        }

        @Override
        // only depends on channel
        public boolean equals(Object o) {
            return this == o || (o instanceof IdleChannel && channel
                .equals(((IdleChannel) o).channel));
        }

        @Override
        public int hashCode() {
            return channel.hashCode();
        }
    }


    private final class IdleChannelWatcherTask implements TimerTask {

        @Override
        public void run(Timeout timeout) {
            if (isClosed.get()) {
                return;
            }
            if (LOGGER.isDebugEnabled()) {
                partitions.forEach((key, value) -> LOGGER
                    .debug("Get idle channels for key: {} and size: {}", key, value.size()));
            }
            long startTime = System.currentTimeMillis();
            int closeCount = 0;
            int totalCount = 0;
            for (ConcurrentLinkedDeque<IdleChannel> partition : partitions.values()) {
                if (LOGGER.isDebugEnabled()) {
                    totalCount += partition.size();
                }
                List<IdleChannel> closedChannels =
                    closeChannelsBaseExpired(getExpiredChannels(partition, startTime));
                if (!closedChannels.isEmpty()) {
                    partition.removeAll(closedChannels);
                    closeCount += closedChannels.size();
                }
            }
            if (LOGGER.isDebugEnabled()) {
                long duration = System.currentTimeMillis() - startTime;
                LOGGER
                    .debug("Closed {} connections out of total: {} in {}ms", closeCount, totalCount,
                        duration);
            }
            scheduleNewIdleChannelDetector(timeout.task());

        }

        private List<IdleChannel> getExpiredChannels(ConcurrentLinkedDeque<IdleChannel> partition,
            long startTime) {
            List<IdleChannel> expiredChannels = null;
            for (IdleChannel idleChannel : partition) {
                boolean isIdleTimeoutExpired = isIdleTimeoutExpired(idleChannel, startTime);
                boolean isChannelClosed = ChannelUtils.isChannelActive(idleChannel.channel);
                boolean isTtlExpired = isTtlExpired(idleChannel.channel, startTime);

                if (isIdleTimeoutExpired || isChannelClosed || isTtlExpired) {
                    LOGGER.debug(
                        "Candidate expired channel: {} with isIdleTimeoutExpired: {}, isChannelClosed: {}, isTtlExpired: {}",
                        idleChannel.channel, isIdleTimeoutExpired, isChannelClosed, isTtlExpired);
                    if (expiredChannels == null) {
                        expiredChannels = new ArrayList<>(1);
                    }
                    expiredChannels.add(idleChannel);
                }
            }
            return expiredChannels != null ? expiredChannels : Collections.emptyList();
        }

        private boolean isIdleTimeoutExpired(IdleChannel idleChannel, long startTime) {
            return maxIdleTimeEnabled && startTime - idleChannel.startTime >= maxIdleTime;
        }

        private List<IdleChannel> closeChannelsBaseExpired(List<IdleChannel> candidates) {
            List<IdleChannel> closedChannels = null;
            for (int i = 0; i < candidates.size(); i++) {
                // We call takeOwnership here to avoid closing a channel that has just been taken out
                // of the pool, otherwise we risk closing an active connection.
                IdleChannel idleChannel = candidates.get(i);
                if (idleChannel.takeOwnership()) {
                    LOGGER.debug("Closing Idle Channel {}", idleChannel.channel);
                    ChannelUtils.close(idleChannel.channel);
                    if (closedChannels != null) {
                        closedChannels.add(idleChannel);
                    }

                } else if (closedChannels == null) {
                    // first non closeable to be skipped, copy all
                    // previously skipped closeable channels
                    closedChannels = new ArrayList<>(candidates.size());
                    for (int j = 0; j < i; j++) {
                        closedChannels.add(candidates.get(j));
                    }
                }
            }
            return closedChannels != null ? closedChannels : Collections.emptyList();
        }
    }
}

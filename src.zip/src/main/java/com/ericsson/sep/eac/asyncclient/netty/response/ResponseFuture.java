/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.response;

import com.ericsson.sep.eac.asyncclient.Auth;
import com.ericsson.sep.eac.asyncclient.ListenableFuture;
import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.channel.ChannelPoolPartitioning;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelState;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.channel.ConnectionSemaphore;
import com.ericsson.sep.eac.asyncclient.netty.request.NettyRequest;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;
import com.ericsson.sep.eac.asyncclient.netty.timer.TimeoutsHolder;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.handler.codec.http.DefaultHttpResponse;
import org.slf4j.Logger;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.currentMillisTime;

/**
 * @author emeezhg
 * @date 1/10/2019
 */


/**
 * A {@link Future} that can be used to track when an asynchronous HTTP request
 * has been fully processed.
 *
 * @param <V> the result type
 */
public final class ResponseFuture<V> implements ListenableFuture<V> {

    private static final Logger LOGGER = LogHelper.getLogger(ResponseFuture.class);

    //    @SuppressWarnings("rawtypes")
    //    private static final AtomicIntegerFieldUpdater<ResponseFuture> REDIRECT_COUNT_UPDATER =
    //        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "redirectCount");
    //    @SuppressWarnings("rawtypes")
    //    private static final AtomicIntegerFieldUpdater<ResponseFuture> CURRENT_RETRY_UPDATER =
    //        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "currentRetry");
    @SuppressWarnings("rawtypes")
    private static final AtomicIntegerFieldUpdater<ResponseFuture> IS_DONE_FIELD =
        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "isDone");
    @SuppressWarnings("rawtypes")
    private static final AtomicIntegerFieldUpdater<ResponseFuture> IS_CANCELLED_FIELD =
        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "isCancelled");
    @SuppressWarnings("rawtypes")
    private static final AtomicIntegerFieldUpdater<ResponseFuture> IN_AUTH_FIELD =
        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "inAuth");
    @SuppressWarnings("rawtypes")
    private static final AtomicIntegerFieldUpdater<ResponseFuture> IN_PROXY_AUTH_FIELD =
        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "inProxyAuth");
    @SuppressWarnings("rawtypes")
    private static final AtomicIntegerFieldUpdater<ResponseFuture> CONTENT_PROCESSED_FIELD =
        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "contentProcessed");
    @SuppressWarnings("rawtypes")
    private static final AtomicIntegerFieldUpdater<ResponseFuture> ON_THROWABLE_CALLED_FIELD =
        AtomicIntegerFieldUpdater.newUpdater(ResponseFuture.class, "onThrowableCalled");
    @SuppressWarnings("rawtypes")
    private static final AtomicReferenceFieldUpdater<ResponseFuture, TimeoutsHolder>
        TIMEOUTS_HOLDER_FIELD = AtomicReferenceFieldUpdater
        .newUpdater(ResponseFuture.class, TimeoutsHolder.class, "timeoutsHolder");
    @SuppressWarnings("rawtypes")
    private static final AtomicReferenceFieldUpdater<ResponseFuture, Object>
        PARTITION_KEY_LOCK_FIELD = AtomicReferenceFieldUpdater
        .newUpdater(ResponseFuture.class, Object.class, "partitionKeyLock");

    private final long start = currentMillisTime();
    private final ChannelPoolPartitioning connectionPoolPartitioning;
    private final ConnectionSemaphore connectionSemaphore;
    private final ProxyServer proxyServer;
    private final SslConfig sslConfigInRequest;
    //    private final int maxRetry;
    private final CompletableFuture<V> future = new CompletableFuture<>();
    public Throwable pendingException;
    // state mutated from outside the event loop
    // TODO check if they are indeed mutated outside the event loop
    private volatile int isDone = 0;
    private volatile int isCancelled = 0;
    private volatile int inAuth = 0;
    private volatile int inProxyAuth = 0;
    private volatile int statusReceived = 0;
    @SuppressWarnings("unused")
    private volatile int contentProcessed = 0;
    @SuppressWarnings("unused")
    private volatile int onThrowableCalled = 0;
    @SuppressWarnings("unused")
    private volatile TimeoutsHolder timeoutsHolder;
    // partition key, when != null used to release lock in ChannelManager
    private volatile Object partitionKeyLock;
    // volatile where we need CAS ops
    //    private volatile int redirectCount = 0;
    //    private volatile int currentRetry = 0;
    // volatile where we don't need CAS ops
    private volatile long touch = currentMillisTime();
    private volatile ChannelState channelState = ChannelState.NEW;
    // state mutated only inside the event loop
    private Channel channel;
    private boolean keepAlive = true;
    private Request targetRequest;
    private Request currentRequest;
    private NettyRequest nettyRequest;
    private AsyncHandler<V> asyncHandler;
    private boolean contentStreamAlreadyConsumed;
    private boolean reuseChannel;
    private boolean headersAlreadyWrittenOnContinue;
    private boolean dontWriteBodyBecauseExpectContinue;
    private boolean allowConnect;
    private Auth auth;
    private Auth proxyAuth;
    private DefaultHttpResponse defaultHttpResponse;
    private List<ChannelFuture> subFutures = new LinkedList<ChannelFuture>();

    public ResponseFuture(Request originalRequest, AsyncHandler<V> asyncHandler,
        NettyRequest nettyRequest,
        //        int maxRetry,
        ChannelPoolPartitioning connectionPoolPartitioning, ConnectionSemaphore connectionSemaphore,
        ProxyServer proxyServer, SslConfig sslConfigInRequest) {

        this.asyncHandler = asyncHandler;
        this.targetRequest = currentRequest = originalRequest;
        this.nettyRequest = nettyRequest;
        this.connectionPoolPartitioning = connectionPoolPartitioning;
        this.connectionSemaphore = connectionSemaphore;
        this.proxyServer = proxyServer;
        this.sslConfigInRequest = sslConfigInRequest;
        //        this.maxRetry = maxRetry;
    }

    private void releasePartitionKeyLock() {
        if (connectionSemaphore == null) {
            return;
        }

        Object partitionKey = takePartitionKeyLock();
        if (partitionKey != null) {
            connectionSemaphore.releaseChannelLock(partitionKey);
        }
    }

    // Take partition key lock object,
    // but do not release channel lock.
    public Object takePartitionKeyLock() {
        // shortcut, much faster than getAndSet
        if (partitionKeyLock == null) {
            return null;
        }

        return PARTITION_KEY_LOCK_FIELD.getAndSet(this, null);
    }

    // java.util.concurrent.Future

    @Override
    public boolean isDone() {
        return isDone != 0 || isCancelled();
    }

    @Override
    public boolean isCancelled() {
        return isCancelled != 0;
    }

    @Override
    public boolean cancel(boolean force) {
        releasePartitionKeyLock();
        cancelTimeouts();

        if (IS_CANCELLED_FIELD.getAndSet(this, 1) != 0)
            return false;

        // cancel could happen before channel was attached
        if (channel != null) {
            ChannelUtils.setDiscard(channel);
            ChannelUtils.closeChannelSilently(channel);
        }

        if (ON_THROWABLE_CALLED_FIELD.getAndSet(this, 1) == 0) {
            try {
                asyncHandler.onThrowable(new CancellationException());
            } catch (Exception t) {
                LOGGER.warn("Cancel", t);
            }
        }

        future.cancel(false);
        return true;
    }

    @Override
    public V get() throws InterruptedException, ExecutionException {
        return future.get();
    }

    @Override
    public V get(long l, TimeUnit tu)
        throws InterruptedException, TimeoutException, ExecutionException {
        return future.get(l, tu);
    }

    private void loadContent() throws ExecutionException {
        if (future.isDone()) {
            LOGGER.debug("Future has done.");
            try {
                future.get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("Unreachable", e);
            }
        }

        // No more retry
        //        CURRENT_RETRY_UPDATER.set(this, maxRetry);
        if (CONTENT_PROCESSED_FIELD.getAndSet(this, 1) == 0) {
            try {
                future.complete(asyncHandler.onCompleted());
            } catch (Exception ex) {
                if (ON_THROWABLE_CALLED_FIELD.getAndSet(this, 1) == 0) {
                    try {
                        try {
                            asyncHandler.onThrowable(ex);
                        } catch (Exception t) {
                            LOGGER.debug("asyncHandler.onThrowable", t);
                        }
                    } finally {
                        cancelTimeouts();
                    }
                }
                future.completeExceptionally(ex);
            }
        }
        future.getNow(null);
    }

    private boolean terminateAndExit() {
        releasePartitionKeyLock();
        cancelTimeouts();
        this.channel = null;
        this.reuseChannel = false;
        return IS_DONE_FIELD.getAndSet(this, 1) != 0 || isCancelled != 0;
    }

    @Override
    public final void done() {

        if (terminateAndExit()) {
            return;
        }
        try {
            loadContent();
        } catch (Exception t) {
            future.completeExceptionally(t);
        }
    }

    @Override
    public final void abort(final Throwable t) {

        if (terminateAndExit()) {
            return;
        }

        future.completeExceptionally(t);

        if (ON_THROWABLE_CALLED_FIELD.compareAndSet(this, 0, 1)) {
            try {
                asyncHandler.onThrowable(t);
            } catch (Exception te) {
                LOGGER.debug("asyncHandler.onThrowable", te);
            }
        }

    }

    @Override
    public void touch() {
        touch = currentMillisTime();
    }

    @Override
    public ListenableFuture<V> addListener(Runnable listener, Executor exec) {
        if (exec == null) {
            exec = Runnable::run;
        }
        future.whenCompleteAsync((r, v) -> listener.run(), exec);
        return this;
    }

    @Override
    public CompletableFuture<V> toCompletableFuture() {
        return future;
    }

    // INTERNAL

    public Uri getUri() {
        return targetRequest.getUri();
    }

    public ProxyServer getProxyServer() {
        return proxyServer;
    }

    public SslConfig getSslConfigInRequest() {
        return sslConfigInRequest;
    }

    public void cancelTimeouts() {
        TimeoutsHolder ref = TIMEOUTS_HOLDER_FIELD.getAndSet(this, null);
        if (ref != null) {
            //            ref.cancel();
        }
    }

    public final Request getTargetRequest() {
        return targetRequest;
    }

    public void setTargetRequest(Request targetRequest) {
        this.targetRequest = targetRequest;
    }

    public final Request getCurrentRequest() {
        return currentRequest;
    }

    public void setCurrentRequest(Request currentRequest) {
        this.currentRequest = currentRequest;
    }

    public final NettyRequest getNettyRequest() {
        return nettyRequest;
    }

    public final void setNettyRequest(NettyRequest nettyRequest) {
        this.nettyRequest = nettyRequest;
    }

    public final AsyncHandler<V> getAsyncHandler() {
        return asyncHandler;
    }

    public void setAsyncHandler(AsyncHandler<V> asyncHandler) {
        this.asyncHandler = asyncHandler;
    }

    public final boolean isKeepAlive() {
        return keepAlive;
    }

    public final void setKeepAlive(final boolean keepAlive) {
        this.keepAlive = keepAlive;
    }

    //    public int incrementAndGetCurrentRedirectCount() {
    //        return REDIRECT_COUNT_UPDATER.incrementAndGet(this);
    //    }

    public TimeoutsHolder getTimeoutsHolder() {
        return TIMEOUTS_HOLDER_FIELD.get(this);
    }

    public void setTimeoutsHolder(TimeoutsHolder timeoutsHolder) {
        TIMEOUTS_HOLDER_FIELD.set(this, timeoutsHolder);
    }

    public boolean isInAuth() {
        return inAuth != 0;
    }

    public void setInAuth(boolean inAuth) {
        this.inAuth = inAuth ? 1 : 0;
    }

    public boolean isAndSetInAuth(boolean set) {
        return IN_AUTH_FIELD.getAndSet(this, set ? 1 : 0) != 0;
    }

    public boolean isInProxyAuth() {
        return inProxyAuth != 0;
    }

    public void setInProxyAuth(boolean inProxyAuth) {
        this.inProxyAuth = inProxyAuth ? 1 : 0;
    }

    public boolean isAndSetInProxyAuth(boolean inProxyAuth) {
        return IN_PROXY_AUTH_FIELD.getAndSet(this, inProxyAuth ? 1 : 0) != 0;
    }

    public ChannelState getChannelState() {
        return channelState;
    }

    public void setChannelState(ChannelState channelState) {
        this.channelState = channelState;
    }

    public boolean isContentStreamConsumed() {
        return contentStreamAlreadyConsumed;
    }

    public void setContentStreamConsumed(boolean streamConsumed) {
        this.contentStreamAlreadyConsumed = streamConsumed;
    }

    public long getLastTouch() {
        return touch;
    }

    public boolean isHeadersAlreadyWrittenOnContinue() {
        return headersAlreadyWrittenOnContinue;
    }

    public void setHeadersAlreadyWrittenOnContinue(boolean headersAlreadyWrittenOnContinue) {
        this.headersAlreadyWrittenOnContinue = headersAlreadyWrittenOnContinue;
    }

    public boolean isDontWriteBodyBecauseExpectContinue() {
        return dontWriteBodyBecauseExpectContinue;
    }

    public void setDontWriteBodyBecauseExpectContinue(boolean dontWriteBodyBecauseExpectContinue) {
        this.dontWriteBodyBecauseExpectContinue = dontWriteBodyBecauseExpectContinue;
    }

    public boolean isConnectAllowed() {
        return allowConnect;
    }

    public void setConnectAllowed(boolean allowConnect) {
        this.allowConnect = allowConnect;
    }

    public void attachChannel(Channel channel, boolean reuseChannel) {

        // future could have been cancelled first
        if (isDone()) {
            ChannelUtils.closeChannelSilently(channel);
        }

        this.channel = channel;
        this.reuseChannel = reuseChannel;
    }

    public Channel channel() {
        return channel;
    }

    public boolean isReuseChannel() {
        return reuseChannel;
    }

    public void setReuseChannel(boolean reuseChannel) {
        this.reuseChannel = reuseChannel;
    }

    //    public boolean incrementRetryAndCheck() {
    //        return maxRetry > 0 && CURRENT_RETRY_UPDATER.incrementAndGet(this) <= maxRetry;
    //    }

    /**
     * Return true if the {@link Future} can be recovered. There is some scenario
     * where a connection can be closed by an unexpected IOException, and in some
     * situation we can recover from that exception.
     *
     * @return true if that {@link Future} cannot be recovered.
     */
    public boolean isReplayPossible() {
        return !isDone() && !(ChannelUtils.isChannelActive(channel) && !"https"
            .equalsIgnoreCase(getUri().getScheme())) && inAuth == 0 && inProxyAuth == 0;
    }

    public long getStart() {
        return start;
    }

    public Object getPartitionKey() {
        return connectionPoolPartitioning
            .getPartitionKey(targetRequest.getUri(), targetRequest.getTargetHost(), proxyServer);
    }

    public void acquirePartitionLockLazily() throws IOException {
        if (connectionSemaphore == null || partitionKeyLock != null) {
            return;
        }

        Object partitionKey = getPartitionKey();
        connectionSemaphore.acquireChannelLock(partitionKey);
        Object prevKey = PARTITION_KEY_LOCK_FIELD.getAndSet(this, partitionKey);
        if (prevKey != null) {
            // self-check

            connectionSemaphore.releaseChannelLock(prevKey);
            releasePartitionKeyLock();

            throw new IllegalStateException(
                "Trying to acquire partition lock concurrently. Please report.");
        }

        if (isDone()) {
            // may be cancelled while we acquired a lock
            releasePartitionKeyLock();
        }
    }

    public Auth getAuth() {
        return auth;
    }

    public void setAuth(Auth auth) {
        this.auth = auth;
    }

    public Auth getProxyAuth() {
        return proxyAuth;
    }

    public void setProxyAuth(Auth proxyAuth) {
        this.proxyAuth = proxyAuth;
    }

    @Override
    public String toString() {
        return "ResponseFuture{" + "proxyServer=" + proxyServer + ", sslConfigInRequest="
            + sslConfigInRequest + ", future=" + future + ", isDone=" + isDone + ", isCancelled="
            + isCancelled + ", inAuth=" + inAuth + ", inProxyAuth=" + inProxyAuth
            + ", targetRequest=" + targetRequest + ", currentRequest=" + currentRequest
            + ", asyncHandler=" + asyncHandler + ", reuseChannel=" + reuseChannel + ", auth=" + auth
            + ", proxyAuth=" + proxyAuth + '}';
    }

    public DefaultHttpResponse getDefaultHttpResponse() {
        return defaultHttpResponse;
    }

    public void setDefaultHttpResponse(DefaultHttpResponse defaultHttpResponse) {
        this.defaultHttpResponse = defaultHttpResponse;
    }

    public List<ChannelFuture> getSubFutures() {
        return subFutures;
    }
}


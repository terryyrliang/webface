/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.util;

import com.ericsson.sep.eac.asyncclient.RequestParam;
import com.ericsson.sep.eac.asyncclient.common.StringBuilderPool;
import org.slf4j.Logger;

import java.io.Closeable;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static java.nio.charset.StandardCharsets.US_ASCII;
import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public class CommonUtils {

    private CommonUtils() {
    }

    public static long currentMillisTime() {
        return System.currentTimeMillis();
    }

    public static <T> T getWithDefault(T value, T def) {
        return value == null ? def : value;
    }

    public static boolean nullOrEmptyString(String str) {
        return (str == null) || "".equals(str.trim());
    }

    public static final String EMPTY_STRING = "";

    public static <T> List<T> newList() {
        return new ArrayList<T>();
    }

    public static <T> List<T> newList(T t) {
        List<T> list = new ArrayList<T>();
        list.add(t);
        return list;
    }

    public static boolean isNonEmpty(Collection<?> collection) {
        return collection != null && !collection.isEmpty();
    }

    public static boolean isNonEmpty(String string) {
        return !isEmpty(string);
    }

    public static boolean isEmpty(String string) {
        return string == null || string.isEmpty();
    }


    public static String nullToEmpty(Object obj) {
        return (obj == null) ? "" : obj.toString();
    }


    public static int toNumber(Object obj) {
        return (obj == null) ? 0 : Integer.parseInt(obj.toString());
    }

    public static void closeSilently(Closeable closeable) {
        if (closeable != null)
            try {
                closeable.close();
            } catch (IOException e) {
                //
            }
    }

    public static void logAndThrowIllegalStateException(Logger logger, String errMsg) {
        logger.error(errMsg);
        throw new IllegalStateException(errMsg);
    }

    public static String toHexString(byte[] data) {
        StringBuilder buffer = StringBuilderPool.DEFAULT.stringBuilder();
        for (byte aData : data) {
            buffer.append(Integer.toHexString((aData & 0xf0) >>> 4));
            buffer.append(Integer.toHexString(aData & 0x0f));
        }
        return buffer.toString();
    }

    public static ByteBuffer urlEncodeFormParams(List<RequestParam> params, Charset charset) {
        return charSequence2ByteBuffer(doUrlEncodeFormParams(params, charset), US_ASCII);
    }

    private static StringBuilder doUrlEncodeFormParams(List<RequestParam> params, Charset charset) {
        StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
        params.forEach(
            param -> encodeAndAppendFormParam(sb, param.getName(), param.getValue(), charset));
        sb.setLength(sb.length() - 1);
        return sb;
    }

    private static void encodeAndAppendFormParam(StringBuilder sb, String name, String value,
        Charset charset) {
        encodeAndAppendFormField(sb, name, charset);
        if (value != null) {
            sb.append('=');
            encodeAndAppendFormField(sb, value, charset);
        }
        sb.append('&');
    }

    private static void encodeAndAppendFormField(StringBuilder sb, String field, Charset charset) {
        if (charset.equals(UTF_8)) {
            Utf8UrlEncoder.encodeAndAppendFormElement(sb, field);
        } else {
            try {
                sb.append(URLEncoder.encode(field, charset.name()));
            } catch (UnsupportedEncodingException ignored) {

            }
        }
    }

    public static byte[] byteBuffer2ByteArray(ByteBuffer bb) {
        byte[] rawBase = new byte[bb.remaining()];
        bb.get(rawBase);
        return rawBase;
    }

    public static byte[] charSequence2Bytes(CharSequence sb, Charset charset) {
        ByteBuffer bb = charSequence2ByteBuffer(sb, charset);
        return byteBuffer2ByteArray(bb);
    }

    public static ByteBuffer charSequence2ByteBuffer(CharSequence cs, Charset charset) {
        return charset.encode(CharBuffer.wrap(cs));
    }

    public static void appendBase16(StringBuilder buf, byte[] bytes) {
        int base = 16;
        for (byte b : bytes) {
            int bi = 0xff & b;
            int c = '0' + (bi / base) % base;
            if (c > '9') {
                c = 'a' + (c - '0' - 10);
            }
            buf.append((char) c);
            c = '0' + bi % base;
            if (c > '9') {
                c = 'a' + (c - '0' - 10);
            }
            buf.append((char) c);
        }
    }

    private static final ThreadLocal<MessageDigest> MD5_MESSAGE_DIGESTS =
        ThreadLocal.withInitial(() -> {
            try {
                return MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException e) {
                throw new InternalError("MD5 not supported on this platform");
            }
        });

    private static final ThreadLocal<MessageDigest> SHA1_MESSAGE_DIGESTS =
        ThreadLocal.withInitial(() -> {
            try {
                return MessageDigest.getInstance("SHA1");
            } catch (NoSuchAlgorithmException e) {
                throw new InternalError("SHA1 not supported on this platform");
            }
        });

    public static MessageDigest pooledMd5MessageDigest() {
        MessageDigest md = MD5_MESSAGE_DIGESTS.get();
        md.reset();
        return md;
    }

    public static MessageDigest pooledSha1MessageDigest() {
        MessageDigest md = SHA1_MESSAGE_DIGESTS.get();
        md.reset();
        return md;
    }

    public static <T extends Throwable> T unknownStackTrace(T t, Class<?> clazz, String method) {
        t.setStackTrace(
            new StackTraceElement[] {new StackTraceElement(clazz.getName(), method, null, -1)});
        return t;
    }
}

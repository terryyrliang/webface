/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import org.slf4j.Logger;

public abstract class SimpleChannelFutureListener implements ChannelFutureListener {
    private static final Logger LOGGER = LogHelper.getLogger(SimpleChannelFutureListener.class);
    @Override
    public void operationComplete(ChannelFuture channelFuture) {
        Channel channel = channelFuture.channel();
        if (channelFuture.isSuccess()){
            LOGGER.debug("channelFuture is success");
            onSuccess(channel);
        } else {
            LOGGER.debug("channelFuture is failure");
            onFailure(channel, channelFuture.cause());
        }
    }

    public abstract void onSuccess(Channel channel);

    public abstract void onFailure(Channel channel, Throwable throwable);
}

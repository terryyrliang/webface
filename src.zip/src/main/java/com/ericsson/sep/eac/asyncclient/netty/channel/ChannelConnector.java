/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;

import com.ericsson.sep.eac.asyncclient.AsyncClientState;
import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.SimpleChannelFutureListener;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2Handler;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.DefaultFullHttpRequest;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpVersion;
import org.slf4j.Logger;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.ASY_H2_HANDLER;

public class ChannelConnector {
    private static final Logger LOGGER = LogHelper.getLogger(ChannelConnector.class);

    private static final AtomicIntegerFieldUpdater<ChannelConnector> I_UPDATE =
        AtomicIntegerFieldUpdater.newUpdater(ChannelConnector.class, "i");

    private final AsyncHandler<?> asyncHandler;
    private final InetSocketAddress localAddress;
    private final List<InetSocketAddress> remoteAddresses;
    private final AsyncClientState clientState;
    private volatile int i = 0;

    public ChannelConnector(AsyncHandler<?> asyncHandler, InetAddress localAddress,
        List<InetSocketAddress> remoteAddresses, AsyncClientState clientState) {
        this.asyncHandler = asyncHandler;
        this.localAddress = localAddress != null ? new InetSocketAddress(localAddress, 0) : null;
        this.remoteAddresses = remoteAddresses;
        this.clientState = clientState;
    }

    public void connect(final Bootstrap bootstrap, final ConnectListener<?> listener) {
        final InetSocketAddress remoteAddress = remoteAddresses.get(i);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("try to connect:{} ", remoteAddress);
        }
        try {
            asyncHandler.onTcpConnectAttempt(remoteAddress);
        } catch (Exception e) {
            LOGGER.error("onTcpConnectAttempt failure", e);
            listener.onFailure(null, e);
            return;
        }
        try {
            doConnect(bootstrap, listener, remoteAddress);
        } catch (RejectedExecutionException e) {
            LOGGER.warn("connect remote {} exception", remoteAddress);
            if (clientState.isClosed()) {
                LOGGER.warn("connect failure because engine is shutting down");
            } else {
                listener.onFailure(null, e);
            }
        }
    }

    private void doConnect(Bootstrap bootstrap, ConnectListener<?> listener,
        InetSocketAddress remoteAddress) {
        LOGGER.debug("doConnect backend: {}", remoteAddress);
        bootstrap.connect(remoteAddress, localAddress)
                .addListener(new SimpleChannelFutureListener() {
                    @Override
                    public void onSuccess(Channel outChannel) {
                        LOGGER.debug("connect remote address success");
                        try {
                            asyncHandler.onTcpConnectSuccess(remoteAddress, outChannel);
                        } catch (Exception e) {
                            LOGGER
                                    .error("onTcpConnectSuccess failure to remoteAddress:{}", remoteAddress,
                                            e);
                            listener.onFailure(outChannel, e);
                            return;
                        }
                        Uri uri = listener.getFuture().getTargetRequest().getUri();
                        if (uri.isHttp2() && 1 == 2) {
                            DefaultFullHttpRequest upgradeRequest =
                                    new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.GET, "/", Unpooled.EMPTY_BUFFER);

                            String hostString = remoteAddress.getHostString();
                            if (hostString == null) {
                                hostString = remoteAddress.getAddress().getHostAddress();
                            }
                            upgradeRequest.headers().set(HttpHeaderNames.HOST, hostString + ':' + remoteAddress.getPort());
                            outChannel.attr(AsyncConstants.CONNECT_LISTENER_ATTR).set(listener);
                            Http2Handler http2Handler = (Http2Handler) outChannel.pipeline().remove(ASY_H2_HANDLER);
                            outChannel.attr(AsyncConstants.H2_HANDLER).set(http2Handler);
                            outChannel.attr(AsyncConstants.FIRST_REQUEST_WITH_BODY).set("yes");
                            outChannel.writeAndFlush(upgradeRequest);
                        } else {
                            listener.onSuccess(outChannel, remoteAddress);
                        }
                    }

                    @Override
                    public void onFailure(Channel channel, Throwable throwable) {
                        LOGGER.debug("connect remote address failure");
                        try {
                            asyncHandler.onTcpConnectFailure(remoteAddress, throwable);
                        } catch (Exception e) {
                            LOGGER
                                    .error("onTcpConnectFailure failure to remoteAddress:{}", remoteAddress,
                                            e);
                            listener.onFailure(channel, e);
                            return;
                        }
                        boolean retry = pickNextRemoteAddress();
                        if (retry) {
                            LOGGER.debug("try to connect next remote address");
                            ChannelConnector.this.connect(bootstrap, listener);
                        } else {
                            listener.onFailure(channel, throwable);
                        }
                    }
                });
    }

    private boolean pickNextRemoteAddress() {
        I_UPDATE.incrementAndGet(this);
        return i < remoteAddresses.size();
    }
}

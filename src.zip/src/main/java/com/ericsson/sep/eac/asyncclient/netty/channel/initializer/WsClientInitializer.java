/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.initializer;

import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.WebSocketHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerUtils;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.websocketx.extensions.compression.WebSocketClientCompressionHandler;

import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.*;


/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class WsClientInitializer extends ChannelInitializer<SocketChannel> {

    private final AsyncClientConfig config;
    private final RequestSender requestSender;
    private final ChannelManager channelManager;
    private final WebSocketHandler wsHandler;

    public WsClientInitializer(AsyncClientConfig config, RequestSender requestSender,
        ChannelManager channelManager) {
        this.config = config;
        this.requestSender = requestSender;
        this.channelManager = channelManager;
        this.wsHandler = new WebSocketHandler(config, requestSender, channelManager);
    }

    @Override
    protected void initChannel(SocketChannel ch) {
        ChannelPipeline pipeline = ch.pipeline();
        pipeline.addLast(HTTP_CLIENT_CODEC, HandlerUtils.newHttpClientCodec(config));
        pipeline.addLast(HTTP_AGGREGATOR, HandlerUtils.newHttpObjectAggregator(config));
        pipeline.addLast(WS_CLIENT_COMPRESSION, WebSocketClientCompressionHandler.INSTANCE);
        pipeline.addLast(ASY_WS_HANDLER, wsHandler);
    }

    public WebSocketHandler getWsHandler() {
        return wsHandler;
    }
}

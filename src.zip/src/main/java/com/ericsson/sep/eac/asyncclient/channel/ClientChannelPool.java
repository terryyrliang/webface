/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.channel;

import io.netty.channel.Channel;

import java.util.Map;
import java.util.function.Predicate;

/**
 * @author emeezhg
 * @date 1/9/2019
 */
public interface ClientChannelPool {

    /**
     * Add a channel to the pool
     * @param partitionKey the key to retrieve the cached channel
     * @param channel an I/O Channel
     * @return true if added
     */
    boolean offer(Object partitionKey, Channel channel);


    /**
     * Remove the channel associated with the uri
     * @param partitionKey the key when invoking add
     * @return the channel associated with the uri
     */
    Channel poll(Object partitionKey);

    /**
     * Remove all channels from the cache.
     * A channel might have been associated with several uri
     * @param channel
     * @return true if the channel has been removed
     */
    boolean removeAll(Channel channel);

    /**
     * Implementation can decide based on rules to allow
     * @return true if a channel can be cached
     */
    boolean isOpen();

    /**
     * Destroy all cached channels by this instance
     */
    void destroy();

    /**
     * Flush partitions based on a predicate
     *
     * @param predicate the predicate
     */
    void flushPartitions(Predicate<Object> predicate);

    /**
     * @return The number of idle channels per host.
     */
    Map<String, Long> getIdleChannelCountPerHost();
}

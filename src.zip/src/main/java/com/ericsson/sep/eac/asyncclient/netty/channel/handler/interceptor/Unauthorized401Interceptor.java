/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler.interceptor;

import com.ericsson.sep.eac.asyncclient.Auth;
import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.RequestBuilder;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelState;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.util.AuthUtils;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.DefaultHttpHeaders;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponse;
import org.slf4j.Logger;

import java.util.List;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isEmpty;


/**
 * @author emeezhg
 * @date 12/21/2018
 */
public class Unauthorized401Interceptor {
    private static final Logger LOGGER = LogHelper.getLogger(Unauthorized401Interceptor.class);

    private final ChannelManager channelManager;
    private final RequestSender requestSender;

    public Unauthorized401Interceptor(ChannelManager channelManager, RequestSender requestSender) {
        this.channelManager = channelManager;
        this.requestSender = requestSender;
    }

    public boolean isExitAfterHandling401(final Channel channel, final ResponseFuture<?> future,
        HttpResponse response) {
        Request request = future.getCurrentRequest();
        Auth auth = request.getAuth();

        if (auth == null) {
            LOGGER.debug("Can't handle 401 as there is no realm.");
            return false;
        }
        LOGGER.debug("Get future inAuth:{}", future.isInAuth());
        if (future.isAndSetInAuth(true)) {
            LOGGER.info("Can't handle 401 as auth was already performed.");
            return false;
        }

        List<String> wwwAuthHeaders = response.headers().getAll(HttpHeaderNames.WWW_AUTHENTICATE);
        if (wwwAuthHeaders == null || wwwAuthHeaders.isEmpty()) {
            LOGGER.info("Can't handle 401 since response doesn't contain WWW-Authenticate headers.");
            return false;
        }
        future.setChannelState(ChannelState.NEW);
        HttpHeaders newRequestHeaders = new DefaultHttpHeaders(false).add(request.getHeaders());
        if (auth.getScheme() == Auth.AuthScheme.DIGEST) {
            String digestHeader = AuthUtils.getHeaderWithPrefix(wwwAuthHeaders, "Digest");
            if (isEmpty(digestHeader)) {
                LOGGER.info(
                    "Can't handle 401 with Digest realm as WWW-Authenticate headers don't match.");
                return false;
            }
            Auth newDigestRealm =
                AuthUtils.auth(auth).setUri(request.getUri()).setMethodName(request.getMethod())
                    .setUsePreemptiveAuth(true).parseWWWAuthenticateHeader(digestHeader).build();
            future.setAuth(newDigestRealm);
        } else {
            throw new IllegalStateException("Only support Digest Authentication.");
        }
        final Request newRequest =
            new RequestBuilder(request).setHeaders(newRequestHeaders).build();
        LOGGER.debug("Sending digest authentication request to {}", request.getUrl());
        if (future.isKeepAlive()) {
            future.setReuseChannel(true);
            requestSender.getChannelAndExecNextRequest(channel, future, newRequest, null);
        } else {
            channelManager.closeChannel(channel);
            requestSender.sendNextRequest(newRequest, future);
        }
        return true;
    }

}

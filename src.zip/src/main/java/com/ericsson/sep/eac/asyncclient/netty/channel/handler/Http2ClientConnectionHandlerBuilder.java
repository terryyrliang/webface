package com.ericsson.sep.eac.asyncclient.netty.channel.handler;

import io.netty.handler.codec.http2.AbstractHttp2ConnectionHandlerBuilder;
import io.netty.handler.codec.http2.Http2Connection;
import io.netty.handler.codec.http2.Http2ConnectionDecoder;
import io.netty.handler.codec.http2.Http2ConnectionEncoder;
import io.netty.handler.codec.http2.Http2FrameListener;
import io.netty.handler.codec.http2.Http2FrameLogger;
import io.netty.handler.codec.http2.Http2Settings;

public class Http2ClientConnectionHandlerBuilder
        extends AbstractHttp2ConnectionHandlerBuilder<Http2ClientConnectionHandler, Http2ClientConnectionHandlerBuilder> {

    public Http2ClientConnectionHandler build() {
        return (Http2ClientConnectionHandler) super.build();
    }

    public Http2ClientConnectionHandlerBuilder connection(Http2Connection connection) {
        return (Http2ClientConnectionHandlerBuilder) super.connection(connection);
    }

    public Http2ClientConnectionHandlerBuilder frameListener(Http2FrameListener frameListener) {
        return (Http2ClientConnectionHandlerBuilder) super.frameListener(frameListener);
    }

    public Http2ClientConnectionHandlerBuilder frameLogger(Http2FrameLogger frameLogger) {
        return (Http2ClientConnectionHandlerBuilder) super.frameLogger(frameLogger);
    }

    public Http2ClientConnectionHandlerBuilder initialSettings(Http2Settings settings) {
        return (Http2ClientConnectionHandlerBuilder) super.initialSettings(settings);
    }

    protected Http2ClientConnectionHandler build(Http2ConnectionDecoder decoder, Http2ConnectionEncoder encoder, Http2Settings initialSettings)
            throws Exception {
        Http2ClientConnectionHandler handler = new Http2ClientConnectionHandler(decoder, encoder, initialSettings);
        frameListener(frameListener());
        return handler;
    }
}

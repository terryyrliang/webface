/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.handler.AsyncCompletionHandlerBase;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;

public class BoundRequestBuilder extends RequestBuilderBase<BoundRequestBuilder>{
    private final AsyncClient client;

    public BoundRequestBuilder(AsyncClient client, String method, boolean isDisableEncoding) {
        super(method, isDisableEncoding);
        this.client = client;
    }

    protected BoundRequestBuilder(AsyncClient client, String method, boolean isDisableEncoding,
        boolean isValidateHeaders) {
        super(method, isDisableEncoding, isValidateHeaders);
        this.client = client;
    }

    protected BoundRequestBuilder(AsyncClient client, Request prototype) {
        super(prototype);
        this.client = client;
    }

    protected BoundRequestBuilder(AsyncClient client, Request prototype, boolean isDisableEncoding,
        boolean isValidateHeaders) {
        super(prototype, isDisableEncoding, isValidateHeaders);
        this.client = client;
    }

    public <T> ListenableFuture<T> execute(AsyncHandler<T> asyncHandler){
        return client.executeRequest(build(), asyncHandler);
    }

    public ListenableFuture<Response> execute() {
        return client.executeRequest(build(), new AsyncCompletionHandlerBase());
    }

}

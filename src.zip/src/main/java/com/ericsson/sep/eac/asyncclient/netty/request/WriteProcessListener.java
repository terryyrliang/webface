/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.request;

import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.channel.ChannelProgressiveFuture;
import io.netty.channel.ChannelProgressiveFutureListener;

public class WriteProcessListener extends WriteListener implements
    ChannelProgressiveFutureListener {
    private final long expectedTotalAmount;
    private long lastProcess = 0L;

    public WriteProcessListener(ResponseFuture<?> future, boolean isNotifyHeaders,
        long expectedTotalAmount) {
        super(future, isNotifyHeaders);
        this.expectedTotalAmount = expectedTotalAmount;
    }

    /**
     * @param progress the progress of the operation so far (cumulative)
     * @param total the number that signifies the end of the operation when {@code progress} reaches at it.
     *      {@code -1} if the end of operation is unknown.
     * @throws Exception
     */
    @Override
    public void operationProgressed(ChannelProgressiveFuture progressiveFuture, long progress, long total) throws Exception {
        future.touch();
        if (processAsyncHandler != null && !isNotifyHeaders){
            long currentLastProcess = lastProcess;
            lastProcess = progress;
            if (total <0){
                total = expectedTotalAmount;
            }
            if (progress != currentLastProcess){
                processAsyncHandler.onContentWriteProcess(progress - currentLastProcess, progress, total);
            }


        }
    }

    @Override
    public void operationComplete(ChannelProgressiveFuture future) {
        operationComplete(future.channel(), future.cause());
    }
}

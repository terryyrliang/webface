/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler;

import com.ericsson.sep.eac.asyncclient.HttpResponsePartContent;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.handler.codec.DecoderResultProvider;
import io.netty.handler.codec.http.*;
import io.netty.util.CharsetUtil;

@ChannelHandler.Sharable
public class HttpHandler extends AsyncClientBaseHandler {

    public HttpHandler(AsyncClientConfig config, RequestSender requestSender,
        ChannelManager channelManager) {
        super(config, requestSender, channelManager);
    }

    @Override
    public void handleRead(Channel channel, ResponseFuture<?> future, Object receivedMsg) {
        LOGGER.debug("Http handler received Message: {}", receivedMsg);
        if (future.isDone()) {
            LOGGER.debug("future is already done");
            channelManager.closeChannel(channel);
            return;
        }
        AsyncHandler<?> handler = future.getAsyncHandler();
        try {
            if (receivedMsg instanceof DecoderResultProvider) {
                DecoderResultProvider decoderResultProvider = (DecoderResultProvider) receivedMsg;
                Throwable throwable = decoderResultProvider.decoderResult().cause();
                if (throwable != null) {
                    handleReadFailure(channel, future, throwable);
                    return;
                }
            }
            if (receivedMsg instanceof HttpResponse) {
                LOGGER.debug("Received http response.");
                handleHttpResponse((HttpResponse) receivedMsg, channel, future, handler);
            } else if (receivedMsg instanceof HttpContent) {
                LOGGER.debug("Received http content.");
                handleHttpContent((HttpContent) receivedMsg, channel, future, handler);
            }
        } catch (Exception e) {
            handleReadFailure(channel, future, e);
        }
    }

    @Override
    public void handleChannelInactive(ResponseFuture<?> future) {
    }

    @Override
    public void handleException(ResponseFuture<?> future, Throwable cause) {

    }

    private void handleHttpResponse(HttpResponse response, Channel channel,
        ResponseFuture<?> future, AsyncHandler<?> asyncHandler) {
        LOGGER.debug("Handle http response: {}", response);
        HttpRequest httpRequest = future.getNettyRequest().getHttpRequest();
        LOGGER.debug("Request: {} \n\nResponse: {}", httpRequest, response);
        future.setKeepAlive(config.isKeepAlive());
        handleHttpVersion(asyncHandler, response.protocolVersion());
        if (!interceptors.isExitAfterIntercept(channel, future, response)) {
            boolean abort = abortAfterHandlingStatusAndHeaders(asyncHandler, response.status(),
                response.headers());
            LOGGER.debug("Check http response abort: {}", abort);
            if (abort) {
                finishUpdate(future, channel, true);
            }
        }
    }

    private void handleHttpContent(HttpContent content, Channel channel, ResponseFuture<?> future,
        AsyncHandler<?> asyncHandler) {
        LOGGER.debug("Handle http content.");
        boolean abort = false;
        boolean isLastContent = content instanceof LastHttpContent;
        LOGGER.debug("It is last: {}", isLastContent);

        if (isLastContent) {
            LOGGER.debug("Handle last content.");
            LastHttpContent lastHttpContent = (LastHttpContent) content;
            HttpHeaders trailingHeaders = lastHttpContent.trailingHeaders();
            LOGGER.debug("Get trailing headers: {}", trailingHeaders);
            if (!trailingHeaders.isEmpty()) {
                abort = asyncHandler.onTrailingHeadersReceived(trailingHeaders)
                    == AsyncHandler.State.ABORT;
                LOGGER.debug("Trailing header abort: {}", abort);

            }
        }
        LOGGER.debug("Handle http content abort: {}", abort);
        ByteBuf contentBuf = content.content();
        LOGGER.debug("Received http response content: {}", contentBuf.toString(CharsetUtil.UTF_8));
        if (!abort && (contentBuf.isReadable() || isLastContent)) {
            HttpResponsePartContent partContent = config.getResponseBodyPartFactory()
                .newResponsePartContent(contentBuf, isLastContent);
            abort = asyncHandler.onPartContentReceived(partContent) == AsyncHandler.State.ABORT;
            LOGGER.debug("Handle http content with abort: {}", abort);
        }

        if (abort || isLastContent) {
            boolean close = abort || !future.isKeepAlive();
            LOGGER.debug("Finish update with close: {}", close);
            finishUpdate(future, channel, close);
        }
    }

}

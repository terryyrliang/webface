package com.ericsson.sep.eac.asyncclient.netty.channel.initializer;

import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2ClientConnectionHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2ClientConnectionHandlerBuilder;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2Handler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2SettingsHandler;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import io.netty.channel.*;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http2.*;
import io.netty.handler.timeout.IdleStateEvent;
import org.slf4j.Logger;

public class Http2cDirectClientInitializer extends ChannelInitializer<SocketChannel> {
    private static final Logger LOGGER = LogHelper.getLogger(Http2cDirectClientInitializer.class);
    private final int maxContentLength;
    private Http2ClientConnectionHandler connectionHandler;
    private Http2Handler responseHandler;
    private Http2Settings clientSettings = Http2Settings.defaultSettings();
    private Http2SettingsHandler settingsHandler;
    private Http2EventAdapter eventListener = new Http2EventAdapter();
    private Float windowUpdateRatio;
    private Integer initialFlowControlWindowUpdate = null;

    public Http2cDirectClientInitializer(AsyncClientConfig config, RequestSender sender,
                                         ChannelManager channelManager) {
        this.maxContentLength = config.getResponseMaxContentLengthKB() * 1024;
        this.windowUpdateRatio = config.getWindowUpdateRatio();
        this.initialFlowControlWindowUpdate = config.getInitialFlowControlWindowUpdate();
        this.responseHandler = new Http2Handler(config, sender, channelManager);
    }

    public Http2cDirectClientInitializer eventListener(Http2EventAdapter eventListener) {
        if (eventListener != null) {
            this.eventListener = eventListener;
        }
        return this;
    }

    public Http2cDirectClientInitializer clientSettings(Http2Settings clientSettings) {
        if (clientSettings != null) {
            this.clientSettings = clientSettings;
        }
        return this;
    }

    public void initChannel(SocketChannel ch) throws Exception {
        DefaultHttp2Connection connection = new DefaultHttp2Connection(false);
        connection.addListener(this.eventListener);

        connectionHandler = new Http2ClientConnectionHandlerBuilder()
                .frameListener(new DelegatingDecompressorFrameListener(connection, new InboundHttp2ToHttpAdapterBuilder(connection)
                        .maxContentLength(this.maxContentLength).propagateSettings(true).build()))
                .initialSettings(this.clientSettings).connection(connection).build();
        if ((this.windowUpdateRatio != null) && ((connection.local().flowController() instanceof DefaultHttp2LocalFlowController))) {
            ((DefaultHttp2LocalFlowController) connection.local().flowController()).windowUpdateRatio(this.windowUpdateRatio.floatValue());
        }
        this.settingsHandler = new Http2SettingsHandler(this.initialFlowControlWindowUpdate);
        configureClearText(ch);
        ch.attr(AsyncConstants.DIRECT_H2C_ATTR).set("yes");
    }

    private void configureClearText(SocketChannel ch) {
        ch.pipeline().addLast(new ChannelHandler[]{connectionHandler});
        ch.pipeline().addLast(new ChannelHandler[]{this.settingsHandler, this.responseHandler, new UserEventLogger()});
    }

    public Http2SettingsHandler getSettingsHandler() {
        return this.settingsHandler;
    }

    private class UserEventLogger extends ChannelInboundHandlerAdapter {
        private UserEventLogger() {
        }

        public void userEventTriggered(ChannelHandlerContext context, Object event) throws Exception {
            LOGGER.debug("{} User Event Triggered: {}", event.getClass().getName(), event.toString());
            if (!(event instanceof IdleStateEvent)) {
                context.fireUserEventTriggered(event);
            }
        }

        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
            LOGGER.error("Http2 client exception caught {}", cause, cause);
        }
    }
}

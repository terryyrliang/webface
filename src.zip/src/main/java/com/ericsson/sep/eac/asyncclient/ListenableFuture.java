/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient;

import java.util.concurrent.*;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public interface ListenableFuture<T> extends Future<T> {
    /**
     * Terminate and if there is no exception, mark this future as done, and release the internal lock
     */
    void done();

    /**
     * Abort current processing, and propagate the {@link Throwable} to the {@link Future} or the AsyncHandler
     */
    void abort(Throwable t);

    /**
     * Touch the current instance to prevent external services to times out
     */
    void touch();

    /**
     *
     * @param listener the listener to run when the computation is completed
     * @param executor the executor to run the listener in
     * @return this future
     */
    ListenableFuture<T> addListener(Runnable listener, Executor executor);

    CompletableFuture<T> toCompletableFuture();



    class CompletedFailure<T> implements ListenableFuture<T>{
        private final ExecutionException exception;

        public CompletedFailure(Throwable t){
            exception = new ExecutionException(t);
        }

        public CompletedFailure(String message, Throwable t){
            exception = new ExecutionException(message, t);
        }
        @Override
        public void done() {

        }

        @Override
        public void abort(Throwable t) {

        }

        @Override
        public void touch() {

        }

        @Override
        public ListenableFuture addListener(Runnable listener, Executor executor) {
            if (executor != null){
                executor.execute(listener);
            } else {
                listener.run();
            }
            return this;
        }

        @Override
        public CompletableFuture<T> toCompletableFuture() {
            CompletableFuture<T> future = new CompletableFuture<>();
            future.completeExceptionally(exception);
            return future;
        }

        @Override
        public boolean cancel(boolean mayInterruptIfRunning) {
            return true;
        }

        @Override
        public boolean isCancelled() {
            return false;
        }

        @Override
        public boolean isDone() {
            return true;
        }

        @Override
        public T get() throws ExecutionException {
            throw exception;
        }

        @Override
        public T get(long timeout, TimeUnit unit) throws ExecutionException {
            throw exception;
        }
    }
}

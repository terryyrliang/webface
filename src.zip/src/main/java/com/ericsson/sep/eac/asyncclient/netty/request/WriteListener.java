/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.request;

import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.handler.ProcessAsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.channel.Channel;
import org.slf4j.Logger;

import java.nio.channels.ClosedChannelException;

public abstract class WriteListener {
    private static final Logger LOGGER = LogHelper.getLogger(WriteListener.class);
    protected final ResponseFuture<?> future;
    final ProcessAsyncHandler<?> processAsyncHandler;
    final boolean isNotifyHeaders;

    public WriteListener(ResponseFuture<?> future, boolean isNotifyHeaders) {
        this.future = future;
        this.processAsyncHandler = future.getAsyncHandler() instanceof ProcessAsyncHandler ? (ProcessAsyncHandler<?>) future.getAsyncHandler() : null;
        this.isNotifyHeaders = isNotifyHeaders;
    }

    void operationComplete(Channel channel, Throwable cause){
        future.touch();
        if (abortWithThrowable(channel, cause)){
            LOGGER.debug("abort when write because exception", cause);
            return;
        }
        LOGGER.debug("get processAsyncHandler:{}", processAsyncHandler);

        if (processAsyncHandler != null){
            boolean isStartPublish = !future.isInAuth() && !future.isInProxyAuth();
            if (isStartPublish){
                if (isNotifyHeaders){
                    LOGGER.debug("onHeadersWritten");
                    processAsyncHandler.onHeadersWritten();
                } else {
                    LOGGER.debug("onContentWritten");
                    processAsyncHandler.onContentWritten();
                }
            }
        }

    }

    private boolean abortWithThrowable(Channel channel, Throwable cause) {
        if (cause != null) {
            if (cause instanceof IllegalStateException || cause instanceof ClosedChannelException ) {
                LOGGER.warn(cause.getMessage(), cause);
                ChannelUtils.closeChannelSilently(channel);
            } else {
                future.abort(cause);
            }
            return true;
        }
        return false;
    }
}

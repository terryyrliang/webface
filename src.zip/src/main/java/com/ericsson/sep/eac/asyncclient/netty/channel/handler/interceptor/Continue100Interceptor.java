/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler.interceptor;

import com.ericsson.sep.eac.asyncclient.OnLastContentCallback;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.channel.Channel;

public class Continue100Interceptor {

    private final RequestSender requestSender;

    public Continue100Interceptor(RequestSender requestSender) {
        this.requestSender = requestSender;
    }

    public boolean isExitAfterHandling100(final Channel channel, ResponseFuture<?> future){
        future.setHeadersAlreadyWrittenOnContinue(true);
        future.setDontWriteBodyBecauseExpectContinue(false);

        ChannelUtils.setAttribute(channel, new OnLastContentCallback(future) {
            @Override
            public void call() {
                ChannelUtils.setAttribute(channel, future);
                requestSender.writeRequest(future, channel);
            }
        });
        return true;
    }
}

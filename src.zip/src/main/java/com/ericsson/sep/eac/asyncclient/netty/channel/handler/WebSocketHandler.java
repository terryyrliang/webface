/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler;

import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.netty.ws.NettyWebSocket;
import com.ericsson.sep.eac.asyncclient.ws.WebSocketStatusCode;
import com.ericsson.sep.eac.asyncclient.ws.WebSocketUpgradeHandler;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;

import java.io.IOException;

import static com.ericsson.sep.eac.asyncclient.util.WebSocketUtil.getAcceptKey;

@ChannelHandler.Sharable
public class WebSocketHandler extends AsyncClientBaseHandler {

    public WebSocketHandler(AsyncClientConfig config, RequestSender requestSender,
        ChannelManager channelManager) {
        super(config, requestSender, channelManager);
    }

    @Override
    public void handleRead(Channel channel, ResponseFuture<?> future, Object receivedMsg) {
        WebSocketUpgradeHandler upgradeHandler =
            (WebSocketUpgradeHandler) future.getAsyncHandler();
        if (receivedMsg instanceof HttpResponse) {
            HttpResponse response = (HttpResponse) receivedMsg;
            if (LOGGER.isDebugEnabled()) {
                HttpRequest httpRequest = future.getNettyRequest().getHttpRequest();
                LOGGER.debug("web socket request:{} \n\n response:{}", httpRequest, response);
            }

            HttpResponseStatus status = response.status();
            handleHttpVersion(upgradeHandler, response.protocolVersion());
            if (!interceptors.isExitAfterIntercept(channel, future, response)) {
                switch (upgradeHandler.onStatusReceived(status)) {
                    case CONTINUE:
                        upgradeWs(channel, future, upgradeHandler, response);
                        break;
                    case ABORT:
                        abort(channel, future, upgradeHandler, status);
                        break;
                }
            }

        } else if (receivedMsg instanceof WebSocketFrame) {
            WebSocketFrame frame = (WebSocketFrame) receivedMsg;
            NettyWebSocket webSocket = upgradeHandler.onCompleted();
            if (webSocket.isReady()){
                webSocket.handleFrame(frame);
            } else {
                webSocket.bufferFrame(frame);
            }
        } else if (!(receivedMsg instanceof LastHttpContent)) {
            LOGGER.error("web socket process received a invalid message:{}", receivedMsg);
        }
    }


    @Override
    public void handleChannelInactive(ResponseFuture<?> future) {
        String message = "connection was closed abnormally since no CloseFrame received";
        LOGGER.debug(message);

        try {
            NettyWebSocket webSocket = getNettyWebSocket(future);
            if (webSocket != null){
                webSocket.onClose(WebSocketStatusCode.NO_CODE, message);
            }
        } catch (Throwable e){
            LOGGER.error("channel inactive exception", e);
        }
    }

    @Override
    public void handleException(ResponseFuture<?> future, Throwable cause) {
        LOGGER.warn("exception Caught", cause);
        try{
            NettyWebSocket webSocket = getNettyWebSocket(future);
            if (webSocket != null){
                webSocket.onError(cause);
                webSocket.sendCloseFrame();
            }
        } catch (Throwable throwable ){
            LOGGER.error("exceptionCaught exception", throwable);
        }
    }

    private void upgradeWs(Channel channel, ResponseFuture<?> future,
        WebSocketUpgradeHandler upgradeHandler, HttpResponse response) {
        HttpHeaders headers = response.headers();

        boolean isStatusValid = response.status().equals(HttpResponseStatus.SWITCHING_PROTOCOLS);
        boolean isUpgradeValid = headers.get(HttpHeaderNames.UPGRADE) != null;
        boolean isConnectionValid = HttpHeaderValues.UPGRADE
            .contentEqualsIgnoreCase(headers.get(HttpHeaderNames.CONNECTION));
        boolean isHeaderReceivedContinue =
            upgradeHandler.onHeadersReceived(headers) == AsyncHandler.State.CONTINUE;

        if (!isStatusValid || !isUpgradeValid || !isConnectionValid || !isHeaderReceivedContinue) {
            requestSender.abort(channel, future, new IOException("Invalid handshake response"));
            return;
        }
        String acceptKey = headers.get(HttpHeaderNames.SEC_WEBSOCKET_ACCEPT);
        String acceptKeyInRequest = getAcceptKey(future.getNettyRequest().getHttpRequest().headers()
            .get(HttpHeaderNames.SEC_WEBSOCKET_KEY));

        if (acceptKey == null || !acceptKey.equals(acceptKeyInRequest)){
            requestSender.abort(channel, future,
                new IOException("Invalid challenge. Actual: " + acceptKey + ". Expected: " + acceptKeyInRequest));
        }
        ChannelUtils.setAttribute(channel, future);
        upgradeHandler.setWebSocket(new NettyWebSocket(channel, headers));
        channelManager.upgradePipelineForWebSocket(channel.pipeline());

        try {
            upgradeHandler.onOpen();
        } catch (Exception e){
            LOGGER.warn("open web socket session exception", e);
        }
        future.done();
    }


    private void abort(Channel channel, ResponseFuture<?> future,
        WebSocketUpgradeHandler upgradeHandler, HttpResponseStatus status) {
        try {
            upgradeHandler.onThrowable(new IOException("Invalid status code:"+ status.code() + " text:"+ status.codeAsText()));
        } finally {
            finishUpdate(future, channel, true);
        }
    }

    private NettyWebSocket getNettyWebSocket(ResponseFuture<?> future){
        WebSocketUpgradeHandler upgradeHandler = (WebSocketUpgradeHandler) future.getAsyncHandler();
        return upgradeHandler.onCompleted();
    }


}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.channel;

import com.ericsson.sep.eac.asyncclient.AsyncClient;
import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.ChannelCreation;
import com.ericsson.sep.eac.asyncclient.common.Http2Channel;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2Handler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2SettingsHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.initializer.Http2cDirectClientInitializer;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestHostnameResolver;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.netty.timer.TimeoutsHolder;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.DefaultFullHttpRequest;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http2.Http2ConnectionEncoder;
import io.netty.handler.codec.http2.Http2ConnectionHandler;
import io.netty.util.Timer;
import io.netty.util.TimerTask;
import io.netty.util.*;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.ImmediateEventExecutor;
import io.netty.util.concurrent.Promise;
import org.slf4j.Logger;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.ericsson.sep.eac.asyncclient.common.AsyncConstants.CHANNEL_CREATION_ATTRIBUTE_KEY;
import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.ASY_H2_HANDLER;
import static com.ericsson.sep.eac.asyncclient.util.AssertUtils.assertNotNull;
import static java.util.Collections.singletonList;

/**
 * @author emeezhg
 * @date 1/9/2019
 */
public class Http2ChannelPool implements ChannelPool {
    private static final Logger LOGGER = LogHelper.getLogger(Http2ChannelPool.class);

    // key is partition key
    private final ConcurrentHashMap<Object, Http2Channel> partitions = new ConcurrentHashMap<>();
    // key <channel id>:<stream id>
    private final ConcurrentHashMap<String, ResponseFuture> responseFutureMap = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<Object, Lock> lockConcurrentHashMap = new ConcurrentHashMap<>();

    private final AtomicBoolean isClosed = new AtomicBoolean(false);
    private final Timer nettyTimer;
    private final int connectionTtl;
    private final boolean connectionTtlEnabled;
    private final int maxIdleTime;
    private final boolean maxIdleTimeEnabled;
    private final long cleanerPeriodMilliSec;
    private static final int CORE_SIZE = Runtime.getRuntime().availableProcessors();
    private int http2ChannelPerHost = CORE_SIZE;
    private ChannelManager channelManager;
    private AsyncClientConfig config;

    public Http2ChannelPool(ChannelManager channelManager, AsyncClientConfig config, Timer timer) {
        this(channelManager, config.getPooledConnectionIdleTimeoutMilliSec(),
                config.getPooledConnectionTtlMilliSec(), timer,
                config.getPooledConnectionClearPeriodMilliSec());
        this.config = config;
        this.http2ChannelPerHost = config.getHttp2ChannelPerHost() > CORE_SIZE ? config.getHttp2ChannelPerHost() : CORE_SIZE;
    }

    public Http2ChannelPool(ChannelManager channelManager, int maxIdleTime, int connectionTtl,
                            Timer timer, int cleanerPeriodMilliSec) {
        this.channelManager = channelManager;
        this.maxIdleTime = maxIdleTime;
        this.connectionTtl = connectionTtl;
        connectionTtlEnabled = connectionTtl > 0;
        this.nettyTimer = timer;
        maxIdleTimeEnabled = maxIdleTime > 0;
        this.cleanerPeriodMilliSec = Math.min(cleanerPeriodMilliSec,
                Math.min(connectionTtlEnabled ? connectionTtl : Integer.MAX_VALUE,
                        maxIdleTimeEnabled ? maxIdleTime : Integer.MAX_VALUE));
    }

    @Override
    public boolean offer(Object partitionKey, Channel channel) {
        if (isClosed.get()) {
            return false;
        }
        return true;
    }

    private void registerChannelCreation(Object partitionKey, Channel channel, long currentTime) {
        Attribute<ChannelCreation> channelCreationAttribute =
                channel.attr(CHANNEL_CREATION_ATTRIBUTE_KEY);
        if (channelCreationAttribute.get() == null) {
            channelCreationAttribute.set(new ChannelCreation(currentTime, partitionKey));
        }
    }

    @Override
    public Channel poll(Object partitionKey) {
        return null;
    }

    public Http2Channel pollHttp2Channel(Object partitionKey) {
        Lock lock = acquireLock(partitionKey);
        try {
            lock.lock();
            Http2Channel http2Channel = partitions.get(partitionKey);
            if (http2Channel != null) {
                if (ChannelUtils.isStreamIdExceeded(http2Channel.streamId)) {
                    LOGGER.warn("Partition : {} stream id ge exceeded...", partitionKey);
                    initChannel(partitionKey);
                }
                return http2Channel;
            } else {
                initChannel(partitionKey);
                return partitions.get(partitionKey);
            }
        } finally {
            lock.unlock();
        }
    }

    private void initChannel(Object partitionKey) {
        partitions.remove(partitionKey);
        String partitionKeyStr = (String) partitionKey;
        String hostAndPortStr = getHostString(partitionKeyStr);
        LOGGER.debug("target url - {}", hostAndPortStr);
        Bootstrap bootstrap = channelManager.getHttp2cDirectBootstrap(config.getConnectionTimeoutMilliSec());
        List<String> resolvedAddresses = resolveAddresses(hostAndPortStr);
        for (String resolvedAddr : resolvedAddresses) {
            try {
                LOGGER.debug("resolved address {}", resolvedAddr);
                String[] hostAndPort = resolvedAddr.split(":");
                int remotePort = hostAndPort.length == 2 ? Integer.valueOf(hostAndPort[1]) : 80;

                Channel channel = bootstrap.connect(hostAndPort[0], remotePort).syncUninterruptibly().channel();
                ChannelManager.initCounter.incrementAndGet();
                long currentTime = System.currentTimeMillis();
                Http2SettingsHandler http2SettingsHandler = (channelManager
                        .getHttp2cDirectClientInitializer()).getSettingsHandler();
                if (http2SettingsHandler == null) {
                    throw new IllegalStateException("init channel failed, Http2SettingsHandler is null");
                }
                http2SettingsHandler.awaitSettings(config.getConnectionTimeoutMilliSec() / 1000);

                Http2Channel newHttp2Channel = new Http2Channel(channel, currentTime);
                registerChannelCreation(partitionKey, channel, currentTime);
                partitions.put(partitionKey, newHttp2Channel);
                LOGGER.debug("Connect to {} successfully", resolvedAddr);
                break;
            } catch (Exception e) {
                LOGGER.warn("Fail to connect to {}, will try another if any", resolvedAddr);
            }
        }
    }

    public Lock acquireLock(Object partitionKey) {
        Lock lock = new ReentrantLock();
        if (lockConcurrentHashMap.putIfAbsent(partitionKey, lock) == null) {
            return lock;
        }
        return lockConcurrentHashMap.get(partitionKey);
    }

    private String getHostString(String partitionKeyStr) {
        boolean isSecure = partitionKeyStr.startsWith("https://");
        String hostAndPortStr = null;
        if (!isSecure) {
            hostAndPortStr = partitionKeyStr.substring(partitionKeyStr.indexOf("http://") + "http://".length());
        } else {
            hostAndPortStr = partitionKeyStr.substring(partitionKeyStr.indexOf("https://") + "https://".length());
        }
        return hostAndPortStr;
    }

    private List<String> resolveAddresses(String hostAndPortStr) {
        List<String> list = new LinkedList<>();
        try {
            String[] hostAndPort = hostAndPortStr.split(":");
            for (InetAddress addr : InetAddress.getAllByName(hostAndPort[0])) {
                list.add(String.format("%s:%s", addr.getHostAddress(), hostAndPort[1]));
            }
        } catch (UnknownHostException e) {
            throw new IllegalStateException(String.format("Unable to resolve address %s", hostAndPortStr), e);
        }
        return list;
    }

    @Override
    public boolean removeAll(Channel channel) {
        ChannelCreation creation =
                connectionTtlEnabled ? channel.attr(CHANNEL_CREATION_ATTRIBUTE_KEY).get() : null;
        return !isClosed.get() && creation != null && partitions.remove(creation.partitionKey) != null;
    }

    public boolean removeByParitionKey(Object partitionKey) {
//        return !isClosed.get() && partitions.remove(partitionKey) != null;
        return partitions.remove(partitionKey) != null;
    }

    @Override
    public boolean isOpen() {
        return !isClosed.get();
    }

    @Override
    public void destroy() {
        if (isClosed.getAndSet(true)) {
            return;
        }
        partitions.clear();
    }

    @Override
    public void flushPartitions(Predicate<Object> predicate) {
        throw new UnsupportedOperationException("Not support flushPartitions");
    }

    @Override
    public Map<String, Long> getIdleChannelCountPerHost() {
        throw new UnsupportedOperationException("Not support getIdleChannelCountPerHost");
    }

    public ResponseFuture getResponseFuture(String requestId) {
        if (!responseFutureMap.containsKey(requestId)) {
            ChannelManager.nullCounter.incrementAndGet();
        }
        return responseFutureMap.remove(requestId);
    }

    public void putResponseFuture(String requestId, ResponseFuture responseFuture) {
        responseFutureMap.put(requestId, responseFuture);
    }
}
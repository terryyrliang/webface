/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;

import com.ericsson.sep.eac.asyncclient.Request;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.request.NettyRequest;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.request.SimpleFutureListener;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.netty.timer.TimeoutsHolder;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http2.DefaultHttp2ConnectionEncoder;
import io.netty.handler.codec.http2.Http2CodecUtil;
import io.netty.handler.codec.http2.Http2ConnectionEncoder;
import io.netty.handler.ssl.SslHandler;
import io.netty.util.concurrent.Future;
import org.slf4j.Logger;

import java.net.ConnectException;
import java.net.InetSocketAddress;


public final class ConnectListener<T> {
    private static final Logger LOGGER = LogHelper.getLogger(ConnectListener.class);

    private final RequestSender requestSender;
    private final ResponseFuture<T> future;
    private final ChannelManager channelManager;
    private final ConnectionSemaphore connectionSemaphore;

    public ConnectListener(RequestSender requestSender, ResponseFuture<T> future,
        ChannelManager channelManager, ConnectionSemaphore connectionSemaphore) {
        this.requestSender = requestSender;
        this.future = future;
        this.channelManager = channelManager;
        this.connectionSemaphore = connectionSemaphore;
    }

    public void onSuccess(Channel channel, InetSocketAddress remoteAddress) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Connect {} success with channel: {}", remoteAddress, channel);
        }
        if (connectionSemaphore != null) {
            // transfer lock from future to channel
            Object partitionKeyLock = future.takePartitionKeyLock();
            LOGGER.debug("Get partitionKey: {}", partitionKeyLock);

            if (partitionKeyLock != null) {
                channel.closeFuture().addListener(
                    future -> connectionSemaphore.releaseChannelLock(partitionKeyLock));
            }
        }

        ChannelUtils.setActiveToken(channel);

        TimeoutsHolder timeoutsHolder = future.getTimeoutsHolder();

        if (futureIsAlreadyDone(channel)) {
            LOGGER.debug("Future is already done.");
            return;
        }

        Request request = future.getTargetRequest();
        Uri uri = request.getUri();
        LOGGER.debug("Get target request:{} and uri: {}", request, uri);

        timeoutsHolder.setResolvedRemoteAddress(remoteAddress);

        ProxyServer proxyServer = future.getProxyServer();

        if (proxyServer == null && uri.isSecured()) {
            processTlsRequestWithoutProxyServer(channel, uri.isHttp2());
        } else {
            if (uri.isHttp2PriorKnowledge()) {
                LOGGER.debug("Update pipeline for h2 prior knowledge.");
                channelManager.updatePipelineForH2cPriorKnowledge(channel.pipeline());
//                channel.pipeline().writeAndFlush(Http2CodecUtil.connectionPrefaceBuf());
//                NettyRequest nettyRequest = future.getNettyRequest();
//                HttpRequest httpRequest = nettyRequest.getHttpRequest();

            }
            LOGGER.debug("Write request with proxyServer: {}", proxyServer);
            writeRequest(channel);
        }
    }

    private void processTlsRequestWithoutProxyServer(Channel channel, boolean isHttp2) {
        LOGGER.debug("Process TLS request without proxy Server.");
        SslHandler sslHandler;
        try {
            sslHandler = channelManager
                .addSslHandler(channel.pipeline(), isHttp2, future.getSslConfigInRequest());
        } catch (Exception sslError) {
            onFailure(channel, sslError);
            return;
        }

        final AsyncHandler<?> asyncHandler = future.getAsyncHandler();

        try {
            asyncHandler.onTlsHandshakeAttempt();
        } catch (Exception e) {
            LOGGER.error("onTlsHandshakeAttempt crashed", e);
            onFailure(channel, e);
            return;
        }
        Future<Channel> handshakePromise = sslHandler.handshakeFuture();
        LOGGER.debug("ApplicationProtocol I: {}", sslHandler.applicationProtocol());
        handshakePromise.addListener(new SimpleFutureListener<Channel>() {

            @Override
            protected void onSuccess(Channel value) {
                try {
                    LOGGER.debug("Handshake success.");
                    LOGGER.debug("ApplicationProtocol II: {}", sslHandler.applicationProtocol());
                    asyncHandler.onTlsHandshakeSuccess(sslHandler.engine().getSession());
                } catch (Exception e) {
                    LOGGER.error("onTlsHandshakeSuccess failure", e);
                    ConnectListener.this.onFailure(channel, e);
                    return;
                }
                writeRequest(channel);
            }

            @Override
            protected void onFailure(Throwable t) {
                try {
                    asyncHandler.onTlsHandshakeFailure(t);
                } catch (Exception e) {
                    LOGGER.error("onTlsHandshakeSuccess failure", e);
                    ConnectListener.this.onFailure(channel, e);
                    return;
                }
                ConnectListener.this.onFailure(channel, t);
            }
        });
    }

    public void onFailure(Channel channel, Throwable t) {
        LOGGER.debug("connect listener failure.");
        ChannelUtils.closeChannelSilently(channel);

        String message = t.getMessage() != null ? t.getMessage() : future.getUri().getBaseUrl();
        ConnectException e = new ConnectException(message);
        e.initCause(t);
        future.abort(e);
    }

    private void writeRequest(Channel channel) {
        LOGGER.debug("Write request");
        if (futureIsAlreadyDone(channel)) {
            LOGGER.warn("Future is already done.");
            return;
        }

        ChannelUtils.setAttribute(channel, future);
        channelManager.registerOpenChannel(channel);
        future.attachChannel(channel, false);
        requestSender.writeRequest(future, channel);
    }

    private boolean futureIsAlreadyDone(Channel channel) {
        if (future.isDone()) {
            ChannelUtils.closeChannelSilently(channel);
            return true;
        }
        return false;
    }

    public ResponseFuture<T> getFuture() {
        return future;
    }
}

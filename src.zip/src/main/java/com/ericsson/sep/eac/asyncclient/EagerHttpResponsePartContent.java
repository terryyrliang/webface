/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.util.ByteBufUtils;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.nio.ByteBuffer;

public class EagerHttpResponsePartContent extends HttpResponsePartContent {

    private final byte[] bytes;

    public EagerHttpResponsePartContent(ByteBuf content, boolean last) {
        super(last);
        this.bytes = ByteBufUtils.byteBuf2Bytes(content);
    }

    @Override
    public int length() {
        return bytes.length;
    }

    @Override
    public byte[] getPartContentBytes() {
        return bytes.clone();
    }

    @Override
    public ByteBuf getPartContentByteBuf() {
        return Unpooled.wrappedBuffer(bytes);
    }

    @Override
    public ByteBuffer getPartContentByteBuffer() {
        return ByteBuffer.wrap(bytes);
    }
}

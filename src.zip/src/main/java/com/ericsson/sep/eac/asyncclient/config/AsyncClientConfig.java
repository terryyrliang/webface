/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.config;


import com.ericsson.sep.eac.asyncclient.HttpResponsePartContentFactory;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public interface AsyncClientConfig {

    int getIoThreadsCount();

    int getMaxConnections();

    int getMaxConnectionPerHost();

    int getConnectionTimeoutMilliSec();

    int getReadTimeoutMilliSec();

    int getRequestTimeoutMilliSec();

    boolean isKeepAlive();

    boolean isTcpNoDelay();

    boolean isSoReuseAddress();

    int getMaxInitLineLength();

    int getMaxHeaderSize();

    int getMaxChunkSize();

    boolean isValidateResponseHeaders();

    int getInitBufferSize();

    int getResponseMaxContentLengthKB();

    //  ssl
    SslConfig getSslConfig();

    // bellow items are configuration for channel pool

    /**
     * @return the time in millisecond an {@link com.ericsson.sep.eac.asyncclient.AsyncClient} will keep connection in the pool, or -1 to keep connection while possible.
     */
    int getPooledConnectionTtlMilliSec();

    /**
     * @return the time in millisecond an {@link com.ericsson.sep.eac.asyncclient.AsyncClient} will keep connection in pool
     */
    int getPooledConnectionIdleTimeoutMilliSec();

    /**
     * @return the period in millis to clean the pool of dead and idle connections.
     */
    int getPooledConnectionClearPeriodMilliSec();

    /**
     * @return the duration in milliseconds to obtain a free channel
     */
    int getObtainFreeChannelTimeoutMilliSec();

    /**
     * @return ResponsePartContentFactory
     */
    HttpResponsePartContentFactory getResponseBodyPartFactory();

    /**
     * @return web socket max frame size in KB
     */
    int getWebSocketMaxFrameSizeKB();

    /**
     * quite period MilliSec to shutdown AsyncClient
     * @return
     */
    int getQuietPeriodMilliSec();

    /**
     * timeout MilliSec to shutdown AsyncClient
     * @return
     */
    int getShutdownTimeoutMilliSec();

    boolean isHttp2();

    boolean isHttp2PriorKnowledge();

    Float getWindowUpdateRatio();

    Integer getInitialFlowControlWindowUpdate();

    int getHttp2ChannelPerHost();

}

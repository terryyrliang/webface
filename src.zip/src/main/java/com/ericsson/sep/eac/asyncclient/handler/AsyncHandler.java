/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.handler;

import com.ericsson.sep.eac.asyncclient.HttpResponsePartContent;
import com.ericsson.sep.eac.asyncclient.netty.request.NettyRequest;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;

import javax.net.ssl.SSLSession;
import java.net.InetSocketAddress;
import java.util.ArrayList;

/**
 * @author emeezhg
 * @date 1/10/2019
 */
public interface AsyncHandler<T> {
    default void onHostnameResolutionAttempt(String hostname) {
    }

    default void onHostnameResolutionSuccess(String hostname,
        ArrayList<InetSocketAddress> socketAddresses) {
    }

    default void onHostnameResolutionFailure(String hostname, Throwable t) {
    }

    default void onTlsHandshakeAttempt() {
    }

    default void onTlsHandshakeSuccess(SSLSession session) {
    }

    default void onTlsHandshakeFailure(Throwable t) {
    }

    /**
     * Notify the callback when a request is being written on the channel. If the original request causes multiple requests to be sent, for example, because of authorization or
     * retry, it will be notified multiple times.
     *
     * @param request the real request object as passed to the provider
     */
    default void onRequestSend(NettyRequest request) {
    }

    enum State {

        /**
         * Stop the processing.
         */
        ABORT,
        /**
         * Continue the processing
         */
        CONTINUE
    }

    State onHttpVersionReceived(HttpVersion httpVersion);

    State onStatusReceived(HttpResponseStatus status);

    State onHeadersReceived(HttpHeaders headers);

    State onPartContentReceived(HttpResponsePartContent partContent);

    default State onTrailingHeadersReceived(HttpHeaders headers) {
        return State.CONTINUE;
    }

    void onThrowable(Throwable t);

    T onCompleted();

    // TCP Connect event
    default void onTcpConnectAttempt(InetSocketAddress address) {
    }

    default void onTcpConnectSuccess(InetSocketAddress remoteAddress, Channel channel) {
    }

    default void onTcpConnectFailure(InetSocketAddress address, Throwable t) {
    }

    /**
     * notify the callback when try to
     */
    default void onConnectionPoolAttempt() {
    }

    /**
     * Notify the callback when a new connection was successfully fetched from the pool.
     *
     * @param connection the connection
     */
    default void onConnectionPooled(Channel connection) {
    }

    /**
     * Notify the callback when try to offer a connection to the pool
     *
     * @param connection
     */
    default void onConnectionOffer(Channel connection) {
    }
}



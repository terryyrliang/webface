/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;

import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;

public class BaseConnectionSemaphoreFactory implements ConnectionSemaphoreFactory{

    @Override
    public ConnectionSemaphore newConnectionSemaphore(AsyncClientConfig config) {
        int obtainFreeChannelTimeoutMilliSec = Math.max(0, config.getObtainFreeChannelTimeoutMilliSec());
        int maxConnections = config.getMaxConnections();
        int maxConnectionsPerHost = config.getMaxConnectionPerHost();

        if (maxConnections > 0 && maxConnectionsPerHost > 0) {
            return new CombinedConnectionSemaphore(maxConnections, maxConnectionsPerHost, obtainFreeChannelTimeoutMilliSec);
        }
        if (maxConnections > 0) {
            return new MaxConnectionSemaphore(maxConnections, obtainFreeChannelTimeoutMilliSec);
        }
        if (maxConnectionsPerHost > 0) {
            return new CombinedConnectionSemaphore(maxConnections, maxConnectionsPerHost, obtainFreeChannelTimeoutMilliSec);
        }

        return new NoopConnectionSemaphore();
    }
}

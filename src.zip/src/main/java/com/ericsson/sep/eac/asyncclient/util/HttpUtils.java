/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.util;

import com.ericsson.sep.eac.asyncclient.common.StringBuilderPool;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.util.AsciiString;

import java.nio.charset.Charset;

public class HttpUtils {
    private HttpUtils() {
    }

    private static final String CONTENT_TYPE_CHARSET_ATTRIBUTE = "charset=";
    public static final AsciiString ACCEPT_ALL_HEADER_VALUE = new AsciiString("*/*");

    public static Charset extractContentTypeCharset(String contentType) {
        String charsetName =
            extractContentTypeAttribute(contentType, CONTENT_TYPE_CHARSET_ATTRIBUTE);
        return charsetName != null ? Charset.forName(charsetName) : null;
    }

    public static String originHeader(Uri uri) {
        StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
        sb.append(uri.isSecured() ? "https://" : "http://").append(uri.getHost());
        if (uri.getExplicitPort() != uri.getSchemeDefaultPort()) {
            sb.append(':').append(uri.getPort());
        }
        return sb.toString();
    }

    public static String hostHeader(Uri uri) {
        String host = uri.getHost();
        int port = uri.getPort();
        return port == -1 || port == uri.getSchemeDefaultPort() ? host : host + ":" + port;
    }

    private static String extractContentTypeAttribute(String contentType, String attribute) {
        if (contentType == null) {
            return null;
        }

        for (int i = 0; i < contentType.length(); i++) {
            if (contentType.regionMatches(true, i, attribute, 0, attribute.length())) {
                int start = i + attribute.length();

                // trim left
                while (start < contentType.length()) {
                    char c = contentType.charAt(start);
                    if (c == ' ' || c == '\'' || c == '"') {
                        start++;
                    } else {
                        break;
                    }
                }
                if (start == contentType.length()) {
                    break;
                }

                // trim right
                int end = start + 1;
                while (end < contentType.length()) {
                    char c = contentType.charAt(end);
                    if (c == ' ' || c == '\'' || c == '"' || c == ';') {
                        break;
                    } else {
                        end++;
                    }
                }

                return contentType.substring(start, end);
            }
        }

        return null;
    }
}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.util;

import com.ericsson.sep.eac.asyncclient.Auth;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import org.slf4j.Logger;

import java.nio.charset.Charset;
import java.util.Base64;
import java.util.List;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;
import static java.nio.charset.StandardCharsets.ISO_8859_1;

/**
 * @author emeezhg
 * @date 12/19/2018
 */
public final class AuthUtils {
    private static final Logger LOGGER = LogHelper.getLogger(AuthUtils.class);

    private AuthUtils() {
    }

    public static String computeProxyAuthorizationHeader(Auth proxyAuth) {

        String proxyAuthorization = null;
        if (proxyAuth != null && proxyAuth.isUsePreemptiveAuth()) {

            if (proxyAuth.getScheme() == Auth.AuthScheme.BASIC) {
                proxyAuthorization = computeBasicAuthentication(proxyAuth);
                LOGGER.debug("generate proxyAuthorization:{}", proxyAuthorization);
                // current we only support basic authentication for proxy server
            } else {
                throw new IllegalStateException(
                    "only support basic authorization for proxy server. Invalid Authentication scheme "
                        + proxyAuth.getScheme());
            }
        }

        return proxyAuthorization;
    }

    public static String getHeaderWithPrefix(List<String> authenticateHeaders, String prefix) {
        if (authenticateHeaders != null) {
            for (String authenticateHeader : authenticateHeaders) {
                if (authenticateHeader.regionMatches(true, 0, prefix, 0, prefix.length())) {
                    return authenticateHeader;
                }
            }
        }
        return null;
    }

    public static String computeRealmURI(Uri uri, boolean useAbsoluteURI, boolean omitQuery) {
        if (useAbsoluteURI) {
            return omitQuery && isNonEmpty(uri.getQuery()) ?
                uri.withNewQuery(null).toUrl() :
                uri.toUrl();
        } else {
            String path = uri.getNonEmptyPath();
            return omitQuery || !isNonEmpty(uri.getQuery()) ? path : path + "?" + uri.getQuery();
        }
    }

    public static String computeBasicAuthentication(Auth realm) {
        return realm != null ?
            computeBasicAuthentication(realm.getUsername(), realm.getPassword(),
                realm.getCharset()) :
            null;
    }

    public static String computeBasicAuthentication(String username, String password,
        Charset charset) {
        String s = username + ":" + password;
        return "Basic " + Base64.getEncoder().encodeToString(s.getBytes(charset));
    }

    public static String computeDigestAuthentication(Auth auth) {
        String realmUri =
            computeRealmURI(auth.getUri(), auth.isUseAbsoluteURI(), auth.isOmitQuery());

        StringBuilder builder = new StringBuilder().append("Digest ");
        append(builder, "username", auth.getUsername(), true);
        append(builder, "realm", auth.getRealmName(), true);
        append(builder, "nonce", auth.getNonce(), true);
        append(builder, "uri", realmUri, true);
        if (isNonEmpty(auth.getAlgorithm())) {
            append(builder, "algorithm", auth.getAlgorithm(), false);
        }

        append(builder, "response", auth.getResponse(), true);

        if (auth.getOpaque() != null) {
            append(builder, "opaque", auth.getOpaque(), true);
        }

        if (auth.getQop() != null) {
            append(builder, "qop", auth.getQop(), false);
            // nc and cnonce only sent if server sent qop
            append(builder, "nc", auth.getNc(), false);
            append(builder, "cnonce", auth.getCnonce(), true);
        }
        // remove tailing ", "
        builder.setLength(builder.length() - 2);

        return new String(CommonUtils.charSequence2Bytes(builder, ISO_8859_1));
    }

    private static void append(StringBuilder builder, String name, String value, boolean quoted) {
        builder.append(name).append('=');
        if (quoted) {
            builder.append('"').append(value).append('"');
        } else {
            builder.append(value);
        }

        builder.append(", ");
    }

    public static Auth.Builder auth(Auth prototype) {
        return new Auth.Builder(prototype.getUsername(), prototype.getPassword())
            .setRealmName(prototype.getRealmName()).setAlgorithm(prototype.getAlgorithm())
            .setNc(prototype.getNc()).setNonce(prototype.getNonce())
            .setCharset(prototype.getCharset()).setOpaque(prototype.getOpaque())
            .setQop(prototype.getQop()).setScheme(prototype.getScheme()).setUri(prototype.getUri())
            .setUsePreemptiveAuth(prototype.isUsePreemptiveAuth())
            .setUseAbsoluteURI(prototype.isUseAbsoluteURI()).setOmitQuery(prototype.isOmitQuery())
            .setServicePrincipalName(prototype.getServicePrincipalName())
            .setUseCanonicalHostname(prototype.isUseCanonicalHostname())
            .setCustomLoginConfig(prototype.getCustomLoginConfig())
            .setLoginContextName(prototype.getLoginContextName());
    }

    public static Auth.Builder auth(Auth.AuthScheme scheme, String username, String password) {
        return new Auth.Builder(username, password).setScheme(scheme).setUsePreemptiveAuth(true);
    }

    public static Auth.Builder basicAuthRealm(String username, String password) {
        return auth(Auth.AuthScheme.BASIC, username, password);
    }

    public static Auth.Builder digestAuthRealm(String username, String password) {
        return auth(Auth.AuthScheme.DIGEST, username, password);
    }
}

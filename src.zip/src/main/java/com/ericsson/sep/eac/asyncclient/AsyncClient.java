/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;

import java.io.Closeable;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public interface AsyncClient extends Closeable{

    boolean isClosed();

    BoundRequestBuilder prepare(String url);

    BoundRequestBuilder prepare(String method, String url);

    BoundRequestBuilder prepareRequest(Request request);

    BoundRequestBuilder prepareRequest(RequestBuilder requestBuilder);

    <T> ListenableFuture<T> executeRequest(Request request, AsyncHandler<T> handler);

    <T> ListenableFuture<T> executeRequest(RequestBuilder requestBuilder, AsyncHandler<T> handler);

    ListenableFuture<Response> executeRequest(Request request);

    ListenableFuture<Response> executeRequest(RequestBuilder requestBuilder);

    AsyncClientConfig getConfig();
}

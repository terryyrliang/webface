/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.request.body;

import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;

import java.io.IOException;
import java.nio.ByteBuffer;

public class NettyByteBufferBody implements NettyBody {

    private final ByteBuffer bb;
    private final CharSequence contentTypeOverride;
    private final long length;

    public NettyByteBufferBody(ByteBuffer bb) {
        this(bb, null);
    }

    public NettyByteBufferBody(ByteBuffer bb, CharSequence contentTypeOverride) {
        this.bb = bb;
        length = bb.remaining();
        bb.mark();
        this.contentTypeOverride = contentTypeOverride;
    }

    @Override
    public long getContentLength() {
        return length;
    }

    @Override
    public CharSequence getContentType() {
        return contentTypeOverride;
    }

    @Override
    public void write(Channel channel, ResponseFuture<?> responseFuture) throws IOException {

    }

    public ByteBuf byteBuf() {
        // for retry
        bb.reset();
        return Unpooled.wrappedBuffer(bb);
    }
}

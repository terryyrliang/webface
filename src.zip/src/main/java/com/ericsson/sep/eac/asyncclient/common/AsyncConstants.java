/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.common;

import com.ericsson.sep.eac.asyncclient.channel.Http2ChannelPool;
import com.ericsson.sep.eac.asyncclient.netty.channel.ConnectListener;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2Handler;
import io.netty.handler.codec.http2.HttpConversionUtil;
import io.netty.util.AsciiString;
import io.netty.util.AttributeKey;

import java.net.InetSocketAddress;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public class AsyncConstants {
    private AsyncConstants() {
    }

    public static final String HTTP_09 = "HTTP/0.9";
    public static final String HTTP_10 = "HTTP/1.0";
    public static final String HTTP_11 = "HTTP/1.1";
    public static final String HTTP_20 = "HTTP/2.0";

    public static final AttributeKey<String> UPGRADE_ISSUED_ATTR = AttributeKey.newInstance("UPGRADE_ISSUED");
    public static final AttributeKey<String> UPGRADE_REJECTED_ATTR = AttributeKey.newInstance("UPGRADE_REJECTED");
    public static final AttributeKey<String> UPGRADE_SUCCESSFUL_ATTR = AttributeKey.newInstance("UPGRADE_SUCCESSFUL");
    public static final AttributeKey<String> PRIOR_KNOWLEDGE_ATTR = AttributeKey.newInstance("PRIOR_KNOWLEDGE");

    public static final AttributeKey<ChannelCreation> CHANNEL_CREATION_ATTRIBUTE_KEY =
            AttributeKey.valueOf("channelCreation");
    public static final AttributeKey<String> DIRECT_H2C_ATTR = AttributeKey.newInstance("DIRECT_H2C_ATTR");

    public static final AttributeKey<ConnectListener> CONNECT_LISTENER_ATTR = AttributeKey.newInstance("CONNECT_LISTENER");
    public static final AttributeKey<Http2Handler> H2_HANDLER = AttributeKey.newInstance("H2_HANDLER");
    public static final AttributeKey<String> FIRST_REQUEST_WITH_BODY = AttributeKey.newInstance("FIRST_REQUEST");

    public static final String ATTR_HTTP2_BEGIN_STREAM_ID = "Http2BeginStreamId";

    public final static AsciiString STREAM_ID_HEADER =
            HttpConversionUtil.ExtensionHeaderNames.STREAM_ID.text();

    public static final float DEFAULT_WINDOW_UPDATE_RATIO = 0.5f;
    public static final int DEFAULT_INIT_FLOW_CONTROL_WINDOW_UPDATE = 65535;
    public static final int DEFAULT_HTTP2_CHANNEL_PER_HOST = 2;
    public static final int DEFAULT_BEGIN_STREAM_ID = 1;

    public static boolean isTestMode() {
        String v = System.getProperty("SIG_Running_Mode");

        return isNonEmpty(v) && "Testing".equalsIgnoreCase(v);

    }
}

/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient;

import io.netty.handler.codec.http.HttpMethod;

public class RequestBuilder extends RequestBuilderBase<RequestBuilder>{

    public RequestBuilder(){
        this(HttpMethod.GET.name());
    }

    public RequestBuilder(String method) {
        super(method, false);
    }

    public RequestBuilder(String protocol, String method) {
        super(protocol, method, false);
    }

    public RequestBuilder(String method, boolean isDisableEncoding) {
        super(method, isDisableEncoding);
    }

    protected RequestBuilder(String method, boolean isDisableEncoding, boolean isValidateHeaders) {
        super(method, isDisableEncoding, isValidateHeaders);
    }

    public RequestBuilder(Request prototype) {
        super(prototype);
    }

    protected RequestBuilder(Request prototype, boolean isDisableEncoding,
        boolean isValidateHeaders) {
        super(prototype, isDisableEncoding, isValidateHeaders);
    }
}

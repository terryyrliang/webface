/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.handler;

public interface ProgressAsyncHandler<T> extends AsyncHandler<T>{

    State onHeadersWritten();

    State onContentWritten();

    /**
     * Invoked when the I/O operation associated with the {@link Request} body wasn't fully written in a single I/O write
     * operation. This method is never invoked if the write operation complete in a sinfle I/O write.
     *
     * @param amount  The amount of bytes to transfer.
     * @param current The amount of bytes transferred
     * @param total   The total number of bytes transferred
     */
    State onContentWriteProgress(long amount, long current, long total);

}

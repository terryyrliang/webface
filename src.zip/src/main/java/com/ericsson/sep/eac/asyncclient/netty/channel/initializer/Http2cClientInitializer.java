/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.initializer;

import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.ConnectListener;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.Http2Handler;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerUtils;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import io.netty.channel.*;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http2.*;
import org.slf4j.Logger;


import java.net.InetSocketAddress;

import static com.ericsson.sep.eac.asyncclient.netty.channel.handler.common.HandlerNames.*;



/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class Http2cClientInitializer extends ChannelInitializer<SocketChannel> {
    private static final Logger LOGGER = LogHelper.getLogger(Http2cClientInitializer.class);
    private static final int KB = 1024;

    private final AsyncClientConfig config;
    private final RequestSender requestSender;
    private final ChannelManager channelManager;

    public Http2cClientInitializer(AsyncClientConfig config, RequestSender sender,
        ChannelManager channelManager) {
        this.config = config;
        this.requestSender = sender;
        this.channelManager = channelManager;
    }

    @Override
    protected void initChannel(SocketChannel socketChannel) {
        LOGGER.debug("init channel for h2c");
        ChannelPipeline pipeline = socketChannel.pipeline();
        pipeline.addLast(ASY_H2_HANDLER, new Http2Handler(config, requestSender, channelManager));
        HttpToHttp2ConnectionHandler httpToHttp2PlainConnectionHandler =
            newHttpToHttp2ConnectionHandler();
        configHttp1ToH2cHandler(pipeline, httpToHttp2PlainConnectionHandler);
    }

    private void configHttp1ToH2cHandler(ChannelPipeline pipeline,
        HttpToHttp2ConnectionHandler httpToHttp2PlainConnectionHandler) {
        // http/1.1 upgrade to http2 plain text
        HttpClientCodec sourceCodec = HandlerUtils.newHttpClientCodec(config);
        Http2ClientUpgradeCodec upgradeCodec =
                new Http2ClientUpgradeCodec(httpToHttp2PlainConnectionHandler);
        HttpClientUpgradeHandler upgradeHandler =
                new HttpClientUpgradeHandler(sourceCodec, upgradeCodec,
                        config.getResponseMaxContentLengthKB() * KB);
        if (pipeline.get(HTTP_CLIENT_CODEC) == null) {
            pipeline.addBefore(ASY_H2_HANDLER, HTTP_CLIENT_CODEC, sourceCodec);
        }
        if (pipeline.get(HttpClientUpgradeHandler.class) == null){
            pipeline.addAfter(HTTP_CLIENT_CODEC, H2_UPGRADE, upgradeHandler);
        }
        pipeline.addLast(EVENT_LOG, new UserEventLogger());
    }

    private HttpToHttp2ConnectionHandler newHttpToHttp2ConnectionHandler() {
        final DefaultHttp2Connection connection = new DefaultHttp2Connection(false);
        final InboundHttp2ToHttpAdapter adapter = new InboundHttp2ToHttpAdapterBuilder(connection)
            .maxContentLength(config.getResponseMaxContentLengthKB() * KB)
            .build();
        final DelegatingDecompressorFrameListener frameListener =
            new DelegatingDecompressorFrameListener(connection, adapter);
        return new HttpToHttp2ConnectionHandlerBuilder()
            .frameListener(frameListener)
            .connection(connection)
            .build();
    }


    /**
     * Class that logs any User Events triggered on this channel.
     */
    private static class UserEventLogger extends ChannelInboundHandlerAdapter {
        @Override
        public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
            String evtStr = evt == null ? "" : evt.toString();
            LOGGER.debug("User Event Triggered: {}", evtStr);
            if (evtStr.equals("UPGRADE_ISSUED")) {
                ctx.channel().attr(AsyncConstants.UPGRADE_ISSUED_ATTR).set("yes");
            } else if (evtStr.equals("UPGRADE_REJECTED")) {
                ctx.channel().attr(AsyncConstants.UPGRADE_REJECTED_ATTR).set("yes");
                fireRequest(ctx);
            } else if (evtStr.equals("UPGRADE_SUCCESSFUL")) {
                ctx.channel().attr(AsyncConstants.UPGRADE_SUCCESSFUL_ATTR).set("yes");
                fireRequest(ctx);
            }
            ctx.fireUserEventTriggered(evt);
        }

        private void fireRequest(ChannelHandlerContext ctx) {
            Channel channel = ctx.channel();
            if ("yes".equalsIgnoreCase(channel.attr(AsyncConstants.FIRST_REQUEST_WITH_BODY).get())) {
                Http2Handler http2Handler = channel.attr(AsyncConstants.H2_HANDLER).get();
                if (http2Handler != null) {
                    channel.pipeline().addLast(ASY_H2_HANDLER, http2Handler);
                    InetSocketAddress remote = (InetSocketAddress) channel.remoteAddress();
                    ConnectListener listener = channel.attr(AsyncConstants.CONNECT_LISTENER_ATTR).get();
                    listener.onSuccess(channel, remote);
                }
            }
        }
    }
}

//package com.ericsson.sep.eac.asyncclient;
//
//public enum HttpVersion {
//    HTTP_0_9("HTTP/0.9", 9),
//    HTTP_1_0("HTTP/1.0", 10),
//    HTTP_1_1("HTTP/1.1", 11),
//    HTTP_2("HTTP/2.0", 20);
//
//    private static final String HTTP_09 = "HTTP/0.9";
//    private static final String HTTP_10 = "HTTP/1.0";
//    private static final String HTTP_11 = "HTTP/1.1";
//    private static final String HTTP_20 = "HTTP/2.0";
//
//    private final String text;
//    private final int version;
//
//    HttpVersion(String text, int version) {
//        this.text = text;
//        this.version = version;
//    }
//
//    public static HttpVersion fromText(String text) {
//        switch (text) {
//            case HTTP_09:
//                return HTTP_0_9;
//            case HTTP_10:
//                return HTTP_1_0;
//            case HTTP_20:
//                return HTTP_2;
//            default:
//                return HTTP_1_1;
//        }
//    }
//
//    public static HttpVersion fromVersion(int version) {
//        switch (version) {
//            case 9:
//                return HTTP_0_9;
//            case 10:
//                return HTTP_1_0;
//            case 20:
//                return HTTP_2;
//            default:
//                return HTTP_1_1;
//        }
//    }
//
//}

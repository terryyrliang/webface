/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.ws;

public interface WebSocketListener {

    /**
     * invoke when the websocket is open
     * @param webSocket
     */
    void onOpen(WebSocket webSocket);

    /**
     * invoke if the websocket is closed
     * @param webSocket
     * @param code
     * @param reason
     */
    void onClose(WebSocket webSocket, int code, String reason);

    /**
     * invoke if throwable occur
     * @param throwable
     */
    void onError(Throwable throwable);

    /**
     * invoke if receives text frame
     * @param payload
     * @param finalFragment
     * @param extension
     */
    void onTextFrame(String payload, boolean finalFragment, int extension);

    /**
     * invoke if receives binary frame
     * @param payload
     * @param finalFragment
     * @param extension
     */
    void onBinaryFrame(byte[] payload, boolean finalFragment, int extension);

    /**
     * invoke if receives ping frame
     * @param payload
     */
    void onPingFrame(byte[] payload);

    /** invoke if receives pong frame
     * @param payload
     */
    void onPongFrame(byte[] payload);
}

/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.netty.request;

import com.ericsson.sep.eac.asyncclient.*;
import com.ericsson.sep.eac.asyncclient.channel.Http2ChannelPool;
import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.Http2Channel;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.exception.PoolClosedException;
import com.ericsson.sep.eac.asyncclient.exception.RemoteClosedException;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.*;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import com.ericsson.sep.eac.asyncclient.netty.ssl.config.SslConfig;
import com.ericsson.sep.eac.asyncclient.netty.timer.TimeoutsHolder;
import com.ericsson.sep.eac.asyncclient.proxy.ProxyServer;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import com.ericsson.sep.eac.asyncclient.ws.WebSocketUpgradeHandler;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http2.*;
import io.netty.util.Timer;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.ImmediateEventExecutor;
import io.netty.util.concurrent.Promise;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import static java.util.Collections.singletonList;

/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class RequestSender {
    private static final Logger LOGGER = LogHelper.getLogger(RequestSender.class);

    private final AsyncClientConfig config;
    private final ChannelManager channelManager;
    private final ConnectionSemaphore connectionSemaphore;
    private final Timer timer;
    private final AsyncClientState clientState;
    private final RequestFactory requestFactory;
    private Object streamIdResetLock = new Object();

    public RequestSender(AsyncClientConfig config, ChannelManager channelManager, Timer timer,
        AsyncClientState clientState) {
        this.config = config;
        this.channelManager = channelManager;
        this.connectionSemaphore =
            new BaseConnectionSemaphoreFactory().newConnectionSemaphore(config);
        this.timer = timer;
        this.clientState = clientState;
        this.requestFactory = new RequestFactory(config);
    }

    public <T> ListenableFuture<T> sendHttp2Request(final Request request, final AsyncHandler<T> asyncHandler,
                                               ResponseFuture<T> future) {
        if (clientState.isClosed()) {
            throw new IllegalStateException("Client has already closed!");
        }
        SslConfig sslConfigInRequest = request.getSslConfig();
        ResponseFuture<T> newFuture =
                newRequestAndResponseFuture(request, asyncHandler, future, null,
                        sslConfigInRequest, false);
        Object partitionKey = request.getChannelPoolPartitioning().getPartitionKey(request.getUri(), request.getTargetHost(), null);
        Http2ChannelPool http2ChannelPool = (Http2ChannelPool) channelManager.getChannelPool();
        Lock lock = http2ChannelPool.acquireLock(partitionKey);
        try {
            lock.lock();
            Http2Channel http2Channel = http2ChannelPool.pollHttp2Channel(partitionKey);
            Channel channel = http2Channel.getChannel();
            int streamId = http2Channel.incAndGetStreamId();
            newFuture.getNettyRequest().getHttpRequest().headers().add(HttpConversionUtil.ExtensionHeaderNames.STREAM_ID.text(), Integer.toString(streamId));
            http2ChannelPool.putResponseFuture(ChannelUtils.getRequestId(channel, streamId), newFuture);
            ListenableFuture<T> futureList = sendRequestWithOpenChannel2(newFuture, asyncHandler, channel);
            ChannelManager.sendCounter.incrementAndGet();
            return futureList;
        } finally {
            lock.unlock();
        }
    }

    public <T> ListenableFuture<T> sendRequest(final Request request, final AsyncHandler<T> handler,
        ResponseFuture<T> future) {
        if (clientState.isClosed()) {
            throw new IllegalStateException("Client has already closed!");
        }
        validateWebSocketRequest(request, handler);
        ProxyServer proxyServer = request.getProxyServer();
        SslConfig sslConfigInRequest = request.getSslConfig();
        if (isConnectTunnelingWithProxy(proxyServer, request, future)) {
            LOGGER.debug("Using connect method to proxy server.");
            // send request with proxyServer
            if (future != null && future.isConnectAllowed()) {
                // send request with proxy server in CONNECT method
                LOGGER.debug("Sending request in CONNECT to proxy Server.");
                return sendRequestWithConnectMethod(request, handler, future, proxyServer,
                    sslConfigInRequest, true);
            } else {
                LOGGER.debug("Sending request to proxy.");
                return sendRequestWithProxy(request, handler, future, proxyServer,
                    sslConfigInRequest);
            }
        } else {
            // no connect
            LOGGER.debug("Send request without CONNECT.");
            return sendRequestWithConnectMethod(request, handler, future, proxyServer,
                sslConfigInRequest, false);
        }
    }

    public void getChannelAndExecNextRequest(final Channel channel, final ResponseFuture<?> future,
        Request nextRequest, Future<Channel> handshakePromise) {
        LOGGER.debug("Get the channel and execute next request.");
        Object channelAttr;
        if (handshakePromise == null) {
            LOGGER.debug("Execute next request without handshake");
            channelAttr = new OnLastContentCallback(future) {
                @Override
                public void call() {
                    sendNextRequest(nextRequest, future);
                }
            };
        } else {
            LOGGER.debug("Execute next request with handshake.");
            channelAttr = new OnLastContentCallback(future) {
                @Override
                public void call() {
                    handshakePromise.addListener(f -> {
                        if (f.isSuccess()) {
                            LOGGER.debug("Handshake future is succeed.");
                            sendNextRequest(nextRequest, future);
                        } else {
                            LOGGER.debug("Abort because handshake is failure.");
                            future.abort(f.cause());
                        }
                    });
                }
            };
        }
        ChannelUtils.setAttribute(channel, channelAttr);
    }


    public <T> void sendNextRequest(final Request request, final ResponseFuture<T> future) {
        LOGGER.debug("Sending next request.");
        sendRequest(request, future.getAsyncHandler(), future);
    }

    public <T> void writeRequest(ResponseFuture<T> future, Channel channel) {
        LOGGER.debug("Sender start to write request.");
        Request request = future.getTargetRequest();
        Uri uri = request.getUri();
        boolean isHttp2PriorKnowledge = uri.isHttp2PriorKnowledge();

        NettyRequest nettyRequest = future.getNettyRequest();
        HttpRequest httpRequest = nettyRequest.getHttpRequest();
        AsyncHandler<T> asyncHandler = future.getAsyncHandler();

        if (!ChannelUtils.isChannelActive(channel)) {
            LOGGER.warn("Channel is not active.");
            return;
        }

        try {
            if (!future.isHeadersAlreadyWrittenOnContinue()) {
                try {
                    asyncHandler.onRequestSend(nettyRequest);
                } catch (Exception e) {
                    LOGGER.error("OnRequestSend exception.", e);
                    abort(channel, future, e);
                    return;
                }
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("Written request: {} to channel.", httpRequest);
                }
                if ((uri.isHttp2() && !isHttp2PriorKnowledge && !uri.isSecured()) || channelManager.ifUpgradeSuccess(channel)) {
                    // Send HTTP2 frame directly if resource profile is with prior knowledge or the channel is upgrade successfully.
                    writeHttp2cRequest(future, channel, (DefaultFullHttpRequest) httpRequest, request);
                } else {
                    channel.writeAndFlush(httpRequest).addListener(new WriteCompletedListener(future));
                }
                if (ChannelUtils.isChannelActive(channel)) {
                    scheduleReadTimeout(future);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Written request exception.", e);
            abort(channel, future, e);
        }
    }

    private void writeHttp2cRequest(ResponseFuture future, Channel channel, DefaultFullHttpRequest httpRequest, Request targetRequest)
        throws Exception {
        String tn = Thread.currentThread().getName();
        Http2ConnectionHandler http2ConnectionHandler = channel.pipeline().get(Http2ConnectionHandler.class);
        ChannelHandlerContext ctx = channel.pipeline().firstContext();
        //todo: should trigger manual??
//        http2ConnectionHandler.channelActive(ctx);
        Http2ConnectionEncoder encoder = http2ConnectionHandler.encoder();
        ByteBuf content = httpRequest.content();
        int beginStreamId = Integer.valueOf(targetRequest.getAttributes().getOrDefault(AsyncConstants.ATTR_HTTP2_BEGIN_STREAM_ID, "-1"));
        int streamId = encoder.connection().local().incrementAndGetNextStreamId();
        streamId = streamId > beginStreamId ? streamId : beginStreamId;
        if (content != null && content.readableBytes() >0) {
            LOGGER.debug("write header and data http2Frame");
            future.getSubFutures().add(encoder.writeHeaders(ctx, streamId, http1HeadersToHttp2Headers(httpRequest), 0, false, ctx.newPromise()));
            future.getSubFutures().add(encoder.writeData(ctx, streamId, content.retain(), 0, true, ctx.newPromise()));
            LOGGER.debug("done");
        } else {
            LOGGER.debug("write headerFrame");
            future.getSubFutures().add(encoder.writeHeaders(ctx, streamId, http1HeadersToHttp2Headers(httpRequest), 0, true, ctx.newPromise()));
        }
        http2ConnectionHandler.flush(ctx);
        ctx.channel().attr(AsyncConstants.PRIOR_KNOWLEDGE_ATTR).set("yes");

    }

    private static Http2Headers http1HeadersToHttp2Headers(FullHttpRequest request) {
        HttpHeaders headers = request.headers();
        Http2Headers http2Headers = HttpConversionUtil.toHttp2Headers(headers, true);
        CharSequence host = request.headers().get(HttpHeaderNames.HOST);
        http2Headers.method(request.method().asciiName())
            .path(request.uri())
            .scheme(HttpScheme.HTTP.name());
        if (host != null) {
            http2Headers.authority(host);
        }
        LOGGER.debug("convert to http2Headers:{}", http2Headers);
        return http2Headers;
    }

    public <T> void handleUnexpectedClosedChannel(Channel channel, ResponseFuture<T> future) {
        LOGGER.debug("Handle unexpected closed channel.");
        if (ChannelUtils.isActiveTokenSet(channel)) {
            if (future.isDone()) {
                channelManager.closeChannel(channel);
            } else {
                LOGGER.debug("Handle unexpected closed channel, abort channel!");
                Throwable t = future.pendingException != null ?
                    future.pendingException :
                    RemoteClosedException.INSTANCE;
                abort(channel, future, t);
            }
        }
    }

    public <T> void abort(Channel channel, ResponseFuture<T> future, Throwable t) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.error("Abort channel: {} with future: {} and cause: {}", channel, future,
                t.getMessage());
        }

        future.abort(t);
        if (ChannelUtils.isChannelActive(channel)) {
            channelManager.closeChannel(channel);
        }

        if (!future.isDone()) {
            future.setChannelState(ChannelState.CLOSED);
        }
    }

    public boolean isClosed() {
        return clientState.isClosed();
    }

    private void validateWebSocketRequest(Request request, AsyncHandler handler) {
        LOGGER.debug("Validating this web socket request.");
        Uri uri = request.getUri();
        boolean isWebSocket = uri.isWebSocket();
        if (handler instanceof WebSocketUpgradeHandler) {
            if (!isWebSocket) {
                throw new IllegalArgumentException(
                    "Request scheme isn't ws or wss: " + uri.getScheme());
            } else if (!"GET".equalsIgnoreCase(request.getMethod()) && !"CONNECT"
                .equalsIgnoreCase(request.getMethod())) {
                throw new IllegalArgumentException(
                    "Request method isn't GET or CONNECT " + request.getMethod());
            }

        } else if (isWebSocket) {
            throw new IllegalArgumentException(
                "No WebSocketUpgradeHandler but scheme is: " + uri.getScheme());
        }
    }

    private boolean isConnectTunnelingWithProxy(ProxyServer proxyServer, Request request,
        ResponseFuture<?> future) {
        return proxyServer != null && proxyServer.getProxyType().isHttp() && (
            request.getUri().isSecured() || request.getUri().isWebSocket()) && !isConnectDone(
            request, future);
    }

    private boolean isConnectDone(Request request, ResponseFuture<?> future) {
        return future != null && future.getNettyRequest() != null
            && future.getNettyRequest().getHttpRequest().method() == HttpMethod.CONNECT
            && !"CONNECT".equalsIgnoreCase(request.getMethod());
    }

    private <T> ListenableFuture<T> sendRequestWithConnectMethod(Request request,
        AsyncHandler<T> asyncHandler, ResponseFuture<T> future, ProxyServer proxyServer,
        SslConfig sslConfigInRequest, boolean isConnectRequest) {
        LOGGER.debug("Send request with connect method: {}", isConnectRequest);

        ResponseFuture<T> newFuture =
            newRequestAndResponseFuture(request, asyncHandler, future, proxyServer,
                sslConfigInRequest, isConnectRequest);

        Channel channel = getOpenChannel(future, request, proxyServer, asyncHandler);

        ListenableFuture<T> futureList = null;
        if (ChannelUtils.isChannelActive(channel)) {
            try {
                futureList = sendRequestWithOpenChannel(newFuture, asyncHandler, channel);
            } catch (NullPointerException e) {
                LOGGER.error("Exception happened when sending request with open channel.", e);
            }
        } else {
            futureList = sendRequestWithNewChannel(request, proxyServer, newFuture, asyncHandler);
        }
        return futureList;

    }

    private <T> ListenableFuture<T> sendRequestWithNewChannel(Request request,
        ProxyServer proxyServer, ResponseFuture<T> future, AsyncHandler<T> asyncHandler) {
        LOGGER.debug("send request with a new channel");
        Auth auth = future.getAuth();
        Auth proxyAuth = future.getProxyAuth();
        future.setInAuth(auth != null && auth.isUsePreemptiveAuth()
            && auth.getScheme() != Auth.AuthScheme.DIGEST);
        future.setInProxyAuth(proxyAuth != null && proxyAuth.isUsePreemptiveAuth()
            && proxyAuth.getScheme() != Auth.AuthScheme.DIGEST);

        try {
            if (!channelManager.isOpen()) {
                throw PoolClosedException.INSTANCE;
            }
            future.acquirePartitionLockLazily();
        } catch (IOException e) {
            abort(null, future, e);
            return future;
        }

        resolveAddresses(request, proxyServer, future, asyncHandler)
            .addListener(new SimpleFutureListener<List<InetSocketAddress>>() {
                @Override
                protected void onSuccess(List<InetSocketAddress> addresses) {
                    ConnectListener<T> connectListener =
                        new ConnectListener<>(RequestSender.this, future, channelManager,
                            connectionSemaphore);
                    ChannelConnector connector =
                        new ChannelConnector(asyncHandler, request.getLocalAddress(), addresses,
                            clientState);
                    if (!future.isDone()) {
                        channelManager.reConfigBootstrap(request)
                            .addListener((Future<Bootstrap> resultBootstrap) -> {
                                if (resultBootstrap.isSuccess()) {
                                    LOGGER.debug("Try to connect {}", request.getUrl());
                                    connector.connect(resultBootstrap.get(), connectListener);
                                } else {
                                    abort(null, future, resultBootstrap.cause());
                                }
                            });
                    }
                }

                @Override
                protected void onFailure(Throwable t) {
                    LOGGER.warn("Resolve address failure.");
                    abort(null, future, t);
                }
            });
        return future;
    }

    private <T> ListenableFuture<T> sendRequestWithOpenChannel(ResponseFuture<T> future,
        AsyncHandler<T> asyncHandler, Channel channel) {
        LOGGER.debug("Send request with an open channel.");
        try {
            asyncHandler.onConnectionPooled(channel);
        } catch (Exception e) {
            LOGGER.error("OnConnectionPooled exception", e);
            abort(channel, future, e);
            return future;
        }
        SocketAddress remoteAddr = channel.remoteAddress();
        LOGGER.debug("Get channel remote address: {}", remoteAddr);
        if (remoteAddr != null) {
            scheduleRequestTimeout(future, (InetSocketAddress) remoteAddr);
        }
        future.setChannelState(ChannelState.POOLED);
        future.attachChannel(channel, false);

        if (LOGGER.isDebugEnabled()) {
            HttpRequest httpRequest = future.getNettyRequest().getHttpRequest();
            LOGGER.debug("Using open Channel {} for {} '{}'", channel, httpRequest.method(),
                httpRequest.uri());
        }

        ChannelUtils.setAttribute(channel, future);
        if (ChannelUtils.isChannelActive(channel)) {
            LOGGER.debug("Channel is ready to write request.");
            writeRequest(future, channel);
        } else {
            LOGGER.debug("Send request with an open channel: abort channel.");
            // channel is closed
            LOGGER.debug("Channel is closed when write request.");
            handleUnexpectedClosedChannel(channel, future);
        }
        return future;
    }

    private <T> ListenableFuture<T> sendRequestWithOpenChannel2(ResponseFuture<T> future,
                                                               AsyncHandler<T> asyncHandler, Channel channel) {
        LOGGER.debug("Send request with an open channel.");
        try {
            asyncHandler.onConnectionPooled(channel);
        } catch (Exception e) {
            LOGGER.error("OnConnectionPooled exception", e);
            abort(channel, future, e);
            return future;
        }
        SocketAddress remoteAddr = channel.remoteAddress();
        LOGGER.debug("Get channel remote address: {}", remoteAddr);
        if (remoteAddr != null) {
            scheduleRequestTimeout(future, (InetSocketAddress) remoteAddr);
        }

        if (LOGGER.isDebugEnabled()) {
            HttpRequest httpRequest = future.getNettyRequest().getHttpRequest();
            LOGGER.debug("Using open Channel {} for {} '{}'", channel, httpRequest.method(),
                    httpRequest.uri());
        }

        if (ChannelUtils.isChannelActive(channel)) {
            LOGGER.debug("Channel is ready to write request.");
            writeRequest(future, channel);
        } else {
            LOGGER.debug("Send request with an open channel: abort channel.");
            // channel is closed
            LOGGER.debug("Channel is closed when write request.");
            handleUnexpectedClosedChannel(channel, future);
        }
        return future;
    }



    private void scheduleRequestTimeout(ResponseFuture<?> future, InetSocketAddress remoteAddress) {
        LOGGER.debug("Schedule request timeout.");
        future.touch();
        TimeoutsHolder timeoutsHolder =
            new TimeoutsHolder(timer, future, this, config, remoteAddress);
        future.setTimeoutsHolder(timeoutsHolder);
    }

    private void scheduleReadTimeout(ResponseFuture<?> future) {
        TimeoutsHolder timeoutsHolder = future.getTimeoutsHolder();
        if (timeoutsHolder != null) {
            future.touch();
            timeoutsHolder.startReadTimeoutTask();
        }
    }

    private <T> ResponseFuture<T> newRequestAndResponseFuture(final Request request,
        final AsyncHandler<T> asyncHandler, ResponseFuture<T> originalFuture, ProxyServer proxy,
        SslConfig sslConfigInRequest, boolean isConnectRequest) {

        // get auth of request
        Auth auth;
        if (originalFuture != null) {
            auth = originalFuture.getAuth();
        } else {
            auth = request.getAuth();
        }

        boolean isUnauthorized = false;
        if (originalFuture != null) {
            isUnauthorized = originalFuture.isInAuth();
        }

        Auth proxyAuth = null;
        if (originalFuture != null) {
            proxyAuth = originalFuture.getProxyAuth();
        } else if (proxy != null) {
            proxyAuth = proxy.getProxyAuth();
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Get request auth: {} and proxyAuth: {}.", auth, proxyAuth);
        }

        NettyRequest nettyRequest = requestFactory
            .newNettyRequest(request, isConnectRequest, proxy, isUnauthorized, auth, proxyAuth);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Construct target request: {}", nettyRequest.getHttpRequest());
        }

        if (originalFuture == null) {
            ResponseFuture<T> future =
                newResponseFuture(request, asyncHandler, nettyRequest, proxy, sslConfigInRequest);
            future.setAuth(auth);
            future.setProxyAuth(proxyAuth);
            return future;
        } else {
            originalFuture.setNettyRequest(nettyRequest);
            originalFuture.setCurrentRequest(request);
            return originalFuture;
        }
    }

    private <T> ResponseFuture<T> newResponseFuture(Request request, AsyncHandler<T> asyncHandler,
        NettyRequest nettyRequest, ProxyServer proxy, SslConfig sslConfigInRequest) {
        String expectHeader = request.getHeaders().get(HttpHeaderNames.EXPECT);
        ResponseFuture future = new ResponseFuture(request, asyncHandler, nettyRequest,
            request.getChannelPoolPartitioning(), connectionSemaphore, proxy, sslConfigInRequest);
        if (HttpHeaderValues.CONTINUE.contentEqualsIgnoreCase(expectHeader)) {
            future.setDontWriteBodyBecauseExpectContinue(true);
        }
        return future;
    }

    private Channel getOpenChannel(ResponseFuture<?> future, Request request,
        ProxyServer proxyServer, AsyncHandler<?> asyncHandler) {
        if (future != null && future.isReuseChannel() && ChannelUtils
            .isChannelActive(future.channel())) {
            return future.channel();
        } else {
            return pollPooledChannel(request, proxyServer, asyncHandler);
        }
    }

    private Channel pollPooledChannel(Request request, ProxyServer proxyServer,
        AsyncHandler<?> asyncHandler) {
        try {
            // try to get a channel from pool
            asyncHandler.onConnectionPoolAttempt();
        } catch (Exception e) {
            LOGGER.error("OnConnectionPoolAttempt exception", e);
        }
        Uri uri = request.getUri();
        String targetHost = request.getTargetHost();
        Channel channel = channelManager
            .fetch(uri, targetHost, proxyServer, request.getChannelPoolPartitioning());

        if (channel != null && LOGGER.isDebugEnabled()) {
            LOGGER.debug("Using pooled Channel '{}' for '{}' to '{}'", channel, request.getMethod(),
                uri);
        }
        return channel;
    }

    private <T> ListenableFuture<T> sendRequestWithProxy(Request request,
        AsyncHandler<T> asyncHandler, ResponseFuture<T> future, ProxyServer proxyServer,
        SslConfig sslConfig) {

        ResponseFuture<T> newFuture = null;
        for (int i = 0; i < 3; i++) {
            Channel channel = getOpenChannel(future, request, proxyServer, asyncHandler);

            if (channel == null) {
                // pool is empty
                break;
            }

            if (newFuture == null) {
                newFuture = newRequestAndResponseFuture(request, asyncHandler, future, proxyServer,
                    sslConfig, false);
                LOGGER.debug("Generate a response future: {}", newFuture);
            }

            if (ChannelUtils.isChannelActive(channel)) {
                // if the channel is still active, we can use it,
                // otherwise, channel was closed by the time we computed the request, try again
                return sendRequestWithOpenChannel(newFuture, asyncHandler, channel);
            }
        }

        // couldn't poll an active channel
        newFuture =
            newRequestAndResponseFuture(request, asyncHandler, future, proxyServer, sslConfig,
                true);
        return sendRequestWithNewChannel(request, proxyServer, newFuture, asyncHandler);
    }

    private <T> Future<List<InetSocketAddress>> resolveAddresses(Request request, ProxyServer proxy,
        ResponseFuture<T> future, AsyncHandler<T> asyncHandler) {

        Uri uri = request.getUri();
        final Promise<List<InetSocketAddress>> promise =
            ImmediateEventExecutor.INSTANCE.newPromise();

        // todo: !proxy.isIgnoredForHost(uri.getHost())  ignore host to proxy??
        if (proxy != null && proxy.getProxyType().isHttp()) {
            // resolve proxy server address
            int port = uri.isSecured() ? proxy.getSecuredPort() : proxy.getPort();
            InetSocketAddress unresolvedRemoteAddress =
                InetSocketAddress.createUnresolved(proxy.getHost(), port);
            scheduleRequestTimeout(future, unresolvedRemoteAddress);

            return RequestHostnameResolver.INSTANCE
                .resolve(request.getNameResolver(), unresolvedRemoteAddress, asyncHandler);

        } else {
            // resolve backend address directly
            int port = uri.getExplicitPort();

            InetSocketAddress unresolvedRemoteAddress =
                InetSocketAddress.createUnresolved(uri.getHost(), port);
            scheduleRequestTimeout(future, unresolvedRemoteAddress);
            // todo: set InetAddress for request request.getAddress()
            InetAddress address = request.getAddress();
            if (address != null) {
                // bypass resolution
                InetSocketAddress inetSocketAddress = new InetSocketAddress(address, port);
                return promise.setSuccess(singletonList(inetSocketAddress));
            } else {
                return RequestHostnameResolver.INSTANCE
                    .resolve(request.getNameResolver(), unresolvedRemoteAddress, asyncHandler);
            }
        }
    }
}

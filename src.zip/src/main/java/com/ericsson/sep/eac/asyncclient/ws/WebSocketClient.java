/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.ws;

import io.netty.buffer.ByteBuf;
import io.netty.handler.codec.http.HttpHeaders;

import java.net.SocketAddress;
import java.util.concurrent.Future;

public interface WebSocketClient {

    HttpHeaders getUpgradeHeaders();

    SocketAddress getRemoteAddress();

    SocketAddress getLocalAddress();

    Future<Void> sendTextFrame(String payload);

    /**
     * send a text frame with last flag or extension bit
     * if last is false, the next frame must be sent with sendContinuationFrame
     * @param payload   text payload
     * @param last      the flag shows whether this is the last frame
     * @param extension
     * @return
     */
    Future<Void> sendTextFrame(String payload, boolean last, int extension);

    Future<Void> sendBinaryFrame(byte[] payload);

    /**
     * send a text frame with last flag or extension bit
     * if last is false, the next frame must be sent with sendContinuationFrame
     * @param payload
     * @param last
     * @param extension
     * @return
     */
    Future<Void> sendBinaryFrame(byte[] payload, boolean last, int extension);

    Future<Void> sendBinaryFrame(ByteBuf payload, boolean last, int extension);

    Future<Void> sendContinueFrame(String payload, boolean last, int extension);
    Future<Void> sendContinueFrame(byte[] payload, boolean last, int extension);
    Future<Void> sendContinueFrame(ByteBuf payload, boolean last, int extension);


    Future<Void> sendPingFrame();
    Future<Void> sendPingFrame(byte[] payload);
    Future<Void> sendPingFrame(ByteBuf payload);


    Future<Void> sendPongFrame();
    Future<Void> sendPongFrame(byte[] payload);
    Future<Void> sendPongFrame(ByteBuf payload);


    Future<Void> sendCloseFrame();
    Future<Void> sendCloseFrame(int statusCode, String reason);

    boolean isOpen();

    WebSocketListener addWebSocketListener(WebSocketListener listener);
    WebSocketListener removeWebSocketListener(WebSocketListener listener);
}

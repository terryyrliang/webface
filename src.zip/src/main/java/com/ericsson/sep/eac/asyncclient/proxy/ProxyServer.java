/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.proxy;

import com.ericsson.sep.eac.asyncclient.Auth;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import com.ericsson.sep.eac.asyncclient.util.AuthUtils;
import com.ericsson.sep.eac.asyncclient.util.CommonUtils;

import java.util.Collections;
import java.util.List;

/**
 * @author emeezhg
 * @date 1/10/2019
 */
public class ProxyServer {
    private final String host;
    private final int port;
    private final int securedPort;
    private final List<String> nonProxyHosts;
    private final ProxyType proxyType;
    private final Auth proxyAuth;

    public ProxyServer(String host, int port, int securedPort, Auth proxyAuth,
        List<String> nonProxyHosts, ProxyType proxyType) {
        this.host = host;
        this.port = port;
        this.securedPort = securedPort;
        this.proxyAuth = proxyAuth;
        this.nonProxyHosts = nonProxyHosts;
        this.proxyType = proxyType;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public Auth getProxyAuth() {
        return proxyAuth;
    }

    public int getSecuredPort() {
        return securedPort;
    }

    public List<String> getNonProxyHosts() {
        return nonProxyHosts;
    }

    public ProxyType getProxyType() {
        return proxyType;
    }

    @Override
    public String toString() {
        return "ProxyServer{" + "host='" + host + '\'' + ", port=" + port + ", securedPort="
            + securedPort + ", nonProxyHosts=" + nonProxyHosts + ", proxyType=" + proxyType
            + ", proxyAuth=" + proxyAuth + '}';
    }

    public static class Builder {
        private static final String COLON = ":";
        private String host;
        private int port;
        private int securedPort;
        private Auth proxyAuth;
        private List<String> nonProxyHosts;
        private ProxyType proxyType;

        public Builder(String url) {
            Uri uri = Uri.create(url);
            this.host = uri.getHost();
            this.port = uri.getExplicitPort();
            this.securedPort = uri.getExplicitPort();
            buildProxyAuth(uri.getUserInfo());
        }

        private void buildProxyAuth(String userInfo) {
            if (CommonUtils.isNonEmpty(userInfo) && userInfo.contains(COLON)) {
                String[] auth = userInfo.split(COLON, 2);
                this.proxyAuth = AuthUtils.basicAuthRealm(auth[0], auth[1]).build();
            }
        }

        public Builder(String host, int port) {
            this.host = host;
            this.port = port;
            this.securedPort = port;
        }

        public Builder setProxyAuth(Auth proxyAuth) {
            this.proxyAuth = proxyAuth;
            return this;
        }

        public Builder setHost(String host) {
            this.host = host;
            return this;
        }

        public Builder setPort(int port) {
            this.port = port;
            return this;
        }

        public Builder setSecuredPort(int securedPort) {
            this.securedPort = securedPort;
            return this;
        }

        public Builder setNonProxyHosts(List<String> nonProxyHosts) {
            this.nonProxyHosts = nonProxyHosts;
            return this;
        }

        public Builder setProxyType(ProxyType proxyType) {
            this.proxyType = proxyType;
            return this;
        }

        public ProxyServer build() {
            List<String> nonProxyHosts = this.nonProxyHosts != null ?
                Collections.unmodifiableList(this.nonProxyHosts) :
                Collections.emptyList();
            ProxyType proxyType = this.proxyType != null ? this.proxyType : ProxyType.HTTP;
            return new ProxyServer(host, port, securedPort, proxyAuth, nonProxyHosts, proxyType);
        }
    }
}

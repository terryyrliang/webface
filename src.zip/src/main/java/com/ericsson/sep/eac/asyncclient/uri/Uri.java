/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient.uri;

import com.ericsson.sep.eac.asyncclient.common.StringBuilderPool;

import java.net.URI;
import java.net.URISyntaxException;

import static com.ericsson.sep.eac.asyncclient.util.AssertUtils.assertNotEmpty;
import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isEmpty;
import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.isNonEmpty;


/**
 * @author emeezhg
 * @date 12/19/2018
 */
public class Uri {
    public static final String HTTP = "http";
    public static final String HTTPS = "https";
    public static final String WS = "ws";
    public static final String WSS = "wss";
    private final String scheme;
    private final String userInfo;
    private final String host;
    private final int port;
    private final String query;
    private final String path;
    private final String fragment;
    private String url;
    private boolean secured;
    private boolean webSocket;
    private boolean http2;
    private boolean isHttp2PriorKnowledge;

    public Uri(String scheme, String userInfo, String host, int port, String path, String query,
        String fragment, boolean isHttp2, boolean isHttp2PriorKnowledge) {
        this(scheme, userInfo, host, port, path, query, fragment, isHttp2);
        this.isHttp2PriorKnowledge = isHttp2PriorKnowledge;
    }

    public Uri(String scheme, String userInfo, String host, int port, String path, String query,
        String fragment, boolean isHttp2) {
        this(scheme, userInfo, host, port, path, query, fragment);
        this.http2 = isHttp2;
    }

    public Uri(String scheme, String userInfo, String host, int port, String path, String query,
        String fragment) {
        this.scheme = assertNotEmpty(scheme, "scheme");
        this.userInfo = userInfo;
        this.host = assertNotEmpty(host, "host");
        this.port = port;
        this.path = path;
        this.query = query;
        this.fragment = fragment;
        this.secured = HTTPS.equals(scheme) || WSS.equals(scheme);
        this.webSocket = WS.equals(scheme) || WSS.equalsIgnoreCase(scheme);
    }

    public static Uri create(String originalUrl) {
        return create(null, originalUrl, false, false);
    }

    public static Uri create(String originalUrl, boolean isHttp2) {
        return create(null, originalUrl, isHttp2, false);
    }

    public static Uri create(String originalUrl, boolean isHttp2, boolean isHttp2PriorKnowledge) {
        return create(null, originalUrl, isHttp2, isHttp2PriorKnowledge);
    }

//    public static Uri create(Uri context, final String originalUrl, boolean isHttp2) {
//        UriParser parser = new UriParser();
//        parser.parse(context, originalUrl);
//
//        if (isEmpty(parser.scheme)) {
//            throw new IllegalArgumentException(
//                originalUrl + " could not be parsed into a proper Uri, missing scheme");
//        }
//        if (isEmpty(parser.host)) {
//            throw new IllegalArgumentException(
//                originalUrl + " could not be parsed into a proper Uri, missing host");
//        }
//
//        return new Uri(parser.scheme, parser.userInfo, parser.host, parser.port, parser.path,
//            parser.query, parser.fragment, isHttp2);
//    }

    public static Uri create(Uri context, final String originalUrl, boolean isHttp2,
        boolean isHttp2PriorKnowledge) {
        UriParser parser = new UriParser();
        parser.parse(context, originalUrl);

        if (isEmpty(parser.scheme)) {
            throw new IllegalArgumentException(
                originalUrl + " could not be parsed into a proper Uri, missing scheme");
        }
        if (isEmpty(parser.host)) {
            throw new IllegalArgumentException(
                originalUrl + " could not be parsed into a proper Uri, missing host");
        }

        return new Uri(parser.scheme, parser.userInfo, parser.host, parser.port, parser.path,
            parser.query, parser.fragment, isHttp2, isHttp2PriorKnowledge);
    }

    public String getQuery() {
        return query;
    }

    public String getPath() {
        return path;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public int getPort() {
        return port;
    }

    public String getScheme() {
        return scheme;
    }

    public String getHost() {
        return host;
    }

    public String getFragment() {
        return fragment;
    }

    public boolean isSecured() {
        return secured;
    }

    public boolean isWebSocket() {
        return webSocket;
    }

    public boolean isHttp2() {
        return http2;
    }

    public boolean isHttp2PriorKnowledge() {
        return isHttp2PriorKnowledge;
    }

    public URI toJavaNetURI() throws URISyntaxException {
        return new URI(toUrl());
    }

    public int getExplicitPort() {
        return port == -1 ? getSchemeDefaultPort() : port;
    }

    public int getSchemeDefaultPort() {
        return isSecured() ? 443 : 80;
    }

    /**
     * @return [scheme]://[userInfo]@[host]:[port]/[path]?[query]
     */
    public String toUrl() {
        if (url == null) {
            StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
            sb.append(scheme).append("://");
            if (userInfo != null) {
                sb.append(userInfo).append('@');
            }
            sb.append(host);
            if (port != -1) {
                sb.append(':').append(port);
            }
            if (path != null) {
                sb.append(path);
            }
            if (query != null) {
                sb.append('?').append(query);
            }
            url = sb.toString();
            sb.setLength(0);
        }
        return url;
    }

    /**
     * @return [scheme]://[hostname](:[port])/path. Port is omitted if it matches the scheme's default one.
     */
    public String toBaseUrl() {
        StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
        sb.append(scheme).append("://").append(host);
        if (port != -1 && port != getSchemeDefaultPort()) {
            sb.append(':').append(port);
        }
        if (isNonEmpty(path)) {
            sb.append(path);
        }
        return sb.toString();
    }

    /**
     * @return requestUri with query params /[path]?[query]
     */
    public String toRelativeUrl() {
        StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
        if (isNonEmpty(path)) {
            sb.append(path);
        } else {
            sb.append('/');
        }
        if (query != null) {
            sb.append('?').append(query);
        }

        return sb.toString();
    }

    public String toFullUrl() {
        return fragment == null ? toUrl() : toUrl() + "#" + fragment;
    }

    /**
     * @return [scheme]://[host]:[port]
     */
    public String getBaseUrl() {
        return scheme + "://" + host + ":" + getExplicitPort();
    }

    /**
     * @return [host]:[port]
     */
    public String getHostAndPort() {
        return host + ":" + getExplicitPort();
    }

    public boolean isSameBase(Uri other) {
        return scheme.equals(other.getScheme()) && host.equals(other.getHost())
            && getExplicitPort() == other.getExplicitPort();
    }

    public String getNonEmptyPath() {
        return isNonEmpty(path) ? path : "/";
    }

    @Override
    public String toString() {
        return "Uri{fullUrl=" + toUrl() + ", secured=" + secured + ", webSocket=" + webSocket
            + ", http2=" + http2 + ", isHttp2PriorKnowledge=" + isHttp2PriorKnowledge + '}';
    }

    public Uri withNewScheme(String newScheme) {
        return new Uri(newScheme, userInfo, host, port, path, query, fragment);
    }

    public Uri withNewQuery(String newQuery) {
        return new Uri(scheme, userInfo, host, port, path, newQuery, fragment);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((host == null) ? 0 : host.hashCode());
        result = prime * result + ((path == null) ? 0 : path.hashCode());
        result = prime * result + port;
        result = prime * result + ((query == null) ? 0 : query.hashCode());
        result = prime * result + ((scheme == null) ? 0 : scheme.hashCode());
        result = prime * result + ((userInfo == null) ? 0 : userInfo.hashCode());
        result = prime * result + ((fragment == null) ? 0 : fragment.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Uri other = (Uri) obj;
        if (host == null) {
            if (other.host != null) {
                return false;
            }
        } else if (!host.equals(other.host)) {
            return false;
        }
        if (path == null) {
            if (other.path != null) {
                return false;
            }
        } else if (!path.equals(other.path)) {
            return false;
        }
        if (port != other.port) {
            return false;
        }
        if (query == null) {
            if (other.query != null) {
                return false;
            }
        } else if (!query.equals(other.query)) {
            return false;
        }
        if (scheme == null) {
            if (other.scheme != null) {
                return false;
            }
        } else if (!scheme.equals(other.scheme)) {
            return false;
        }
        if (userInfo == null) {
            if (other.userInfo != null) {
                return false;
            }
        } else if (!userInfo.equals(other.userInfo)) {
            return false;
        }
        if (fragment == null) {
            if (other.fragment != null) {
                return false;
            }
        } else if (!fragment.equals(other.fragment)) {
            return false;
        }
        return true;
    }

    public static void validateSupportedScheme(Uri uri) {
        final String scheme = uri.getScheme();
        if (scheme == null || !scheme.equalsIgnoreCase(HTTP) && !scheme.equalsIgnoreCase(HTTPS)
            && !scheme.equalsIgnoreCase(WS) && !scheme.equalsIgnoreCase(WSS)) {
            throw new IllegalArgumentException("The URI scheme, of the URI " + uri
                + ", must be equal (ignoring case) to 'http', 'https', 'ws', or 'wss'");
        }
    }
}

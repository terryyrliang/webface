/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel.handler;

import com.ericsson.sep.eac.asyncclient.OnLastContentCallback;
import com.ericsson.sep.eac.asyncclient.channel.Http2ChannelPool;
import com.ericsson.sep.eac.asyncclient.common.AsyncConstants;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.ChannelEvent;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelUtils;
import com.ericsson.sep.eac.asyncclient.netty.channel.handler.interceptor.Interceptors;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.codec.PrematureChannelClosureException;
import io.netty.handler.codec.http.*;
import io.netty.util.ReferenceCountUtil;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.channels.ClosedChannelException;

public abstract class AsyncClientBaseHandler extends ChannelInboundHandlerAdapter {
    protected static final Logger LOGGER = LogHelper.getLogger(AsyncClientBaseHandler.class);

    protected final AsyncClientConfig config;
    protected final RequestSender requestSender;
    protected final ChannelManager channelManager;
    final Interceptors interceptors;

    public AsyncClientBaseHandler(AsyncClientConfig config, RequestSender requestSender,
        ChannelManager channelManager) {
        this.config = config;
        this.requestSender = requestSender;
        this.channelManager = channelManager;
        this.interceptors = new Interceptors(requestSender, channelManager);
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        LOGGER.debug("Trigger channelRead with received msg: {}", msg.getClass().getSimpleName());
        Channel channel = ctx.channel();
        Object attr = null;
        if (msg instanceof DefaultFullHttpResponse) {
            DefaultFullHttpResponse fullHttpResponse = (DefaultFullHttpResponse) msg;
            String streamId = fullHttpResponse.headers().get(AsyncConstants.STREAM_ID_HEADER);
            if (null != streamId) {
                Http2ChannelPool http2ChannelPool = (Http2ChannelPool) channelManager.getChannelPool();
                attr = http2ChannelPool.getResponseFuture(ChannelUtils.getRequestId(channel, Integer.valueOf(streamId)));
            }
        }
        if (null == attr) {
            attr = ChannelUtils.getAttribute(channel);
        }
        if (null == attr) {
            LOGGER.warn("Receive unknow message {}", msg);
            ReferenceCountUtil.release(msg);
            return;
        }
        LOGGER.debug("Get channel attribute: {}", attr.getClass().getSimpleName());
        try {
            if (attr instanceof OnLastContentCallback) {
                if (msg instanceof LastHttpContent) {
                    ((OnLastContentCallback) attr).call();
                }
            } else if (attr instanceof ResponseFuture<?>) {
                ResponseFuture<?> future = (ResponseFuture<?>) attr;
                future.touch();
                LOGGER.debug("Handle Read channel.");
                handleRead(channel, future, msg);
            } else if (attr != ChannelEvent.DISCARD) {
                LOGGER.warn("Close channel: {} with attribute: {} received message: {}", channel,
                    attr, msg);
                ChannelUtils.closeChannelSilently(channel);
            }
        } finally {
            LOGGER.debug("Release received message.");
            ReferenceCountUtil.release(msg);
        }
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        LOGGER.debug("Channel inactive: abort channel");
        if (requestSender.isClosed()) {
            return;
        }
        Channel channel = ctx.channel();
        channelManager.removeAll(channel);
        Object attr = ChannelUtils.getAttribute(channel);
        if (attr instanceof ResponseFuture<?>) {
            ResponseFuture<?> future = (ResponseFuture<?>) attr;
            future.touch();
            handleChannelInactive(future);
            requestSender.handleUnexpectedClosedChannel(channel, future);
        }
        super.channelInactive(ctx);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        LOGGER.warn("Exception caught.", cause);
        Throwable throwable = cause.getCause();
        if (throwable instanceof PrematureChannelClosureException
            || throwable instanceof ClosedChannelException) {
            return;
        }
        Channel channel = ctx.channel();
        ResponseFuture<?> future = null;
        try {
            Object attr = ChannelUtils.getAttribute(channel);
            if (attr instanceof ResponseFuture<?>) {
                future = (ResponseFuture<?>) attr;
                future.attachChannel(null, false);
                future.touch();

                if (throwable instanceof IOException) {
                    ChannelUtils.closeChannelSilently(channel);
                    return;
                }
            }
        } catch (Exception e) {
            throwable = e;
        }
        if (future != null) {
            LOGGER.warn("Exception occur, recover future failure.");
            try {
                requestSender.abort(channel, future, throwable);
                handleException(future, cause);
            } catch (Exception e) {
                LOGGER.error("Handle exception error.", e);
            }
        }
        channelManager.closeChannel(channel);
        ChannelUtils.closeChannelSilently(channel);
    }

    void handleReadFailure(Channel channel, ResponseFuture<?> future, Throwable cause) {
        try {
            LOGGER.debug("Handle read failure: abort channel with exception", cause);
            requestSender.abort(channel, future, cause);
        } catch (Exception e) {
            LOGGER.warn("Abort failure", e);
        } finally {
            finishUpdate(future, channel, true);
        }
    }

    void finishUpdate(ResponseFuture<?> future, Channel channel, boolean close) {
        future.cancelTimeouts();
        if (close) {
            channelManager.closeChannel(channel);
        } else {
            channelManager.offerChannelToPool(channel, future.getAsyncHandler(), true,
                future.getPartitionKey());
        }

        try {
            future.done();
        } catch (Exception e) {
            LOGGER.warn("Exception", e);
        }
    }

    boolean abortAfterHandlingStatusAndHeaders(AsyncHandler<?> handler, HttpResponseStatus status,
        HttpHeaders httpHeaders) {
        return handler.onStatusReceived(status) == AsyncHandler.State.ABORT || (
            !httpHeaders.isEmpty()
                && handler.onHeadersReceived(httpHeaders) == AsyncHandler.State.ABORT);
    }

    void handleHttpVersion(AsyncHandler<?> handler, HttpVersion httpVersion) {
        handler.onHttpVersionReceived(httpVersion);
    }

    public abstract void handleRead(Channel channel, ResponseFuture<?> future, Object receivedMsg);

    public abstract void handleChannelInactive(ResponseFuture<?> future);

    public abstract void handleException(ResponseFuture<?> future, Throwable cause);
}

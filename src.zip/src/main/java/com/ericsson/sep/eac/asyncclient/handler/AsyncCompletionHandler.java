/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.handler;

import com.ericsson.sep.eac.asyncclient.HttpResponsePartContent;
import com.ericsson.sep.eac.asyncclient.Response;
import com.ericsson.sep.eac.asyncclient.common.LogHelper;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import org.slf4j.Logger;

public abstract class AsyncCompletionHandler<T> implements ProgressAsyncHandler<T>{
    private static final Logger LOGGER = LogHelper.getLogger(AsyncCompletionHandler.class);
    private final Response.ResponseBuilder responseBuilder = new Response.ResponseBuilder();

    @Override
    public State onHttpVersionReceived(HttpVersion version){
        LOGGER.debug("recieved version:{}", version);
        responseBuilder.reset();
        responseBuilder.accumulate(version);
        return State.CONTINUE;
    }

    @Override
    public State onStatusReceived(HttpResponseStatus status) {
        responseBuilder.reset();
        responseBuilder.accumulate(status);
        return State.CONTINUE;
    }

    @Override
    public State onHeadersReceived(HttpHeaders headers) {
        responseBuilder.accumulate(headers);
        return State.CONTINUE;
    }

    @Override
    public State onPartContentReceived(HttpResponsePartContent partContent) {
        responseBuilder.accumulate(partContent);
        return State.CONTINUE;
    }

    @Override
    public State onTrailingHeadersReceived(HttpHeaders headers) {
        responseBuilder.accumulate(headers);
        return State.CONTINUE;
    }

    @Override
    public void onThrowable(Throwable t) {
        LOGGER.warn(t.getMessage());
    }

    @Override
    public T onCompleted() {
        LOGGER.debug("response completed");
        return onCompleted(responseBuilder.build());
    }

    @Override
    public State onHeadersWritten() {
        return State.CONTINUE;
    }

    @Override
    public State onContentWritten() {
        return State.CONTINUE;
    }

    @Override
    public State onContentWriteProgress(long amount, long current, long total) {
        return State.CONTINUE;
    }

    abstract public T onCompleted(Response response);
}

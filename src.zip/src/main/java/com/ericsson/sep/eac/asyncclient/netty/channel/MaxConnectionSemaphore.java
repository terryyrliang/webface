/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.channel;

import com.ericsson.sep.eac.asyncclient.exception.TooManyConnectionsException;
import com.ericsson.sep.eac.asyncclient.util.CommonUtils;

import java.io.IOException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class MaxConnectionSemaphore implements ConnectionSemaphore {
    protected final Semaphore freeChannels;
    protected final int obtainTimeoutMilliSec;
    protected final IOException tooManyConnections;

    public MaxConnectionSemaphore(int maxConnections, int obtainTimeoutMilliSec) {
        this.tooManyConnections = CommonUtils
            .unknownStackTrace(new TooManyConnectionsException(maxConnections),
                MaxConnectionSemaphore.class, "obtainChannelLock");
        freeChannels =
            maxConnections > 0 ? new Semaphore(maxConnections) : InfiniteSemaphore.INSTANCE;
        this.obtainTimeoutMilliSec = Math.max(0, obtainTimeoutMilliSec);
    }

    @Override
    public void acquireChannelLock(Object partitionKey) throws IOException {
        try {
            if (!freeChannels.tryAcquire(obtainTimeoutMilliSec, TimeUnit.MILLISECONDS)) {
                throw tooManyConnections;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
        }
    }

    @Override
    public void releaseChannelLock(Object partitionKey) {
        freeChannels.release();
    }
}

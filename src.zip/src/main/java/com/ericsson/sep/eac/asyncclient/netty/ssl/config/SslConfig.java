/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.ssl.config;

import java.util.concurrent.TimeUnit;

public interface SslConfig {
    /**
     * @return true if use openssl
     */
    boolean isUseOpenSsl();

    /**
     * @return true if use TLS1.3
     */
    boolean isTLS13Support();

    /**
     * @return true if allow insecure connection
     */
    boolean isAllowInsecureConnection();

    /**
     * @return private key file absolute path
     */
    String getPrivateKeyFile();

    /**
     * @return certificate file absolute path
     */
    String getCertificateFile();

    /**
     * @return trust certificate file absolute path
     */
    String getTrustCertFile();

    /**
     * @return the password of private key
     */
    String getKeyPasswordFile();

    /**
     * @return handshake timeout in milliSec
     */
    int getHandshakeTimeoutMilliSec();

    /**
     * @return session cache size
     */
    int getTlsSessionCacheSize();

    /**
     * @return tls session timeout in MilliSec
     */
    int getTlsSessionTimeoutMilliSec();

    int getCacheVolume();

    int getCacheTimeout();

    TimeUnit getCacheTimeoutUnit();

    void copyFrom(SslConfig parentSslConfig);
}

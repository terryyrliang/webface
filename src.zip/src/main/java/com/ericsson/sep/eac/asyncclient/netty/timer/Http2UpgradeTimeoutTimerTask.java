/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.timer;

import com.ericsson.sep.eac.asyncclient.common.StringBuilderPool;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.netty.response.ResponseFuture;
import io.netty.util.Timeout;

import static com.ericsson.sep.eac.asyncclient.util.CommonUtils.currentMillisTime;

public class Http2UpgradeTimeoutTimerTask extends TimeoutTimerTask{

    private final long upgradeTimeout;
    public Http2UpgradeTimeoutTimerTask(RequestSender requestSender, TimeoutsHolder timeoutsHolder,
        ResponseFuture<?> responseFuture, int upgradeTimeout) {
        super(requestSender, timeoutsHolder, responseFuture);
        this.upgradeTimeout = upgradeTimeout;
    }

    @Override
    public void run(Timeout timeout) {
        if (done.getAndSet(true) || requestSender.isClosed()){
            return;
        }
        timeoutsHolder.cancel();
        if (responseFuture.isDone()){
            return;
        }

        long current = currentMillisTime();
        long currentReadTimeInstant = upgradeTimeout + responseFuture.getLastTouch();

        if (currentReadTimeInstant <= current){
            // read timeout
            StringBuilder sb = StringBuilderPool.DEFAULT.stringBuilder();
            sb.append("Read timeout to ");
            addRemoteAddressToExpireInfo(sb);
            sb.append(" after ").append(upgradeTimeout).append(" ms");
            expire(sb.toString(), current - responseFuture.getLastTouch());
            timeoutsHolder.cancel();
        } else {
            done.set(false);
            timeoutsHolder.startUpgradeTimeout(this);
        }
    }
}

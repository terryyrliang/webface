/*
 * ----------------------------------------------------------------------
 *   COPYRIGHT Ericsson 2018
 *
 *   The copyright to the computer program(s) herein is the property of
 *   Ericsson Inc. The programs may be used and/or copied only with written
 *   permission from Ericsson Inc. or in accordance with the terms and
 *   conditions stipulated in the agreement/contract under which the
 *   program(s) have been supplied.
 *   ----------------------------------------------------------------------
 *
 */

package com.ericsson.sep.eac.asyncclient;

import com.ericsson.sep.eac.asyncclient.config.AsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.config.DefaultAsyncClientConfig;
import com.ericsson.sep.eac.asyncclient.handler.AsyncCompletionHandlerBase;
import com.ericsson.sep.eac.asyncclient.handler.AsyncHandler;
import com.ericsson.sep.eac.asyncclient.netty.channel.ChannelManager;
import com.ericsson.sep.eac.asyncclient.netty.request.RequestSender;
import com.ericsson.sep.eac.asyncclient.uri.Uri;
import io.netty.util.HashedWheelTimer;
import io.netty.util.Timer;
import io.netty.util.concurrent.DefaultThreadFactory;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author emeezhg
 * @date 1/8/2019
 */
public class DefaultAsyncClient implements AsyncClient {

    private final AsyncClientConfig config;
    private final ChannelManager channelManager;
    private final RequestSender requestSender;
    private final Timer nettyTimer;

    private final AtomicBoolean closed = new AtomicBoolean(false);

    public DefaultAsyncClient() {
        this(new DefaultAsyncClientConfig.Builder().build());
    }

    public DefaultAsyncClient(AsyncClientConfig config) {
        this.config = config;
        nettyTimer = newNettyTimer(config);
        channelManager = new ChannelManager(config, nettyTimer);
        requestSender =
            new RequestSender(config, channelManager, nettyTimer, new AsyncClientState(closed));
        channelManager.configBootStrapBaseHandlers(requestSender);
        // http2
        channelManager.configHttp2BootStrapBaseHandlers(requestSender);
    }

    private Timer newNettyTimer(AsyncClientConfig config) {
        ThreadFactory threadFactory = new DefaultThreadFactory("asyncClient");
        HashedWheelTimer timer = new HashedWheelTimer(threadFactory);
        timer.start();
        return timer;
    }

    @Override
    public boolean isClosed() {
        return false;
    }


    @Override
    public AsyncClientConfig getConfig() {
        return this.config;
    }

    @Override
    public void close() {
        if (closed.compareAndSet(false, true)) {
            channelManager.shutdownGracefully();
        }
        if (nettyTimer != null) {
            nettyTimer.stop();
        }
    }

    @Override
    public BoundRequestBuilder prepare(String url) {
        return requestBuilder("GET", url);
    }


    @Override
    public BoundRequestBuilder prepare(String method, String url) {
        return requestBuilder(method, url);
    }

    @Override
    public BoundRequestBuilder prepareRequest(Request request) {
        return requestBuilder(request);
    }

    @Override
    public BoundRequestBuilder prepareRequest(RequestBuilder requestBuilder) {
        return prepareRequest(requestBuilder.build());
    }

    @Override
    public <T> ListenableFuture<T> executeRequest(Request request, AsyncHandler<T> handler) {
        return execute(request, handler);
    }

    @Override
    public <T> ListenableFuture<T> executeRequest(RequestBuilder requestBuilder,
        AsyncHandler<T> handler) {
        return execute(requestBuilder.build(), handler);
    }

    @Override
    public ListenableFuture<Response> executeRequest(RequestBuilder requestBuilder) {
        return executeRequest(requestBuilder.build());
    }

    @Override
    public ListenableFuture<Response> executeRequest(Request request) {
        return executeRequest(request, new AsyncCompletionHandlerBase());
    }

    protected BoundRequestBuilder requestBuilder(String method, String url) {
        return new BoundRequestBuilder(this, method, false).setUrl(url);
    }

    protected BoundRequestBuilder requestBuilder(Request request) {
        return new BoundRequestBuilder(this, request);
    }

    private <T> ListenableFuture<T> execute(Request request, final AsyncHandler<T> asyncHandler) {
        try {
            Uri uri = request.getUri();
            if (uri.isHttp2() && uri.isHttp2PriorKnowledge()) {
                return requestSender.sendHttp2Request(request, asyncHandler, null);
            } else {
                return requestSender.sendRequest(request, asyncHandler, null);
            }
        } catch (Exception e) {
            asyncHandler.onThrowable(e);
            return new ListenableFuture.CompletedFailure<>(e);
        }
    }

    public ChannelManager getChannelManager() {
        return channelManager;
    }
}

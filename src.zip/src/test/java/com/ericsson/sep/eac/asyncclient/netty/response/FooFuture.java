/*
 *  COPYRIGHT Ericsson 2019
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 */

package com.ericsson.sep.eac.asyncclient.netty.response;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public class FooFuture {
    private static final AtomicIntegerFieldUpdater<FooFuture> IN_AUTH_FIELD =
        AtomicIntegerFieldUpdater.newUpdater(FooFuture.class, "inAuth");
    private volatile int inAuth = 0;

    public boolean isInAuth() {
        return inAuth != 0;
    }

    public void setInAuth(boolean inAuth) {
        this.inAuth = inAuth ? 1 : 0;
    }

    public boolean isAndSetInAuth(boolean set) {
        return IN_AUTH_FIELD.getAndSet(this, set ? 1 : 0) != 0;
    }
}
